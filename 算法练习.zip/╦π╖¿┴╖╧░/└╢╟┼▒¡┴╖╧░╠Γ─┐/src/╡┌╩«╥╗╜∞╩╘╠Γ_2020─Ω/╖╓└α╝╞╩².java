package ��ʮһ������_2020��;

import java.util.Scanner;

public class ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] input_text=scanner.next().toCharArray();
		scanner.close();
		int A=0;
		int B=0;
		int C=0;
		for(int i=0;i<input_text.length;i++) {
			char text=input_text[i];
			if(text>='A' && text<='Z') {
				A++;
			}
			else if(text>='a' && text<='z') {
				B++;
			}
			else if(text>='0' && text<='9') {
				C++;
			}
		}
		System.out.println(A);
		System.out.println(B);
		System.out.println(C);
	}
}
