package ��ʮһ������_2020��;

import java.math.BigInteger;

public class ָ������ {
	public static void main(String[] args) {
		int n=2020;
		BigInteger data=BigInteger.ONE;
		BigInteger mod=new BigInteger("1921");
		BigInteger m=new BigInteger("7");
		for(int i=1;i<=n;i++) {
			data=data.multiply(m);
		}
		System.out.println(data.mod(mod));
	}
}
