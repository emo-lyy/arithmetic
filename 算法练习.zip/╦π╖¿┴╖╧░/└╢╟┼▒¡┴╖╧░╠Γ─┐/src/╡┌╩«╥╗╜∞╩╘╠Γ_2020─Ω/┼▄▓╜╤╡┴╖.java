package ��ʮһ������_2020��;

public class �ܲ�ѵ�� {
	private static int begin=10000;
	private static int sub=600;
	private static int add=300;
	public static void main(String[] args) {
		double count=0;
		while(begin>0) {
			if(begin>=600) {
				begin-=(sub-add);
				count+=120;
			}
			else {
				count+=begin/10.0;
				begin-=begin;
			}
			//System.out.println(count+"s"+" "+begin);
		}
		System.out.println(count);
	}
}
