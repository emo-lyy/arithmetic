package ��ʮһ������_2020��;

import java.util.Scanner;

public class �ַ������� {
	private static char[] A="ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String[] s=scanner.next().split("");
		scanner.close();
		
		String res="";
		for(int i=0;i<s.length;i++) {
			if(i+1<s.length) {
				String temp=s[i]+s[i+1];
				if(Integer.valueOf(temp)<=26) {
					i++;
					res+=A[Integer.valueOf(temp)-1];
				}
				else {
					res+=A[Integer.valueOf(s[i])-1];
				}
			}
			else {
				res+=A[Integer.valueOf(s[i])-1];
			}
		}
		System.out.println(res);
	}
}
