package ��ʮһ������_2020��;

import java.util.Scanner;

public class ����Сƴ�� {
	static int n,k;
	static String[] A;
	static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		k=scanner.nextInt();
		A=new String[n];
		for(int i=0;i<n;i++) {
			A[i]=scanner.next();
		}
		scanner.close();
		
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				if(i!=j) {
					if(Integer.valueOf(A[i]+A[j])<=k) {
						count++;
					}
				}
			}
		}
		System.out.println(count);
	}
}
