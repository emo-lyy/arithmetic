package ��ʮһ������_2020��;

public class REPEAT_���� {
	public static void main(String[] args) {
		int A=0;
		for(int a=0;a<2;a++) {
			A+=4;
			for(int b=0;b<5;b++) {
				for(int c=0;c<6;c++) {
					A+=5;
				}
				A+=7;
			}
			A+=8;
		}
		A+=9;
		System.out.println(A);
	}
}
