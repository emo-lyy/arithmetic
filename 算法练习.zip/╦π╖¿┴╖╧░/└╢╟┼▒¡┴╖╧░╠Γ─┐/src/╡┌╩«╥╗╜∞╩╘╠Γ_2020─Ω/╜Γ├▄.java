package ��ʮһ������_2020��;

import java.util.Scanner;

public class ���� {
	private static char[] A="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();			//�����ַ�
	private static char[]B= "yxmdacikntjhqlgoufszpwbrevYXMDACIKNTJHQLGOUFSZPWBREV".toCharArray();			//�����ַ�
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] text=scanner.next().toCharArray();
		scanner.close();
		String res=decode(text);
		System.out.println(res);
	}
	//����
	public static String encryption(char[] text) {
		String res="";
		for(int i=0;i<text.length;i++) {
			for(int j=0;j<A.length;j++) {
				if(text[i]==A[j]) {
					res+=B[j];
					break;
				}
			}
		}
		return res;
	}
	
	public static String decode(char[] text) {
		String res="";
		for(int i=0;i<text.length;i++) {
			for(int j=0;j<B.length;j++) {
				if(text[i]==B[j]) {
					res+=A[j];
					break;
				}
			}
		}
		return res;
	}
}
