package ��ʮ��ʡ��;

import java.util.ArrayList;
import java.util.Scanner;

public class ƽ���� {
	static ArrayList<String> box=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		box.add("2");
		box.add("0");
		box.add("1");
		box.add("9");
		f(n);
	}
	public static void f(int n) {
		ArrayList<Integer> temp=new ArrayList<>();
		for(int i=1;i<=n;i++) {
			String[] S=(i+"").split("");
			for (String s : S) {
				if(box.contains(s)) {
					temp.add(i);
					break;
				}
			}
		}
		long res=1;
		for (Integer i : temp) {
			//System.out.println(i);
			res+=i*i;
		}
		System.out.println(res);
	}
}
