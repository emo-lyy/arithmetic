package ��ʮ��ʡ��;

import java.util.Scanner;

public class ������ֵ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		long beginTime=System.currentTimeMillis();
		f(n);
		long endTime=System.currentTimeMillis();
		System.out.println("�ܹ�ִ����:"+(endTime-beginTime)+"ms");
	}
	public static void f(int n) {
		if(n<=3) {System.out.println(1);return;}
		else {
			int a=1;
			int b=1;
			int c=1;
			int sum=(a+b+c)%10000;
			int index=4;
			while(index++<n) {
				a=b;
				b=c;
				c=sum;
				sum=(a+b+c)%10000;
			}
			System.out.println(sum);
		}
	}
}
