package ��ʮ��ʡ��;

import java.util.Arrays;
import java.util.Scanner;

public class ���������ȼ� {
	    public static void main(String args[]) {

	        int t = 0, w = 0;
	        Scanner sc = new Scanner(System.in);
	        int a = sc.nextInt();
	        int b = sc.nextInt();
	        int c = sc.nextInt();
	        int[][] state = new int[c+1][a+1];
//	        long start = System.currentTimeMillis();   //Ҫ���Եĳ���򷽷� ���������������ʱ��ġ�
	        
	        for(int i = 0; i <= c; i++)
	            for(int j = 0; j <= a; j++)
	                state[i][j] = -1;
//	        for(int i = 0; i <= a; i++) state[0][i] = 0;
	        Arrays.fill(state[0], 0);     //---------Java��ν�ĵĶ�ά���飬ֻ��a{{},{}}���ѵ�һ�����0�����ڽ���ȥ�ļ�
	        for(int i = 0; i < b; i++) {
	            t = sc.nextInt();
	            w = sc.nextInt();
	            if(t > c) continue;
	            if(state[t][w] == -1) state[t][w] = 0;
	            state[t][w] += 2;
	        }
	        sc.close();
	        for(int i = 1; i <= a; i++) {
	            for(int j = 1; j <= c; j++) {
	                state[j][i] = state[j-1][i] + state[j][i];
	                if(state[j][i] < 0) state[j][i] = 0;

	            }
	        }
	        //     -----------���濪ʼ�ж�-------------
//	        ArrayList<Integer> jilu = new ArrayList<Integer>();
	        int sign = 0, index = 0;
	        int num = 0;
	        for(int i = 1; i <= a; i++) {
	            sign = state[c][i];
	            index = c;
	            while(sign == 4 || sign == 5) {
	                sign = state[--index][i];
	            }
	            if(sign > 5) {
	                num++;
	            }
	        }
	        System.out.println(num);
	        
//	        long end = System.currentTimeMillis();
//	        System.out.println("��������ʱ�䣺"+(end-start)+"ms");
	        
	    }
	}
