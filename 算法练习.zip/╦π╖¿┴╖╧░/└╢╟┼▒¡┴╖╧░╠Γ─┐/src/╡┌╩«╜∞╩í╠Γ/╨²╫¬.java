package ��ʮ��ʡ��;

import java.util.ArrayList;
import java.util.Scanner;

public class ��ת {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		int[][] A=new int[n][m];
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				A[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		
		ArrayList<ArrayList<Integer>> temp=new ArrayList<>();
		for(int i=m-1;i>=0;i--) {
			ArrayList<Integer> list=new ArrayList<>();
			for(int j=n-1;j>=0;j--) {
				list.add(A[j][i]);
			}
			temp.add(list);
		}
		for(int i=temp.size()-1;i>=0;i--) {
			ArrayList<Integer> list=temp.get(i);
			for (Integer integer : list) {
				System.out.print(integer+" ");
			}
			System.out.println();
		}
	}
}
