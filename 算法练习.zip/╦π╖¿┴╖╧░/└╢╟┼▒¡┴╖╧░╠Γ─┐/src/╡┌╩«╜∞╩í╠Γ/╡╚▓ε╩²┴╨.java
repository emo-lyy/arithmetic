package ��ʮ��ʡ��;

import java.util.Arrays;
import java.util.Scanner;

public class �Ȳ����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] A=new int[n];
		for(int i=0;i<n;i++)A[i]=scanner.nextInt();
		scanner.close();
		Arrays.sort(A);
		int min=A[1]-A[0];
		for(int i=1;i<n-1;i++) {
			int j=i+1;
			int temp=A[j]-A[i];
			min=min<temp?min:temp;
		}
		
		for(int i=min;i>=1;i--) {
			if(check(i,A)) {
				min=i;
				break;
			}
		}
		int k=(A[A.length-1]-A[0])/min;
		System.out.println(k+1);
	}
	
	/**
	 * �ж��ǲ��ǹ���
	 * @param n	����
	 * @param A	Ҫ�жϵ�����
	 * @return		�Ƿ������еĹ���
	 */
	public static boolean check(int n,int[] A) {
		for(int i=1;i<A.length;i++) {
			if((A[i]-A[0])%n!=0) return false;
		}
		return true;
	}
}
