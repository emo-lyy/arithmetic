package ��ʮ��ʡ��;

import java.util.ArrayList;
import java.util.Scanner;

public class �����и� {
	static ArrayList<Integer> A=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		scanner.close();
		dfs(a,b);
		for(int i=0;i<A.size();i++) {
			System.out.println(A.get(i)+" "+A.get(i));
		}
		System.out.println("�ܹ���:"+A.size()+"��");
	}
	public static void dfs(int a,int b) {
		if(a==b) {
			A.add(a);
			return;
		}
		else {
			if(a<b) {
				int temp=a;
				a=b;
				b=temp;
			}
			dfs(a-b,b);
			A.add(b);
		}
	}
}
