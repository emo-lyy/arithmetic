package ��ʮ��ʡ��;

import java.util.Scanner;

public class ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		f(n);
	}
	public static void f(int n) {
		int temp=0;
		for(int i=2;i<10000000;i++) {
			if(n==0)break;
			if(check(i)) {
				System.out.println(i);
				temp=i;
				n--;
			}
		}
		System.out.println("���Ϊ��"+temp);
	}
	public static boolean check(int n) {
		for(int i=2;i<n;i++) {
			if(n%i==0)return false;
		}
		return true;
	}
}
