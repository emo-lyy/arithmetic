package ��ʮ��ʡ��;

import java.util.ArrayList;
import java.util.Scanner;

public class ��ͬ�ִ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		ArrayList<String> list=new ArrayList<>();
		for(int i=1;i<=s.length();i++) {
			for(int j=0;j<=s.length()-i;j++) {
				String temp=s.substring(j, j+i);
				if(!list.contains(temp))list.add(temp);
			}
		}
		for (String string : list) {
			System.out.println(string);
		}
		System.out.println("----------------------");
		System.out.println(list.size());
	}
	
	
}
