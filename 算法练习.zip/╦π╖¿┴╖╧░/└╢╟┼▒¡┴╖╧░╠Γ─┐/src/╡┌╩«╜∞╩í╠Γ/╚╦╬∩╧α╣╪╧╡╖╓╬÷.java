package ��ʮ��ʡ��;

import java.util.Scanner;

public class �������ϵ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int K=scanner.nextInt();
		scanner.nextLine();	//���ڽ���ԭ�ȵĻس�
		String s=scanner.nextLine();
		scanner.close();
		//System.out.println(s);
		String[] A=s.split("\\s+|\\.");
		/*for (String string : A) {
			System.out.println(string);
		}*/
		
		int res=0;
		 //    Alice------>Bob
        for(int i=0;i<A.length;i++){
            if(A[i].equals("Alice")){
                for(int j=i+1;j<A.length;j++){
                    if(A[j].equals("Bob")){
                        int sum=1;    //����Ҫ����1
                        for(int k=i+1;k<j;k++){
                            sum+=A[k].length()+1;
                        }
                        if(sum<=K){
                            res++;
                        }
                    }
                }
            }
        }
        
        //Bob--------->Alice
        for(int i=0;i<A.length;i++){
            if(A[i].equals("Bob")){
                for(int j=i+1;j<A.length;j++){
                    if(A[j].equals("Alice")){
                        int sum=1;    //����Ҫ����1
                        for(int k=i+1;k<j;k++){
                            sum+=A[k].length()+1;
                        }
                        if(sum<=K){
                            res++;
                        }
                    }
                }
            }
        }
        System.out.println(res);
	}
}
