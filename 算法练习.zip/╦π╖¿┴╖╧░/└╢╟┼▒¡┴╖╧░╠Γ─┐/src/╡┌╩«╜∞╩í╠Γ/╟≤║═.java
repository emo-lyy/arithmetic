package ��ʮ��ʡ��;

import java.util.Scanner;

public class ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		long sum=0;
		for(int i=1;i<=n;i++) {
			char[] temp=(i+"").toCharArray();
			for (char c : temp) {
				if(c=='2' || c=='0' || c=='1' || c=='9') {
					sum+=i;
					break;
				}
			}
		}
		System.out.println(sum);
	}
}
