package ģ����Զ�;

import java.util.Scanner;

public class �ྻ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int count=0;
		for(int i=1;i<=n;i++) {
			String[] data=(i+"").split("");
			if(check(data)) {
				count++;
			}
		}
		System.out.println(count);
	}
	
	public static boolean check(String[] data) {
		for (String s : data) {
			if(s.equals("2"))return false;
		}
		return true;
	}
}
