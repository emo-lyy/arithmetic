package ģ����Զ�;

public class ���� {
	public static void main(String[] args) {
		//System.out.println(check(2,3));
		int count=0;
		for(int i=1;i<=19000;i++) {
			if(check(i,19000)) {
				count++;
				System.out.println(i);
			}
		}
		System.out.println(count);
	}
	
	public static boolean check(int a,int b) {
		int max=0;
		for(int i=1;i<=a;i++) {
			if(a%i==0 && b%i==0) {
				max=i;
			}
		}
		if(max==1)return true;
		else return false;
	}
}
