package ģ����Զ�;

import java.util.Scanner;

public class ��ľ�Ǳ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		int[][] data=new int[n][m];
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				data[i][j]=scanner.nextInt();
			}
		}
		int h=scanner.nextInt();
		scanner.close();
		f(data,h,n,m);
	}
	
	public static void f(int[][] data,int h,int n,int m) {
		int temp=0;
		for(int i=0;i<h;i++) {
			int res=t(data,n,m);
			int out=temp+res;
			temp+=res;
			System.out.println(out);
		}
	}
	
	public static int t(int[][] data,int n,int m) {
		int count=0;
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				if(data[i][j]>=1) {
					count++;
					data[i][j]--;
				}
			}
		}
		return count;
	}
}
