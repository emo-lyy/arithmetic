package ģ����Զ�;

public class ���Լ�� {
	public static void main(String[] args) {
		long a=70044;
		long b=113148;
		int max=0;
		for(int i=1;i<=70044;i++) {
			if(a%i==0 && b%i==0) {
				max=i;
			}
		}
		System.out.println(max);
	}
}
