package ģ����Զ�;

import java.util.ArrayList;
import java.util.Scanner;

public class ͳ��Ԫ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		f(s);
	}
	public static void f(String s) {
		ArrayList<String> box=new ArrayList<>();
		addData(box);
		/*for (String S : box) {
			System.out.println(S);
		}*/
		long temp1=0;
		long temp2=0;
		String[] data=s.split("");
		for (String str : data) {
			if(box.contains(str))temp1++;
			else temp2++;
		}
		System.out.println(temp1);
		System.out.println(temp2);
	}
	
	public static void addData(ArrayList<String> box) {
		box.add("a");
		box.add("e");
		box.add("i");
		box.add("o");
		box.add("u");
	}
}
