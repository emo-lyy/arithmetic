package ģ����Զ�;

import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		f(data);
	}
	
	public static void f(int[] data) {
		int index=0;
		int maxLen=0;
		for(int i=index;i<data.length-1;i++) {
			if(data[i]<data[i+1]) {
				int temp=i;
				int begin=i+1;
				while(begin<data.length-1) {
					if(data[begin]<data[begin+1]) {
						index=begin;
						begin++;
					}
					else {
						break;
					}
					maxLen=(maxLen>(begin-temp+1))?maxLen:(begin-temp+1);
				}
			}
		}
		System.out.println(maxLen);
	}
}
