package ģ����Զ�;

import java.util.ArrayList;
import java.util.Scanner;

public class ��ľ�Ǳ��� {
	static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		ArrayList<ArrayList<Integer>> data=new ArrayList<>();
		for(int i=0;i<n;i++) {
			ArrayList<Integer> temp=new ArrayList<>();
			for(int j=0;j<m;j++) {
				int a=scanner.nextInt();
				if(a!=0) {
					temp.add(a);
				}
			}
			data.add(temp);
		}
		int h=scanner.nextInt();
		scanner.close();
		f(data,h);
	}
	
	public static void f(ArrayList<ArrayList<Integer>> data,int h) {
		ArrayList<ArrayList<Integer>> temp=data;
		for(int i=0;i<h;i++) {
			temp=t(temp);
		}
	}
	
	public static ArrayList<ArrayList<Integer>> t(ArrayList<ArrayList<Integer>> data){
		ArrayList<ArrayList<Integer>> res=new ArrayList<>();
		for(int i=0;i<data.size();i++) {
			ArrayList<Integer> box=data.get(i);
			//System.out.println(box);
			ArrayList<Integer> temp=new ArrayList<>();
			for(int j=0;j<box.size();j++) {
				int n=box.get(j);
				if(n>0) {
					count++;
					temp.add(n-1);
				}
			}
			res.add(temp);
		}
		System.out.println(count);
		return res;
	}
}
