package ģ����Զ�;

import java.util.Scanner;

public class ���Ԫ�ؾ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		f(data);
	}
	public static void f(int[] data) {
		int max=0;
		for(int i=0;i<data.length;i++) {
			for(int j=i+1;j<data.length;j++) {
				//System.out.print(data[i]+" "+data[j]+"    ");
				int a=data[j]-data[i];
				int res1=res(a);
				int b=j-i;
				int res2=res(b);
				//System.out.print(res1+" "+res2+"    ");
				int sum=res1+res2;
				max=(max>sum)?max:sum;
			}
			//System.out.println();
		}
		System.out.println(max);
	}
	
	public static int res(int n) {
		if(n<0)return -n;
		return n;
	}
}
