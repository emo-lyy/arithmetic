package �㷨���;

import java.util.Arrays;
import java.util.Scanner;

public class �������� {
	static int n;
	static int[] A;
	public static void main(String[] args) {
		inputData();
		f();
	}
	static void f() {
		Arrays.sort(A);
		for(int i=n-1;i>=0;i--) {
			System.out.print(A[i]+" ");
		}
	}
	
 	static void inputData(){
 		Scanner scanner=new Scanner(System.in);
 		n=scanner.nextInt();
 		A=new int[n];
 		for(int i=0;i<n;i++)A[i]=scanner.nextInt();
 		scanner.close();
 	}
}
