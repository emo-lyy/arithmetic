package �㷨���;

import java.util.Scanner;

public class �����Сֵ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] A=new int[n];
		for(int i=0;i<n;i++)A[i]=scanner.nextInt();
		scanner.close();
	}
	static void f(int[] A) {
		int max=A[0];
		int min=A[0];
		for (int i : A) {
			max=max>i?max:i;
			min=min<i?min:i;
		}
		System.out.println(max);
		System.out.println(min);
	}
}
