package �㷨���;

import java.util.Scanner;

public class ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		scanner.close();
		System.out.println(n+m);
	}
}
