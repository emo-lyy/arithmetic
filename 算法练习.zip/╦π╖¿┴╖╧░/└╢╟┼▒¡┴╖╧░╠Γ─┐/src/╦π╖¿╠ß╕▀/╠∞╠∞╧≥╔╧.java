package �㷨���;

import java.util.ArrayList;
import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close(); 
		
	}
	
	//�����ƽ�
	public static void f(int[] data) {
		long count=0;
		for(int a=0;a<data.length;a++) {
			for(int b=a+1;b<data.length;b++) {
				for(int c=b+1;c<data.length;c++) {
					for(int d=c+1;d<data.length;d++) {
						if(data[a]<data[b] && data[b]<data[c] && data[c]<data[d]) {
							count++;
						}
					}
				}
			}
		}
		System.out.println(count);
	}
}
