package �㷨���;

import java.util.Scanner;

public class Լ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int res=f(n);
		System.out.println(res);
	}
	static int f(int n) {
		int count=0;
		for(int i=1;i<=n;i++) {
			if(n%i==0)count++;
		}
		return count;
	}
}
