package �㷨���;

import java.util.Scanner;

//˼· �����ִ��ۼ�ȥ�и�
public class �����ִ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		char[] A=s.toCharArray();
		String k="";
		for(int i=0;i<A.length;i++) {
			k+=A[i];
			if(s.split(k).length==0) {
				System.out.println(k.length());
				break;
			}
		}
		
	}
	static void out(String[] A) {
		for (String s : A) {
			System.out.print(s+" ");
		}
		System.out.println();
		
	}
}
