package �㷨���;

import java.util.ArrayList;
import java.util.Scanner;

public class ��������״���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		ArrayList<Integer> data=new ArrayList<>();
		for(int i=1;i<=n;i++)	data.add(scanner.nextInt());
		for(int i=0;i<m;i++) {
			String s=scanner.next();
			if(s.equals("DEL")) {
				int k=scanner.nextInt();
				for(int j=0;j<data.size();j++) {
					if(data.get(j)==k) {
						data.remove(j);
						break;
					}
				}
			}
			else {
				int a=scanner.nextInt();
				int b=scanner.nextInt();
				ArrayList<Integer> temp=new ArrayList<>();
				for(int j=0;j<data.size();j++) {
					if(data.get(j)==a) {
						temp.add(b);
						temp.add(data.get(j));
					}else {
						temp.add(data.get(j));
					}
				}
				data=temp;
			}
		}
		scanner.close();
		System.out.println(data.size());
		for (Integer i : data) {
			System.out.print(i+" ");
		}
	}
}
