package �㷨���;

import java.util.ArrayList;
import java.util.Scanner;

public class ����2 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		ArrayList<Integer> A=new ArrayList<>();
		for(int i=2;i<n;i++) {
			if(check(i)) {
				A.add(i);
			}
		}
		System.out.println(A.size());
		out(A);
	}
	static boolean check(int n) {
		for(int i=2;i<=Math.sqrt(n);i++) {
			if(n%i==0)return false;
		}
		return true;
	}
	static void out(ArrayList<Integer> A){
		for (Integer i : A) {
			System.out.print(i+" ");
		}
	}
}
