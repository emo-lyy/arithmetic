package �㷨���;

public class Dome01 {
	public static void main(String[] args) {
		int i=19;
		digui(i);
		
	}
	static void digui(int n) {
		if(n==9) return;
		System.out.println(n);
		digui(n-1);
	}
}
