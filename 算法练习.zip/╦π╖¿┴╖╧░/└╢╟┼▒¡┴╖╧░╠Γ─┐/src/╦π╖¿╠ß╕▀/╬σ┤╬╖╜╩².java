package �㷨���;

public class ��η��� {
	public static void main(String[] args) {
		for(int i=10;i<10000000;i++) {
			String s=i+"";
			long sum=0;
			String[] data=s.split("");
			for (String k : data) {
				sum+=Math.pow(Integer.valueOf(k), 5);
			}
			if(sum==i) {
				System.out.println(i);
			}
		}
	}
}
