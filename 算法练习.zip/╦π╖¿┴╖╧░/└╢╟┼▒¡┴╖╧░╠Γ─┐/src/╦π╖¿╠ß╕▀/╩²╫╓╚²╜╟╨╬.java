package �㷨���;

import java.util.Scanner;

public class ���������� {
	static int n;
	static int[][] A;
	static int max=0;
	public static void main(String[] args) {
		inputData();
		dfs(A,0,0,A[0][0],A[0][0]+"");
		System.out.println(max);
	}
	
	static void dfs(int[][] A,int x,int y,int sum,String s) {
		if(x==A.length-1) {
			max=max>sum?max:sum;
			//System.out.println(s+"="+sum);
			return;
		}
		else {
			 dfs(A,x+1,y,sum+A[x+1][y],s+("+"+A[x+1][y]));
			 dfs(A,x+1,y+1,sum+A[x+1][y+1],s+("+"+A[x+1][y+1]));
		}
	}
	
	static void inputData() {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new int[n][n];
		for(int i=0;i<n;i++)
			for(int j=0;j<=i;j++)
				A[i][j]=scanner.nextInt();
		scanner.close();
	}
	
	static void out(int[][] A) {
		for(int i=0;i<A.length;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
}
