package �㷨���;

import java.util.ArrayList;
import java.util.Scanner;

public class ������ {
	private static ArrayList<Integer> temp=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		f(n);
		System.out.println(temp.size());
		for (Integer i : temp) {
			System.out.print(i+" ");
		}
	}
	public static void f(int n) {
		for(int i=2;i<n;i++) {
			if(check(i)) {
				temp.add(i);
			}
		}
	}
	public static boolean check(int n) {
		for(int i=2;i<n;i++) {
			if(n%i==0)return false;
		}
		return true;
	}
}
