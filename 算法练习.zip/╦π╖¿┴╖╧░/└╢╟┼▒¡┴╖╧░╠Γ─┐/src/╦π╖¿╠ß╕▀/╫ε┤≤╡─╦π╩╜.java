package 算法提高;

import java.util.Scanner;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

//未考虑 A数组的 元数值为负数的情况
public class 最大的算式 {
	static int n,k;
	static int[] A;
	static int max=0;
	public static void main(String[] args) {
		inputData();
		dfs(A,k,1,A[0]+"");
		System.out.println(max);
	}
	static void dfs(int[] A,int k,int index,String s) {
		if(index==A.length) {
			if(k==0) {
				String[] S=s.split("\\*");
				int sum=1;
				ScriptEngineManager manager = new ScriptEngineManager();		//可执行化脚本
				ScriptEngine engine = manager.getEngineByExtension("js");			//获取脚本
				for (String str : S) {
					try {
						int temp=(int)engine.eval(str);							//执行脚本内容
						sum*=temp;
					} catch (ScriptException e) {e.printStackTrace();}
				}
				max=max>sum?max:sum;
			}
			return;
		}
		if(k==0) {
			dfs(A,k,index+1,s+("+"+A[index]));
		}
		else {
			dfs(A,k-1,index+1,s+("*"+A[index]));
			dfs(A,k,index+1,s+("+"+A[index]));
		}
	}
	
	static void inputData() {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		k=scanner.nextInt();
		A=new int[n];
		for(int i=0;i<n;i++)A[i]=scanner.nextInt();
		scanner.close();
	}
	
	static void out(String[] S) {
		for (String s : S) {
			System.out.print(s+" ");
		}
		System.out.println();
	}
}
