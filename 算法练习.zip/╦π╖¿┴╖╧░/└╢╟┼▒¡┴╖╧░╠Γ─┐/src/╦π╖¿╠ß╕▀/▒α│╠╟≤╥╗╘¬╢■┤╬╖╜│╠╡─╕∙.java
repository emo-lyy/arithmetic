package �㷨���;

import java.util.Scanner;

//��ʽ��
public class �����һԪ���η��̵ĸ� {
	static int k;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		int c=scanner.nextInt();
		scanner.close();
		k=b*b-4*a*c;	//�õ� ��
		if(k<0)System.out.println("No");
		else {
			double x1=x1(a,b,c);
			double x2=x2(a,b,c);
			if(x1==x2)System.out.println(x1);
			else System.out.println(x2+" "+x1);
		}
	}
	
	static double x1(int a,int b,int c) {
		return (-b-Math.sqrt(k))/2*a;
	}
	static double x2(int a,int b,int c) {
		return (-b+Math.sqrt(k))/2*a;
	}
}
