package �㷨���;

import java.util.Scanner;

public class �򵥼ӷ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		long sum=0l;
		for(int i=1;i<n;i++) {
			if(i%3==0 || i%5==0)sum+=i;
		}
		System.out.println(sum);
	}
}
