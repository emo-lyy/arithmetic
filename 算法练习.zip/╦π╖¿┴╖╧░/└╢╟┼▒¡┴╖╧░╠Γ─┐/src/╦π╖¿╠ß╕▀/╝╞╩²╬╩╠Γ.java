package �㷨���;

import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String x=scanner.next();
		scanner.close();
		int count=0;
		for(int i=1;i<=n;i++) {
			String s=i+"";
			if(s.contains(x)) {
				for(int j=0;j<s.length();j++) {
					if((s.charAt(j)+"").equals(x))count++;
				}
			}
		}
		System.out.println(count);
	}
}
