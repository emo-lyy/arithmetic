package �㷨���;

import java.util.Scanner;

public class ����ת�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		Integer temp=Integer.parseInt(s,16);
		String a=Integer.toString(temp, 16).toUpperCase();
		Integer b=Integer.parseInt(s, 16);
		String c=Integer.toString(b, 8);
		System.out.println(a+" "+b+" "+c);
	}
}
