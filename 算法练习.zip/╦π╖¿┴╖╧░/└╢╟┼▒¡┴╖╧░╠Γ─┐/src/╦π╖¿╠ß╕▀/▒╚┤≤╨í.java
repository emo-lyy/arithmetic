package �㷨���;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class �ȴ�С {
	public static void main(String[] args) {
		//System.out.println(check("aab","bbc"));
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String[] data=new String[n];
		ArrayList<String> temp=new ArrayList<>();
		for(int i=0;i<n;i++) {
			data[i]=scanner.next();
			if(!temp.contains(data[i]))temp.add(data[i]);
		}
		scanner.close();
		Map<String, Integer> map=new HashMap<>();
		for (String s1 : temp) {
			int count=0;
			for(String s2 : data) {
				if(s1.equals(s2)) {
					count++;
				}
			}
			map.put(s1, count);
		}
			
		ArrayList<String> res=f(temp);
		for (String s : res) {
			System.out.println(s+" "+map.get(s));
		}
		
	}
	
	public static ArrayList<String> f(ArrayList<String> data) {
		//System.out.println(data);
		for(int i=0;i<data.size()-1;i++) {
			for(int j=i+1;j<data.size()-1-i;j++) {
				String s1=data.get(i);
				String s2=data.get(j);
			//	System.out.println(s1);
			//	System.out.println(s2);
				if(check(s1,s2)==false) {
					String temp=data.get(i);
					data.set(i, data.get(j));
					data.set(j, temp);
				}
			}
		}
		return data;
	}
	
	//��� s1���ֵ����� s2ǰ�淵�� true
	public static boolean check(String s1,String s2) {
		if(s1.equals(s2))return false;
		int len1=s1.length();
		int len2=s2.length();
		int len=(len1>len2)?len1:len2;
		char[] temp1=new char[len];
		char[] temp2=new char[len];
		for(int i=0;i<len1;i++) {
			temp1[i]=s1.charAt(i);
		}
		for(int j=0;j<len2;j++) {
			temp2[j]=s2.charAt(j);
		}
		for(int k=0;k<len;k++) {
			if((int)temp1[k]<(int)temp2[k])return true;
			if((int)temp1[k]>(int)temp2[k])return false;
		}
		return true;
	}
	
}
