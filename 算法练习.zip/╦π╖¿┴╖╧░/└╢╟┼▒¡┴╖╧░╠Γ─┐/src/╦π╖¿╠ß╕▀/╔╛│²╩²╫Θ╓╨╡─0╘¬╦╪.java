package �㷨���;

import java.util.ArrayList;
import java.util.Scanner;

public class ɾ�������е�0Ԫ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		ArrayList<Integer> box=new ArrayList<>();
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
			if(data[i]!=0) {
				box.add(data[i]);
			}
		}
		scanner.close();
		for (Integer i : box) {
			System.out.print(i+" ");
		}
		System.out.println("\n"+box.size());
	}
}
