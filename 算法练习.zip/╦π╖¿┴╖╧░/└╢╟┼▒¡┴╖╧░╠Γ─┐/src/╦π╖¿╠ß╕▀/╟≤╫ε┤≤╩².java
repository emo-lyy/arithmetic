package �㷨���;

import java.util.Scanner;

public class ������� {
	static int[] A=new int[10];
	static int max=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		for(int i=0;i<10;i++)A[i]=scanner.nextInt();
		scanner.close();
		f();
		System.out.println(max);
	}
	static void f() {
		for (int i : A) {
			max=max>i?max:i;
		}
	}
}
