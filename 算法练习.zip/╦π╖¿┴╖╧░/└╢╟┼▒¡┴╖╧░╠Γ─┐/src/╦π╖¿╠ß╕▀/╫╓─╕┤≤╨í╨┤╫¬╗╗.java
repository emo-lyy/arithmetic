package �㷨���;

import java.util.Scanner;

public class ��ĸ��Сдת�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] data=scanner.next().toCharArray();
		scanner.close();
		String res=f(data[0]);
		System.out.println(res);
	}
	
	public static String f(char data) {
		if('a'<=data && data<='z') {
			return (data+"").toUpperCase();
		}
		else if('A'<=data && data<='Z') {
			return (data+"").toLowerCase();
		}
		else {
			return (data+"");
		}
	}
}
