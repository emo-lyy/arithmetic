package �㷨���;

import java.util.Scanner;

public class ��д��������x��y�η� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		double x=scanner.nextDouble();
		double y=scanner.nextDouble();
		scanner.close();
		double res=pow(x,y);
		System.out.println(res);
	}
	
	public static double pow( double x, double y) {
		double res=1;
		for(int i=0;i<y;i++) {
			res*=x;
		}
		return res;
	}
}
