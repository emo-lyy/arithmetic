package �㷨���;

import java.util.Scanner;

public class ����֤�������� {
	static char[] A="10x98765432".toCharArray();
	static int[] B= {7, 9 ,10, 5, 8, 4 ,2, 1 ,6 ,3, 7, 9, 10, 5 ,8 ,4 ,2};
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		String s1=s.substring(0,6);
		String s2=s.substring(6, 15);
		String S=s1+"19"+s2;
		String[] K=S.split("");
		int sum=0;
		for(int i=0;i<K.length;i++) {
			sum+=Integer.valueOf(K[i])*B[i];
		}
		int index=sum%11;
		S+=A[index];
		System.out.println(S);
	}
}
