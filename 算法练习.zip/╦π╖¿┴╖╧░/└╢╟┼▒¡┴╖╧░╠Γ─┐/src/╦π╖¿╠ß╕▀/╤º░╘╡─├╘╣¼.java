package �㷨���;

import java.util.ArrayList;
import java.util.Scanner;

public class ѧ�Ե��Թ� {
	static int n,m;
	static int[][] A;
	static String res="";
	static char[] C={'U','D','L','R'};
	static boolean b=false;
	public static void main(String[] args) {
		inputData();
		dfs(0,0,new ArrayList<>(),A);
		System.out.println(res.length());
		System.out.println(res);
	}
	
	/**
	 * �߹���·��ʶΪ-1
	 * @param x	��ǰ��x����
	 * @param y	��ǰ�� y����
	 * @param S	·��
	 */
	static void dfs(int x,int y,ArrayList<String> S,int[][] A) {
		if(x==n-1 && y==m-1) {
			String temp="";
			for (String s : S) {
				temp+=s;
			}
			System.out.println(temp);
			if(b) {
				if(check(temp))res=temp;
			}
			else {
				res=temp;
				b=true;
			}
			return;
		}
		int temp=A[x][y];
		A[x][y]=-1;
		//top	
		if(x-1>=0 && A[x-1][y]==0) {
			S.add(C[0]+"");
			dfs(x-1,y,S,A);
			S.remove(S.size()-1);	//����
		}
		//bottom
		if(x+1<n && A[x+1][y]==0) {
			S.add(C[1]+"");
			dfs(x+1,y,S,A);
			S.remove(S.size()-1);	//����
		}
		//left
		if(y-1>=0 && A[x][y-1]==0) {
			S.add(C[2]+"");
			dfs(x,y-1,S,A);
			S.remove(S.size()-1);	//����
		}
		//right
		if(y+1<m && A[x][y+1]==0) {
			S.add(C[3]+"");
			dfs(x,y+1,S,A);
			S.remove(S.size()-1);	//����
		}
		A[x][y]=temp;		//����
	}
	
	static void inputData() {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		String[] s=new String[n];
		for(int i=0;i<n;i++)
			s[i]=scanner.next();
		scanner.close();
		for(int i=0;i<n;i++) {
			String k=s[i];
			for(int j=0;j<m;j++) {
				A[i][j]=Integer.valueOf(k.charAt(j)+"");
			}
		}
	}
	
	static boolean check(String s) {
		if(s.length()>res.length())return false;
		if(s.length()<res.length())return true;
		for(int i=0;i<s.length();i++) {
			int a=(int)s.charAt(i);
			int b=(int)res.charAt(i);
			if(a>b) return false;
			if(a<b) return true;
		}
		return true;
	}	
	
}
