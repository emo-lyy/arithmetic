package �㷨���;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class �ִ�ͳ�� {
	static int resLen=0;		//�ַ����ĳ���
	static String res="";		//�ַ���
	static int resCount=0;		//�ַ������ֵĴ���
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int l=scanner.nextInt();
		String s=scanner.next();
		scanner.close();
		
		ArrayList<String> A=new ArrayList<>();
		Set<String> S=new HashSet<>();
		for(int i=0;i<s.length();i++) {
			for(int j=l;i+j<s.length();j++) {
				String temp=s.substring(i,i+j);
				A.add(temp);
				S.add(temp);
			}
		}
		
		for (String string : S) {
			int count=Collections.frequency(A, string);
			if(count>resCount) {						//�жϳ��ִ���
				res=string;
				resLen=string.length();
				resCount=count;
			}
			else if(count==resCount) {					//���ִ�����ͬ
				if(string.length()>resLen) {			//�жϳ���
					res=string;
					resLen=string.length();
				}
			}
		}
		System.out.println(res);
	}
}
