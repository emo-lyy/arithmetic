package �㷨���;

import java.util.Scanner;

public class ��������Ʊ�ʾ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		String s=Integer.toString(n, 2);
		for(int i=s.length();i<8;i++) {
			s="0"+s;
		}
		System.out.println(s);
	}
}
