package �㷨���;

import java.util.Scanner;

public class ��д�������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int x=scanner.nextInt();
		int y=scanner.nextInt();
		scanner.close();
		int res=power(x, y);
		System.out.println(res);
	}
	static int power(int x,int y) {
		return (int)Math.pow(x, y);
	}
}
