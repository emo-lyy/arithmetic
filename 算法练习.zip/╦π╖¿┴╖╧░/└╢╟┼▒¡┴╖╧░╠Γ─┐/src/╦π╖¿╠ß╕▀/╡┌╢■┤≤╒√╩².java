package �㷨���;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class �ڶ������� {
	public static void main(String[] args) {
		ArrayList<Integer> A=new ArrayList<>();
		Scanner scanner=new Scanner(System.in);
		while(scanner.hasNext()) {
			int check=scanner.nextInt();
			if(check!=0)A.add(check);
			else break;
		}
		scanner.close();
		//out(A);				 �������
		Collections.sort(A);
		System.out.println(A.get(A.size()-2));
	}
	
	static void out(ArrayList<Integer> A) {
		for (Integer i : A) {
			System.out.print(i+" ");
		}
	}
}
