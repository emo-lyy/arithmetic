package ����;

import java.util.Scanner;

public class ǰ׺����ʽ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String[] box=scanner.nextLine().split("\\s+");
		scanner.close();
		String operation=box[0];
		int[] data=new int[box.length-1];
		for(int i=0;i<data.length;i++) {
			data[i]=Integer.valueOf(box[i+1]);
		}
	/*	System.out.println("�������:"+operation);
		System.out.println("������:");
		for (int i : data) {
			System.out.print(i+" ");
		}*/
		
		if(operation.equals("+")) {
			int temp=0;
			for (int i : data) {
				temp=temp+i;
			}
			System.out.println(temp);
		}
		else if(operation.equals("*")) {
			int temp=1;
			for (int i : data) {
				temp=temp*i;
			}
			System.out.println(temp);
		}
		else if(operation.equals("-")) {
			int temp=data[0];
			for (int i = 1; i < data.length; i++) {
				temp=temp-data[i];
			}
			System.out.println(temp);
		}
		else {
			int temp=data[0];
			for (int i = 1; i < data.length; i++) {
				temp=temp/data[i];
			}
			System.out.println(temp);
		}
	}
}
