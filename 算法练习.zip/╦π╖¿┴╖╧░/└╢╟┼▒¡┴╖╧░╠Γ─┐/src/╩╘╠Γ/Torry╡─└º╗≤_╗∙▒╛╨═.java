package ����;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;

public class Torry������_������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		ArrayList<Integer> list=new ArrayList<>();
		for(int i=1;i<=50000;i++) {
			for(int j=2;j<=i;j++) {
				if(i==j) {
					list.add(i);
				}
				if(i%j==0) {
					break;
				}
			}
		}
		
		/*for (Integer i : list) {
			System.out.println(i);
		}*/
		
		long sum=(long)1;
		for(int i=0;i<n;i++) {
			sum*=list.get(i);
		}
		System.out.println(sum%50000);
	}
}
