package ����;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class HashMap������ʹ�ö� {
	public static void main(String[] args) {
		Map<String,Student[]> map=new HashMap<>();
		Scanner scanner=new Scanner(System.in);
		System.out.println("����������һ����Ա��Ϣ(�ֱ��Կո�ָ� ѧ�š��������Ա�����):");
		Student[] student1=new Student[2];
		for(int i=0;i<2;i++) {
			student1[i]=new Student(scanner.next(),scanner.next(),scanner.next().charAt(0),scanner.nextInt());
		}
		map.put("1801", student1);
		
		System.out.println("����������������Ա��Ϣ(�ֱ��Կո�ָ� ѧ�š��������Ա�����):");
		Student[] student2=new Student[2];
		for(int i=0;i<2;i++) {
			student2[i]=new Student(scanner.next(),scanner.next(),scanner.next().charAt(0),scanner.nextInt());
		}
		map.put("1802", student2);
		scanner.close();
		
		System.out.println("----------------------------------");
		
		Set<String> grend=map.keySet();
		for (String S : grend) {
			System.out.println("�ƶ�"+S+"��:");
			Student[] temp=map.get(S);
			for(int i=0;i<temp.length;i++) {
				String studentNumebr=temp[i].getStudentNumebr();
				String name=temp[i].getName();
				char sex=temp[i].getGrend();
				int age=temp[i].getAge();
				System.out.println("\t"+"ѧ��:"+studentNumebr+"  ����:"+name+"  �Ա�:"+sex+"  ����:"+age);
			}
		}
	}
	
	public static class Student{
		private String studentNumebr;
		private String name;
		private char grend;
		private int age;
		/**
		 * @return the studentNumebr
		 */
		public String getStudentNumebr() {
			return studentNumebr;
		}
		/**
		 * @param studentNumebr the studentNumebr to set
		 */
		public void setStudentNumebr(String studentNumebr) {
			this.studentNumebr = studentNumebr;
		}
		/**
		 * @return the name
		 */
		public String getName() {
			return name;
		}
		/**
		 * @param name the name to set
		 */
		public void setName(String name) {
			this.name = name;
		}
		/**
		 * @return the grend
		 */
		public char getGrend() {
			return grend;
		}
		/**
		 * @param grend the grend to set
		 */
		public void setGrend(char grend) {
			this.grend = grend;
		}
		/**
		 * @return the age
		 */
		public int getAge() {
			return age;
		}
		/**
		 * @param age the age to set
		 */
		public void setAge(int age) {
			this.age = age;
		}
		
		
		public Student() {}
		public Student(String studentNumebr, String name, char grend, int age) {
			super();
			this.studentNumebr = studentNumebr;
			this.name = name;
			this.grend = grend;
			this.age = age;
		}
		
	}
}
