package ����;

import java.util.Scanner;

public class ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String a=scanner.next();
		String b=scanner.next();
		scanner.close();
		
		//����һ
		/*int a_index=a.length()-1;
		int b_index=b.length()-1;
		
		//System.out.println(a_index+" "+b_index);
		
		String str1="";
		while(a_index>=0) {
			//System.out.print(a.charAt(a_index)+" ");
			str1+=a.charAt(a_index);
			a_index--;
		}
		int data1=Integer.valueOf(str1);
		
		String str2="";
		while(b_index>=0) {
			str2+=b.charAt(b_index);
			b_index--;
		}
		int data2=Integer.valueOf(str2);
		
		String str3=(data1+data2)+"";
		int c_index=str3.length()-1;
		while(c_index>=0) {
			System.out.print(str3.charAt(c_index));
			c_index--;
		}*/
		
		
		//������
		int data1=f(a);
		int data2=f(b);
		System.out.println(f(data1+data2+""));
		
	}
	
	public static int f(String str) {
		int index=str.length()-1;
		String temp="";
		while(index>=0) {
			temp+=str.charAt(index);
			index--;
		}
		
		return Integer.valueOf(temp);
	}
}	
