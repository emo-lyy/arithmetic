package ����;

import java.util.Scanner;

public class P0505 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		//System.out.println(factorial(n));
		char[] str=factorial(n).toString().toCharArray();
		int length=str.length-1;
		If(str,length);
		scanner.close();
	}
	
	public static Long factorial(int n) {
		Long nFactorial=(long) 1;
		
		for(int i=2;i<=n;i++) {
			nFactorial=nFactorial*i;
			if(nFactorial % 10 == 0){	
				nFactorial /= 10;
				nFactorial = nFactorial % 10000;
			}			
		}
		return nFactorial;
	}
	
	public static void If(char[] data,int length) {
		if(data[length]=='0') {
			If(data,length-1);
		}
		else {
			System.out.println(data[length]);
		}
	}
}
