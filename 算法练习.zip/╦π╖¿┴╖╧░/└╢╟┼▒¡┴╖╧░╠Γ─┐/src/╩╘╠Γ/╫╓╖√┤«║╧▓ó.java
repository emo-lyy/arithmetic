package ����;

import java.util.Scanner;

public class �ַ����ϲ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String a=scanner.next();
		String b=scanner.next();
		System.out.println(a+b);
		scanner.close();
	}
}
