package ����;

import java.util.ArrayList;
import java.util.Scanner;

public class ɾ�������е�0Ԫ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		ArrayList<Integer> temp=CompactIntegers(data);
		for (Integer i : temp) {
			System.out.print(i+" ");
		}
		System.out.println();
		System.out.println(temp.size());
	}
	
	public static ArrayList<Integer> CompactIntegers(int[] data) {
		ArrayList<Integer> temp=new ArrayList<>();
		for (int i : data) {
			if(i!=0) {
				temp.add(i);
			}
		}
		return temp;
	}
}
