package ����;

import java.util.Calendar;
import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int year=scanner.nextInt();
		int month=scanner.nextInt();
		int date=scanner.nextInt();
		scanner.close();
		int sum=0;
		Calendar c = Calendar.getInstance();
		for(int i=0;i<month-1;i++) {
			c.set(Calendar.YEAR, year);
			c.set(Calendar.MONTH, i);
			int temp=c.getActualMaximum(Calendar.DAY_OF_MONTH);
			sum+=temp;
		}
		System.out.println(sum+date);
	}
}
