package ����;

import java.util.Scanner;

public class �ַ���ƥ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String searchingStr=scanner.next();
		int If=scanner.nextInt();
		int n=scanner.nextInt();
		String[] data=new String[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.next();
		}
		scanner.close();
		if(If==0) {
			String str=searchingStr.toLowerCase();
			for(int i=0;i<n;i++) {
				String temp=data[i].toLowerCase();
				if(temp.indexOf(str)!=-1) {
					System.out.println(data[i]);
				}
			}
		}
		else if(If==1) {
			for(int i=0;i<n;i++) {
				if(data[i].indexOf(searchingStr)!=-1) {
					System.out.println(data[i]);
				}
			}
		}
	}
}
