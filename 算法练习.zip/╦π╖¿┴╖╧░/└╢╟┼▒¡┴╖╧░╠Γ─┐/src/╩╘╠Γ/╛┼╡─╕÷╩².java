package ����;

public class �ŵĸ��� {
	public static void main(String[] args) {
		int count=0;
		for(int i=1;i<=2019;i++) {
			char[] str=(i+"").toCharArray();
			for (char c : str) {
				if(c=='9') {
					System.out.println(i);
					count++;
					break;
				}
			}
		}
		System.out.println(count);
	}
}
