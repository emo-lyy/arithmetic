package ����;

public class �����Ʊ�ʾ����ʵ�� {
	public static void main(String[] args) {
		double n=0.25;
		StringBuffer sb=new StringBuffer("0.");
		while(n>0) {
			double r=n*2;
			if(r>=1) {
				sb.append("1");
				n=r-1;
			}
			else {
				sb.append("0");
				n=r;
			}
			if(sb.length()>34) {
				System.out.println("ERROR");
				return;
			}
		}
		System.out.println(sb.toString());
	}
}
