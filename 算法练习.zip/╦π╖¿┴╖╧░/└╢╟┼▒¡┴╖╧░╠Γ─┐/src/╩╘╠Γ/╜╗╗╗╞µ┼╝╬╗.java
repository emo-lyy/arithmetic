package ����;

public class ������żλ {
	public static void main(String[] args) {
		int n=6;
		int b=f(n);
		System.out.println(b);
	}
	
	public static int f(int n) {
		int ou=n&0xaaaaaaaa;
		
		int ji=n&0x55555555;
		return (ou>>1)^(ji<<1);
	}
}
