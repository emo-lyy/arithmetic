package ����;

import java.util.Scanner;

public class ��̬����ʹ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.nextLine();
		String[] box=scanner.nextLine().split("\\s+");
		scanner.close();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=Integer.valueOf(box[i]);
		}
		
		int sum=0;
		for (int i : data) {
			sum+=i;
		}
		int average=sum/n;
		System.out.println(sum+" "+average);
	}
}
