package ����;

import java.util.Scanner;

public class ������ {
	private static int max=0;
	private static int MAX=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=1;i<=n;i++) {
			int temp=f(i);
			MAX=(temp>MAX)?temp:MAX;
		}
		System.out.println(MAX);
	}
	
	public static int f(int n) {
		//System.out.print(n+" ");
		if(n==1) {
			return 0;
		}
		max=(n>max)?n:max;
			if(n%2==0) {
				f(n/2);
			}else {
				f(n*3+1);
			}
			
		return max;
		
	}
}
