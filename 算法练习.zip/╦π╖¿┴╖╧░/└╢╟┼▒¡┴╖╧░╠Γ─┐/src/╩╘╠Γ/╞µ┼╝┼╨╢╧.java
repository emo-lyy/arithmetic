package ����;

import java.util.Scanner;

public class ��ż�ж� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Long x=scanner.nextLong();
		scanner.close();
		
		if(x%2==0) {
			System.out.println("even");
		}
		else {
			System.out.println("odd");
		}
	}
}
