package ����;

import java.util.Scanner;

public class P0103 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String A=scanner.next();
		scanner.close();
		System.out.println(A.toLowerCase());
		//Сдת��д
//		String str="aaa";
//		System.out.println(str.toUpperCase());
	}
}
