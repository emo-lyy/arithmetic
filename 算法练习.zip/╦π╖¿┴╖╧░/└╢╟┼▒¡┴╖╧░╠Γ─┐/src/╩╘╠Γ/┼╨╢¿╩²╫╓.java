package ����;

import java.util.Scanner;

public class �ж����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char str=scanner.next().charAt(0);
		scanner.close();
		int n=(int)str;
		char data1='0';
		char data2='9';
		int min=(int)data1;
		int max=(int)data2;
		//System.out.println(n+" "+min+" "+max);
		if(min<=n && n<=max) {
			System.out.println("yes");
		}
		else{
			System.out.println("no");
		}
	}
}
