package ����;

import java.util.Scanner;

public class Anagrams���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str1=scanner.next();
		String str2=scanner.next();
		scanner.close();
		
		String str1ToLC=str1.toLowerCase();
		String str2ToLC=str2.toLowerCase();
		
		char[] data1=str1ToLC.toCharArray();
		char[] data2=str2ToLC.toCharArray();
		
		int length1=data1.length;
		int length2=data2.length;
		if(length1!=length2) {
			System.out.println("N");
		}
		else {
			boolean[] If=new boolean[length2];
			for(int i=0;i<length1;i++) {
				for(int j=0;j<length2;j++) {
					if((data1[i]+"").equals(data2[j]+"")) {
						if(! If[j]) {
							If[j]=true;
							break;
						}
					}
				}
			}
			
			String syso="Y";
			for (boolean b : If) {
				if(b==false) {
					syso="N";
					break;
				}
			}
			System.out.println(syso);
		}
	}
	
}
