package ����;

import java.util.Scanner;

public class �ַ���˳��Ƚ� {
	public static void main(String[] args) {
		char[] data1=new char[10000000];
		char[] data2=new char[10000000];
		Scanner scanner=new Scanner(System.in);
		String str1=scanner.next();
		String str2=scanner.next();
		scanner.close();
		char[] char1=str1.toCharArray();
		char[] char2=str2.toCharArray();
		addChar(char1,data1);
		addChar(char2,data2);
		if(str1.equals(str2)) {
			System.out.println(0);
		}
		else {
			f(data1,data2,0);
		}
	}
	
	public static void addChar(char[] car,char[] data) {
		for(int i=0;i<car.length;i++) {
			data[i]=car[i];
		}
		for(int j=car.length;j<data.length;j++) {
			data[j]='0';
		}
	}
	
	public static void f(char[] data1,char[] data2,int index) {
		int a=Integer.valueOf(data1[index]);
		int b=Integer.valueOf(data2[index]);
		if(a<b) {
			System.out.println(1);
		}
		else if(a>b) {
			System.out.println(-1);
		}
		else{
			f(data1,data2,index+=1);
		}
	}
}
