package ����;

import java.util.Scanner;

public class �Ź��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int[][] Data=new int[3][3];
		for(int i=0;i<3;i++) {
			String[] data=scanner.nextLine().split("\\s+");
			for(int j=0;j<3;j++) {
				Data[i][j]=Integer.valueOf(data[j]);
			}
		}
		scanner.close();
		System.out.println(If(Data));
	}
	
	public static int If(int[][] data) {
		int ret=1;
		
		for(int i=0;i<3;i++) {
			int sum=0;
			for(int j=0;j<3;j++) {
				sum+=data[i][j];
			}
			if(sum!=15) {
				ret=0;
			}
		}
		
		if(ret==1) {
			for(int i=0;i<3;i++) {
				int sum=0;
				for(int j=0;j<3;j++) {
					sum+=data[j][i];
				}
				if(sum!=15) {
					ret=0;
				}
			}
		}
		
		if(ret==1) {
			int sum=0;
			for(int i=0;i<3;i++) {
				for(int j=0;j<3;j++) {
					if(i+j==2) {
						sum+=data[i][j];
					}
				}		
			}
			if(sum!=15) {
				ret=0;
			}
		}
		
		if(ret==1) {
			int sum=0;
			for(int i=0;i<3;i++) {
				for(int j=0;j<3;j++) {
					if(i==j) {
						sum+=data[i][j];
					}
				}
			}
			if(sum!=15) {
				ret=0;
			}
		}
		
		return ret;
	}
}
