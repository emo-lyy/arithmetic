package ����;

public class λ��������˽� {
	public static void main(String[] args) {
		int a=6;
		int b=12;
		System.out.println("a="+a);
		System.out.println("b="+b);
		System.out.println("-----------------------");
		
		System.out.println(Integer.toString(a,2));
		System.out.println(Integer.toString(b,2));
		System.out.println("-----------------------");
		
		int c=a&b;
		System.out.println(c);
		System.out.println(Integer.toString(c,2));
		System.out.println("-----------------------");
		
		int d=a|b;
		System.out.println(d);
		System.out.println(Integer.toString(d,2));
		System.out.println("-----------------------");
		
		int e=a^b;
		System.out.println(e);
		System.out.println(Integer.toString(e,2));
		System.out.println("-----------------------");
		
		int f=~a;
		System.out.println(f);
		System.out.println(Integer.toString(f,2));
	}
}
