package ����;

import java.util.Scanner;

public class ��Ԫ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n+1];
		for(int i=1;i<=n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		
		/*for (int i : data) {
			System.out.print(i+" ");
		}*/
		
		for(int i=1;i<data.length-1;i++) {
			for(int j=1;j<data.length-i-1;j++) {
				if(data[j]>data[j+1]) {
					int temp=data[j];
					data[j]=data[j+1];
					data[j+1]=temp;
				}
			}
		}
		
		/*for (int i : data) {
			System.out.print(i+" ");
		}*/
		
		int a=data[1];
		int b=data[data.length-1];
		
		//System.out.println(a+" "+b);
		
		int count=0;
		for(int i=2;i<data.length-1;i++) {
			if(data[i]>a && data[i]<b) {
				count++;
			}
		}
		
		System.out.println(count);
		
	}
}
