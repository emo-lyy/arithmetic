package ����;

import java.util.Scanner;

public class ���������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		scanner.useDelimiter("\n");
		String[] strData=scanner.next().split("\\s+");
		int a=Integer.parseInt(strData[0]);
		int b=Integer.parseInt(strData[1]);
		int count=count(a,b);
		System.out.println(count);
		scanner.close();
	}
	
	public static int count(int a,int b) {
		int count=0;
		for(int i=a;i<=b;i++) {
			//����ֵת��Ϊ������
			String str=Integer.toBinaryString(i);
			char[]  binarySystemData=str.toCharArray();
			for (char c : binarySystemData) {
				if(c=='1') {
					count++;
				}
			}
		}
		
		
		return count;
	}
}
