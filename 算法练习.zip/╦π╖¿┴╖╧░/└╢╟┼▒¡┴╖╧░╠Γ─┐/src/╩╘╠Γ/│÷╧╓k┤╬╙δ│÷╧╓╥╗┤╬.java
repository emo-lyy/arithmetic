package ����;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ����k�������һ�� {
	public static void main(String[] args) {
		final int k=3;
		int[] data=new int[k*4+1];
		int index=0;
		for(int i=5;i<6+k;i++) {
			for(int j=1;j<=k;j++) {
				data[index]=i;
				index++;
			}
		}
		int randomNumber=(int)(Math.random()*10+10);
		data[index]=randomNumber;
		 
		for (int i : data) {
			System.out.print(i+" ");
		}
		System.out.println();
		
		//����һ
		f1(data,k);
		
		System.out.println("------------------");
		
		//������
		f2(data);
	}
	/**
	 * ��Ƶ���ⷽ����λ����
	 */
	public static void f1(int[] data,int k) {
		int len=data.length;
		char[][] KRadix=new char[len][];
		
		//���Ը�λ
		//System.out.println(Integer.toString(6, 2));
		
		int maxLen=0;
		for(int i=0;i<len;i++) {
			KRadix[i]=new StringBuffer(Integer.toString(data[i], k)).reverse().toString().toCharArray();      //reverse ���������ڷ�ת�ַ���
			maxLen=(maxLen>KRadix[i].length)?maxLen:KRadix[i].length;
		}
		
		int[] temp=new int[maxLen];
		for(int i=0;i<len;i++) {
			for(int j=0;j<maxLen;j++) {
				if(j>=KRadix[i].length) {
					temp[j]+=0;
				}
				else {
					temp[j]+=(KRadix[i][j]-'0');
				}
			}
		}
		
		/*for (int i : temp) {
			System.out.print(i+" ");
		}
		System.out.println();*/
		
		int res=0;
		for(int i=0;i<maxLen;i++) {
			res+=(temp[i]%k)*(int)(Math.pow(k, i));
		}
		
		System.out.println(res);
	}
	
	
	/**
	 * �Լ�ʹ��map���ϵĽⷨ
	 */
	public static void f2(int[] data) {
		Map<Integer,Integer> map=new HashMap<>();
		ArrayList<Integer> temp=new ArrayList<>();
		for( int  i : data) {
			if(!temp.contains(i)) {
				temp.add(i);
			}
		}
		
		/*for (Integer i : temp) {
			System.out.print(i+" ");
		}*/
		
		for (Integer i : temp) {
			int count=0;
			for(int j=0;j<data.length;j++) {
				if(i==data[j]) {
					count++;
				}
			}
			map.put(i, count);
		}
		
		for (Integer i : temp) {
			int a=map.get(i);
			if(a==1) {
				System.out.println(i);
			}
		}
	}
	
}
