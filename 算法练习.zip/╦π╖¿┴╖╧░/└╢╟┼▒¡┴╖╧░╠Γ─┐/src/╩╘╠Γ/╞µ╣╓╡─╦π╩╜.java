package ����;

public class ��ֵ���ʽ {
	public static void main(String[] args) {
		for(int i=10000;i<100000;i++) {
			int a=i/10000;
			int b=i%10000/1000;
			int c=i%1000/100;
			int d=i%100/10;
			int e=i%10;
			if(a!=b && a!=c && a!=d & a!=e && b!=c && b!=d && b!=e && c!=d && c!=e && d!=e) {
				for(int j=1;j<10;j++) {
					int EDCBA=Integer.parseInt(e+""+d+""+c+""+b+""+a);
					if(i*j==EDCBA) {
						System.out.println(i+"*"+j+"="+EDCBA);
						System.out.println("a:"+a+" b:"+b+" c:"+c+" d:"+d+" e:"+e);
					}
				}
			}
		}
	}
}
