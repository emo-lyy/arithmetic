package ����;

import java.math.BigInteger;

public class Test2 {
	public static void main(String[] args) {
		BigInteger b=new BigInteger("1");
		for(int i=1;i<10000;i++) {
			b=b.multiply(new BigInteger(i+""));
		}
		System.out.println(b.toString());
	}
}
