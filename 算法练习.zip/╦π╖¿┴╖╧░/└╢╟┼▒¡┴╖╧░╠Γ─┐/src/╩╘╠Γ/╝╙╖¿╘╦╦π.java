package ����;

import java.util.Scanner;

public class �ӷ����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		scanner.useDelimiter("\n");
		String[] data=scanner.next().split("\\s+");
		scanner.close();
		int sum=GetTwoInts(Integer.parseInt(data[0]),Integer.parseInt(data[1]));
		System.out.println(sum);
	}
	
	public static int GetTwoInts(int a,int b){
		return a+b;
	}
}
