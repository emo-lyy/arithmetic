package ����;

import java.util.Scanner;

/**
 * �����str���String[]  ����
 * @author ��ħ
 *
 */
public class s01�ִ� {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		String str="0";
		while(n>0){
			char[] data=str.toCharArray();
			String a="";
			for(int i=0;i<data.length;i++){
				if(data[i]=='0')
					a+="1";
				else
					a+="01";
			}
			str=a;
			n--;
		}
		System.out.println(str);
	}
}
