package ����;

import java.util.ArrayList;
import java.util.Scanner;

public class �ַ����༭ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] data=scanner.nextLine().toCharArray();
		/*for (char c : data) {
			System.out.print(c+" ");
		}*/
		String If=scanner.next();
		if(If.equals("D")) {
			//ɾ���ַ�
			String str=scanner.next();
			int index=f1(data,str);
			if(index==-1) {
				System.out.println("ָ���ַ�������");
			}
			else {
				//System.out.println(index);
				String ret="";
				for(int i=0;i<data.length;i++) {
					if(i!=index) {
						ret=ret+data[i];
					}
				}
				System.out.println(ret);
			}
			
		}
		else if(If.equals("I")) {
			//�����ַ�
			String str1=scanner.next();
			String str2=scanner.next();
			int index=f2(data,str1);
			if(index!=-1) {
				String[] temp=new String[data.length+1];
				int i=0;
				while(i<index) {
					temp[i]=data[i]+"";
					i++;
				}
				temp[index]=str2;
				int j=index+1;
				while(j<temp.length) {
					temp[j]=data[j-1]+"";
					j++;
				}
				
				for (String S : temp) {
					System.out.print(S);
				}
				System.out.println();
			}
			else {
				System.out.println("ָ���ַ�������");
			}
			
		}
		else if(If.equals("R")) {
			//�滻�ַ�
			String str1=scanner.next();
			String str2=scanner.next();
			ArrayList<Integer> index=f3(data,str1);
			if(index.size()==0) {
				System.out.println("ָ���ַ�������");
			}
			else {
				String[] temp=new String[data.length];
				for(int i=0;i<data.length;i++) {
					temp[i]=data[i]+"";
				}
				for (Integer i : index) {
					temp[i]=str2;
				}
			
				for (String S : temp) {
					System.out.print(S);
				}
				System.out.println();
			}
		}
		scanner.close();
	}
	
	//�����ַ��е�һ�γ����ַ�������
	public static int f1(char[] data,String str) {
		int index=0;
		while(index<data.length) {
			if(str.equals(data[index]+"")) {
				return index;
			}
			index++;
		}
		return -1;
	}
	
	//�����ַ������һ�γ���ָ���ַ�������
	public static int f2(char[] data,String str) {
		int index=-1;
		for(int i=0;i<data.length;i++) {
			if(str.equals(data[i]+"")) {
				index=i;
			}
		}
		return index;
	}
	
	//��ѯָ���ַ����ַ����г��ֵ�����λ��
	public static ArrayList<Integer> f3(char[] data,String str) {
		ArrayList<Integer> index=new ArrayList<>();
		//System.out.println(index.size());
		for(int i=0;i<data.length;i++) {
			if(str.equals(data[i]+"")) {
				index.add(i);
			}
		}
		return index;
	}
	
	
}
