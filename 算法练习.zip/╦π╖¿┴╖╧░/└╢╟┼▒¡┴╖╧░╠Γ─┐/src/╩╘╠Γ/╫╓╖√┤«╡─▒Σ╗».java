package ����;

import java.util.Scanner;

public class �ַ����ı仯 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String str=scanner.next();
		scanner.close();
		//System.out.println(n+" "+str);
		if(n==1) {
			System.out.println(str.toUpperCase());
		}
		else if(n==2) {
			System.out.println(str.toLowerCase());
		}
		else if(n==3) {
			int len=str.length()-1;
			char[] data=new char[len+1];
			int index=0;
			while(len>=0) {
				data[index]=str.charAt(len);
				index++;
				len-=1;
			}
			System.out.println(new String(data));
		}
		else if(n==4) {
			char[] data=str.toCharArray();
			char[] box=new char[data.length];
			for (int i=0;i<data.length;i++) {
				int temp=Integer.valueOf(data[i]);
				if(temp<96) {
					box[i]=(char)(temp+32);
				}
				else {
					box[i]=(char)(temp-32);
				}
			}
			System.out.println(new String(box));
		}
		else {
			str=str.toLowerCase();
			char[] data=str.toCharArray();
			char[] box=new char[data.length];
			box[0]=str.charAt(0);
			box[box.length-1]=str.charAt(str.length()-1);
			
			//System.out.println(data[0]+" "+data[str.length()-1]);
			
			
			//���ˣ����������ֱ�Ϊ '-'
			int index=1;
			while(index<str.length()-1) {
				if((data[index]-1)==data[index-1] && (data[index]+1)==data[index+1]) {
					box[index]='-';
				}
				else {
					box[index]=data[index];
				}
				index++;
			}
			
			StringBuffer string=new StringBuffer("");
			//System.out.println(string.length());
			for (char c : box) {
				if(string.length()==0) {
					string.append(c);
				}
				else {
					if(string.charAt(string.length()-1)!='-') {
						string.append(c);
					}
					else {
						if(c!='-') {
							string.append(c);
						}
					}
				}
			}
			System.out.println(string);
		}
	}
		
}
