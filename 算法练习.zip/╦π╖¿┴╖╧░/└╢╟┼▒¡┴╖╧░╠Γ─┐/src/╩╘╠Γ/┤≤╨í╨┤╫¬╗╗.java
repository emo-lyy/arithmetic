package ����;

import java.util.Scanner;

public class ��Сдת�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] data=scanner.next().toCharArray();
		scanner.close();
		char[] box=new char[data.length];
		for(int i=0;i<data.length;i++) {
			int temp=Integer.valueOf(data[i]);
			if(temp<96) {
				box[i]=(char)(temp+32);
			}
			else {
				box[i]=(char)(temp-32);
			}
		}
		String str=new String(box);
		System.out.println(str);
	}
}
