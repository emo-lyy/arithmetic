package ����;

import java.util.ArrayList;
import java.util.Scanner;

public class �ַ�ɾ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str1=scanner.next();
		String str2=scanner.next();
		scanner.close();
		ArrayList<String> list=new ArrayList<>();
		String data1[]=str1.split("");
		for (String s : data1) {
			if(!s.equals(str2)) {
				list.add(s);
			}
		}
		
		for (String s : list) {
			System.out.print(s);
		}
	}
}
