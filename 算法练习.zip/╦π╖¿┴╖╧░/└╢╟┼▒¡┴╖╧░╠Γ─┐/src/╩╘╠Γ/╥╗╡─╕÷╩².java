package ����;

import java.util.Scanner;

public class һ�ĸ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int sum=cuntOne(n);
		System.out.println(sum);
		scanner.close();
	}
	
	public static int cuntOne(int n) {
		int sum=0;
		for (int i = 1; i <= n; i++) {
			char[] str=String.valueOf(i).toCharArray();
			for (char c : str) {
				if(c=='1') {
					sum++;
				}
			}
		}
		
		
		return sum;
	}
}
