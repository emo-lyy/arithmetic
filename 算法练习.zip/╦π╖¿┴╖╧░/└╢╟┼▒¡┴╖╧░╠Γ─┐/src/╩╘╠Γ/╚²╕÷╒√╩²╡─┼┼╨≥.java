package ����;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class �������������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		ArrayList<Integer> data=new ArrayList<>();
		for(int i=0;i<3;i++) {
			data.add(scanner.nextInt());
		}
		scanner.close();
		Collections.sort(data);
		for(int i=data.size()-1;i>=0;i--) {
			System.out.print(data.get(i)+" ");
		}
	}
}
