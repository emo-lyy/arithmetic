package ����;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class �ִ��Ļ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		
		//1.����ַ����ĳ���
		int len=str.length();
		System.out.println(len);
		
		//2.�ҳ��ַ����г��ִ���������ĸ
		String[] data=str.split("");
		/*for (char c : data) {
			System.out.print(c+" ");
		}*/
		ArrayList<String> temp=new ArrayList<>();
		for(int i=0;i<data.length;i++) {
			if(!temp.contains(data[i])) {
				temp.add(data[i]);
			}
		}
		Map<String,Integer> map=new HashMap<>();
		for(int i=0;i<temp.size();i++) {
			int count=0;
			for(int j=0;j<data.length;j++) {
				if(temp.get(i).equals(data[j])) {
					count++;
				}
			}
			map.put(temp.get(i), count);
		}
		
		int sum=0;
		String ret="";
		for(int i=0;i<temp.size();i++) {
			//System.out.println(temp.get(i)+": "+map.get(temp.get(i)));
			ret=(map.get(temp.get(i))>sum)?temp.get(i):ret;
			sum=map.get(temp.get(i));
		}
		System.out.println(ret);
		
		
		//3.�ѳ��ִ���������ĸ��� -
		char[] box=str.toCharArray();
		for(int i=0;i<box.length;i++) {
			if(ret.equals(box[i]+"")) {
				box[i]='-';
			}
		}
		String S=new String(box);
		System.out.println(S);
	}
}
