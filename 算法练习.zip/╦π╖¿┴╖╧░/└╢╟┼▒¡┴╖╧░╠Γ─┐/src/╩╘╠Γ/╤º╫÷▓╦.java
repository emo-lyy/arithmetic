package ����;

import java.util.Scanner;

public class ѧ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();	//A������
		int b=scanner.nextInt();	//B������
		int c=scanner.nextInt();	//C������
		int d=scanner.nextInt();	//D������
		scanner.close();
		
		int A=0;
		int B=0;
		int C=0;
		int D=0;
		int E=0;
		while(a>0 || b>0 || c>0 || d>0) {
			//System.out.println(a+" "+b+" "+c+" "+d);
			if(a>=2 && b>=1 && d>=2) {
				a-=2;
				b-=1;
				d-=2;
				A++;
			}
			else if(a>=1 && b>=1 && c>=1 && d>=1) {
				a-=1;
				b-=1;
				c-=1;
				d-=1;
				B++;
			}
			else if(c>=2 && d>=1) {
				c-=2;
				d-=1;
				C++;
			}
			else if(b>=3){
				b-=3;
				D++;
			}
			else if(a>=1 && d>=1) {
				a-=1;
				d-=1;
				E++;
			}
			else {
				break;
			}
		}
		System.out.println(A);
		System.out.println(B);
		System.out.println(C);
		System.out.println(D);
		System.out.println(E);
	}
}
