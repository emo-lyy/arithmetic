package ����;

public class ����ʽ {
	public static void main(String[] args) {
		int count=0;
		for(int i=100000000;i<1000000000;i++) {
			int a=i/100000000;
			int b=i%100000000/10000000;
			int c=i%10000000/1000000;
			int d=i%1000000/100000;
			int e=i%100000/10000;
			int f=i%10000/1000;
			int g=i%1000/100;
			int h=i%100/10;
			int j=i%10;
			int[] data= {a,b,c,d,e,f,g,h,j};
			if(ifZero(data)) {
				if(If(data)) {
					//System.out.println(a+""+b+""+c+""+d+""+e+""+f+""+g+""+h+""+j+"");
					double sum=a+(b/Double.valueOf(c))+(d*100+e*10+f)/Double.valueOf((g*100+h*10+j));
					if(sum==10) {
						count++;
					}
				}
			}
		}
		System.out.println("����"+count+"�ֿ���");
	}
	
	public static boolean If(int[] data) {
		boolean ret=true;
		for (int i = 0; i < data.length; i++) {
			for (int j = i+1; j < data.length; j++) {
				if (data [i] == data [j])
					ret= false ;
					}
			}
		return ret;
		}
	
	
	public static boolean ifZero(int[] data) {
		boolean ret=true;
		
		for (int i : data) {
			if(i==0) {
				ret=false;
			}
		}
		
		return ret;
	}
}
