package ����;

import java.util.ArrayList;
import java.util.Scanner;

public class ��°ͺղ��� {
	private static ArrayList<Integer> data=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=6;i<n;i++) {
			if(i%2==0) {
				f(i);
				int length=data.size()-1;
				int count=0;
				for(int a=0;a<=length/2;a++) {
					for(int b=length;b>=length/2;b--) {
						if(count==0) {
							if(i==data.get(a)+data.get(b)) {
								System.out.println(i+"="+data.get(a)+"+"+data.get(b));
								count+=1;
							}
						}
						else {
							break;
						}
					}
				}
			}
		}
		
	}
	
	public static void f(int n) {
		for(int i=1;i<n;i++) {
			for(int j=2;j<=i;j++) {
				if(i==j) {
					data.add(i);
				}
				if(i%j==0) {
					break;
				}
			}
		}
		
	}
}
