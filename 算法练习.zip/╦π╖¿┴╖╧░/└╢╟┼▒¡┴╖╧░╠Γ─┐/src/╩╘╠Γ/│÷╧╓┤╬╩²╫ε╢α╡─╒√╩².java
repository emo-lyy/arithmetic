package ����;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ���ִ����������� {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		ArrayList<Integer> list=new ArrayList<>();
		for(int i=0;i<data.length;i++){  
            //�����������û����ͬ��Ԫ�ز������  
            if(!list.contains(data[i])){  
                list.add(data[i]);  
            }  
        }  
		
//		for (Integer i : list) {
//			System.out.print(i+" ");
//		}
		
		Map<Integer , Integer> map=new HashMap<>();
		for (int i = 0; i < list.size(); i++) {
			int box=0;
			for(int j=0;j<data.length;j++) {
				if(list.get(i)==data[j]) {
					box+=1;
				}
			}
			map.put(list.get(i),box);
		}
		
		int ret=list.get(0);
		int count=map.get(list.get(0));
		for(int i=1;i<list.size();i++) {
			int b=list.get(i);
			int c=map.get(b);
			if(c>count) {
				ret=b;
			}
		}
		System.out.println(ret);	
	}
}
