package ����;
import java.util.Scanner;

public class �����n����Сƽ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Long n=Long.parseLong(scanner.next());
		scanner.close();
		Long data=approachNMinData(n);
		System.out.println(data);
	}
	
	public static Long approachNMinData(Long n) {
		Long data=(long) 0;
		for (Long i = (long) 1; i <= n/2; i++) {
			if(i*i>=n) {
				data=i*i;
				break;
			}
		}
		return data;
	}
}
