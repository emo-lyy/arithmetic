package ����;

import java.util.Scanner;

public class Բ���ܳ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		double r=scanner.nextDouble();
		scanner.close();
		C(r);
		S(r);
	}
	
	public static void S(double r) {
		String data=String.valueOf(r*r*3.14);
		System.out.println(data);
		
	}
	
	public static void C(double r) {
		String data=String.valueOf(r*2*3.14);
		System.out.println(data);
	}
}
