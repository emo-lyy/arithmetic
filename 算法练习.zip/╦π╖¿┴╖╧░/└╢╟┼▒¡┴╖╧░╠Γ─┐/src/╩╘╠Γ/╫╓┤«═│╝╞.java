package ����;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class �ִ�ͳ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int len=scanner.nextInt();
		String str=scanner.next();
		scanner.close();
		ArrayList<String> list=new ArrayList<>();
		for(int i=0;i<str.length()-3;i++) {
			for(int j=0;j+len<str.length();j++) {
				//System.out.println(str.substring(i, len+j));
				list.add(str.substring(i, len+j));
			}
			len++;
		}
		
		ArrayList<String> temp=new ArrayList<>();
		
		//ȥ��
		for (String s : list) {
			if(!temp.contains(s)) {
				temp.add(s);
			}
		}
		
		//����ȥ���Ƿ�ɹ�
		/*for (String s : temp) {
			System.out.println(s);
		}*/
		
		//����һ��map�������ڱ���  ÿ���ִ��������ֵĴ���
		Map<String,Integer> map=new HashMap<>();
		for (String s : temp) {
			int count=0;
			for (String t : list) {
				if(s.equals(t)) {
					count++;
				}
			}
			map.put(s, count);
		}
		
		//�ж��ַ����ֵĴ�������ʾ�����ִ�
		String maxStr="";
		int maxCount=0;
		for (String s : temp) {
			int k=map.get(s);
			if(k>maxCount) {
				maxStr=s;
				maxCount=k;
			}
			if(k==maxCount) {
				int len1=s.length();
				int len2=maxStr.length();
				if(len1>len2) {
					maxStr=s;
					maxCount=k;
				}
			}
		}
	
		System.out.println(maxStr);
	}
}
