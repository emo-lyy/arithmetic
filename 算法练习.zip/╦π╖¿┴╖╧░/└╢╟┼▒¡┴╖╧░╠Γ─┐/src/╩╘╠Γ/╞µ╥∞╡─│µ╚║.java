package ����;

import java.math.BigInteger;
import java.util.Scanner;

public class ����ĳ�Ⱥ {
	/*public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int time=scanner.nextInt();
		scanner.close();
		BigInteger temp=A(time);
		System.out.println(temp.mod(new BigInteger("1000000007")));
	}
	
	public static BigInteger A(int time){
		if(time==1) {
			return new BigInteger("1");
		}
		return B(time-1).add(A(time-1));
	}
	
	public static BigInteger B(int time) {
		if(time==1) {
			return new BigInteger("1");
		}
		return A(time-1);
	}*/
	
	/*public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int time=scanner.nextInt();
		scanner.close();
		long[][] data=new long[time][2];
		data[0][0]=1;
		data[0][1]=1;
		int index=1;
		while(index<time) {
			data[index][0]=(data[index-1][0]+data[index-1][1])%1000000007;
			data[index][1]=data[index-1][0]%1000000007;
			index=index+1;
		}
		for (int i=0;i<time;i++) {
			for(int j=0;j<2;j++) {
				System.out.print(data[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println(data[time-1][0]);
	}*/
	
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Long time=scanner.nextLong();
		scanner.close();
		BigInteger a=new BigInteger("1");
		BigInteger b=new BigInteger("1");
		BigInteger temp=a;
		int count=1;
		while(count<time) {
			a=(a.add(b)).remainder(new BigInteger("1000000007"));
			b=temp.remainder(new BigInteger("1000000007"));
			temp=a;
			count++;
		}
		System.out.println(a);
	}
}
