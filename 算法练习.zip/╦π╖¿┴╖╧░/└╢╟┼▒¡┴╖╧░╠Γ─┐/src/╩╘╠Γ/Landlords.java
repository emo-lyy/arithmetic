package 试题;

import java.util.ArrayList;

public class Landlords {
	private static boolean[] IF=new boolean[54];  //用于判断该牌是否已经发出
	public static void main(String[] args) {
		String[] king= {"BEGKING","LITTLEKING"};
		String[] designAndAolour= {"♥","♠","♦","♣"};
		String[] number= {"A","2","3","4","5","6","7","8","9","10","J","Q","k"};
		ArrayList<String> data=new ArrayList<>();   //全部的牌
		data.add(king[0]);
		data.add(king[1]);
		
		for(int i=0;i<designAndAolour.length;i++) {
			for(int j=0;j<number.length;j++) {
				data.add(designAndAolour[i]+number[j]);
			}
		}
		
		/*int count=0;
		for (String s : data) {
			System.out.println(s);
			count++;
		}
		System.out.println(count);*/
		
		//随机地主
		int landlord_temp=(int) ((Math.random()*3)+1);
		
		//随机三张地主牌
		String[] landlordBrand=new String[3];
		int landlordBrand_count=0;
		while(landlordBrand_count<3) {
			int landlordBrand_index=(int)(Math.random()*54);
			if(!getIF(landlordBrand_index)) {
				landlordBrand[landlordBrand_count]=data.get(landlordBrand_index);
				setIF(landlordBrand_index);
				landlordBrand_count++;
			}
		}
		/*for (String s : landlordBrand) {
			System.out.println(s);
		}*/
		
		
		//创建三个用户
		ArrayList<String> user1=new ArrayList<>();
		ArrayList<String> user2=new ArrayList<>();
		ArrayList<String> user3=new ArrayList<>();
		
		//分别给三个用户发牌
		f(user1,data);
		f(user2,data);
		f(user3,data);
		
		//判断谁是地主给予地主牌
		if(landlord_temp==1) {
			for(int i=0;i<3;i++) {
				user1.add(landlordBrand[i]);
			}
		}
		else if(landlord_temp==2) {
			for(int i=0;i<3;i++) {
				user2.add(landlordBrand[i]);
			}
		}
		else if(landlord_temp==3) {
			for(int i=0;i<3;i++) {
				user3.add(landlordBrand[i]);
			}
		}
		
		//输出牌
		int sum=0;
		for (String s : user1) {
			System.out.print(s+" ");
			sum++;
		}
		System.out.println("  "+"总共有"+sum+"张牌");
		sum=0;
		for (String s : user2) {
			System.out.print(s+" ");
			sum++;
		}
		System.out.println("  "+"总共有"+sum+"张牌");
		sum=0;
		for (String s : user3) {
			System.out.print(s+" ");
			sum++;
		}
		System.out.println("  "+"总共有"+sum+"张牌");
		
	}
	
	
	//对牌的判断
	private static boolean getIF(int landlordBrand_index) {
		// TODO Auto-generated method stub
		return IF[landlordBrand_index];
	}
	
	private static void setIF(int landlordBrand_index) {
		IF[landlordBrand_index]=true;
	}
	
	
	//用于给三个用户生成随机牌
	public static void f(ArrayList<String> user,ArrayList<String> data) {
		int count=0;
		while(count<17) {
			int index=(int)(Math.random()*54);
			if(!getIF(index)) {
				user.add(data.get(index));
				setIF(index);
				count++;
			}
		}
	}
}
