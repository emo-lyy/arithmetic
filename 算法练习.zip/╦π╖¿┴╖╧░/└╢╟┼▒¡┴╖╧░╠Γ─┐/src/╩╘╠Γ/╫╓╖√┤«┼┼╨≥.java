package ����;

import java.util.Scanner;

public class �ַ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] data=scanner.next().toCharArray();
		scanner.close();
		int[] box=new int[data.length];
		for(int i=0;i<data.length;i++) {
			box[i]=Integer.valueOf(data[i]);
		}
		bubbleSort(box);
		for (int i : box) {
			System.out.print((char)i);
		}
	}
	
	public static void bubbleSort(int[] data) {
		for (int i = 0; i < data.length-1; i++) {
			for (int j = 0; j < data.length-i-1; j++) {
				if(data[j]>data[j+1]) {
					int temp=data[j];
					data[j]=data[j+1];
					data[j+1]=temp;
				}
			}
		}
	}
}
