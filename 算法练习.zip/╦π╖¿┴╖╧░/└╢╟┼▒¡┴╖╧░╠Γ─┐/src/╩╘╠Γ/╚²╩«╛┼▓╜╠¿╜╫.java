package ����;

import java.util.Scanner;

public class ��ʮ�Ų�̨�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		System.out.println(f1(n,0));
		
		System.out.println(o(n));
	}
	
	public static int f1(int i,int j) {
		if(i==1){
			if(j%2==0)return 0;
			return 1;
		}
		if(i==2)return 1;
		return f1(i-1,j+1)+f1(i-2,j+1);
	}
	
	/*
	 * ��������
	 */
	public static int o(int n) {
		if(n==1) {
			return 0;
		}
		if(n==2) {
			return 1;
		}
		return j(n-1)+j(n-2);
	} 
	public static int j(int n) {
		if(n==1 || n==2) {
			return 1;
		}
		return o(n-1)+o(n-2);
	}
}
