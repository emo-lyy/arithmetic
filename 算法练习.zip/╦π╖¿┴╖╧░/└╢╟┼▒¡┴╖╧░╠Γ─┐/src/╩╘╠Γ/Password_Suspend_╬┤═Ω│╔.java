package ����;

import java.util.Scanner;

public class Password_Suspend_δ��� {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		scanner.useDelimiter("\n");
		String[] input=scanner.next().split("\\s+");
		//����ĳ���
		int passwordLength=Integer.parseInt(input[0]);
		//��֪�����Ƭ����Ŀ
		int knownPasswordFragmentAmount=Integer.parseInt(input[1]);
		
		//��֪������Ƭ��
		String[] knownPasswordFragment=knownPasswordFragment(knownPasswordFragmentAmount);
		//��֪����Ƭ�γ���
		int knownPasswordLength=0;
		for (String string : knownPasswordFragment) {
			knownPasswordLength=knownPasswordLength+string.length();
		}
		
		Long numberOfPossible=countPossible(passwordLength,knownPasswordLength,knownPasswordFragmentAmount);
		System.out.println(numberOfPossible);
		}
	
	
	//������֪Ƭ��
	public static String[] knownPasswordFragment(int knownPasswordFragmentAmount) {
		String[] knownPasswordFragment=new String[knownPasswordFragmentAmount];
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		for(int i=0;i<knownPasswordFragmentAmount;i++) {
			knownPasswordFragment[i]=scanner.next();
		}
		return knownPasswordFragment;
	}
	
	
	//���������
	/**
	 * 
	 * @param passwordLength  �����ܳ���
	 * @param knownPasswordLength	����Ƭ�γ���
	 * @param knownPasswordFragmentAmount  ��֪����Ƭ����Ŀ
	 * @return
	 */
	public static Long countPossible(int passwordLength,int knownPasswordLength,int knownPasswordFragmentAmount) {
		
		//System.out.println(passwordLength+" "+knownPasswordLength+" "+knownPasswordFragmentAmount);
		
		//ע��˴�����Ӧ�ø���һ�� 
		Long numberOfPossible=(long) 1;
		//ʣ�����볤��
		int surplusLength=passwordLength-knownPasswordLength;
		//System.out.println(surplusLength);
		
		if(knownPasswordLength==0) {
			for(int i=1;i<=passwordLength;i++) {
				numberOfPossible=numberOfPossible*26;
			}
		}
		
		else if(knownPasswordLength==1) {
			for(int i=1;i<=surplusLength;i++) {
				numberOfPossible=numberOfPossible*26;
			}
			numberOfPossible=numberOfPossible*(knownPasswordLength+surplusLength);
		}
		
		else {
			for(int i=1;i<=surplusLength;i++) {
				numberOfPossible=numberOfPossible*26;
			}
			numberOfPossible=numberOfPossible*(knownPasswordFragmentAmount+surplusLength)*(knownPasswordFragmentAmount+surplusLength-1);
		}
		
		return numberOfPossible;
	}
}
