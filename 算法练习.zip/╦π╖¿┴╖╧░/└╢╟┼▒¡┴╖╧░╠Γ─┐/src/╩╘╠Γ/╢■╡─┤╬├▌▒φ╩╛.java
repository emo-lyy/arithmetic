package ����;

import java.util.Scanner;

/**
 * ����δ��
 * @author ��ħ
 *
 */
public class ���Ĵ��ݱ�ʾ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		System.out.println(test(n));
	}
	
	public static String test(int n) {
		String ret="";
		String str=Integer.toBinaryString(n);
		//System.out.println(str);
		char[] data=str.toCharArray();	
		int count=0;
		for(int i=data.length-1;i>=0;i--) {
			if(data[count]=='1') {
				if(i<3) {
					if(count==1) {ret+="2";}
					else{ret=ret+"2"+"("+count+")";}
				}
				else {
					ret+="2("+test(count)+")";
				}
				if(i!=0) {
					ret+="+";
				}
			}
			count+=1;
		}
		return ret;
	}
}
