package ����;

import java.util.Scanner;

public class �ִ����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		int index=str.length()-1;
		while(index>=0) {
			System.out.print(str.charAt(index));
			index--;
		}
	}
}
