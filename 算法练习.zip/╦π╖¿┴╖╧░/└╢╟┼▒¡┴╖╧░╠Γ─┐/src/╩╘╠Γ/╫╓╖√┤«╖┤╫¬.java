package ����;

import java.util.Scanner;

public class �ַ�����ת {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.nextLine();
		scanner.close();
		String[] data=str.split("\\s+");
		for (int i = 0; i < data.length; i++) {
			String temp=data[i];
			char[] box=temp.toCharArray();
			int index=box.length-1;
			while(index>=0) {
				System.out.print(box[index]);
				index--;
			}
			System.out.print(" ");
		}
	}
}
