package ����;

import java.util.Scanner;

public class �����Ƶ�һ�ĸ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		System.out.println(Integer.toString(n, 2));
		
		//λ����ⷨ
		int count=0;
		for(int i=0;i<32;i++) {
			if((n&(1<<i))==(1<<i)) {
				count++;
			}
		}
		System.out.println(count);
		
		System.out.println("--------------------------");
		
		//�Լ����ܵ�����
		
		int sum=0;
		String str=Integer.toString(n,2);
		for(int i=0;i<str.length();i++) {
			if((str.charAt(i)+"").equals("1")) {
				sum++;
			}
		}
		System.out.println(sum);
	}
}
