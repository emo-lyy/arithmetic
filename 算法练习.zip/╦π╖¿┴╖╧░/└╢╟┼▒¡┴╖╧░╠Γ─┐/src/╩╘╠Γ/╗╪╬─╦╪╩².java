package ����;

public class �������� {
	public static void main(String[] args) {
		int sum=0;
		for(int i=10000;i<100000;i++) {
			if(ifPrimeNumber(i)) {
					int a=i/10000;
					int b=i%10000/1000;
					//int c=i%1000/100;
					int d=i%100/10;
					int e=i%10;
					if(a==e && b==d) {
						System.out.println(i);
						sum++;
					}
				}
			}
			System.out.println("�ܹ���:"+sum);
		}
	
	public static boolean ifPrimeNumber(int n) {
		boolean ret=true;
		for(int i=2;i<n;i++) {
			if(n%i==0) {
				ret=false;
				break;
			}
		}
		return ret;
	}
}
