package ����;

public class Test {
	public static void main(String[] args) {
		int a=50;
		int b=80;
		System.out.println(a);
		System.out.println(b);
		
		System.out.println("--------------------");
		
		System.out.println(Integer.toString(a, 2));
		System.out.println(Integer.toString(b, 2));
		
		System.out.println("---------------------");
		
		System.out.println(a^b);
		System.out.println(a&b);
		System.out.println(Integer.toString(a^b, 2));
		System.out.println(Integer.toString(a&b, 2));
		
		System.out.println("---------------------");
		
		int sum=0;
		int temp=0;
		while(b!=0) {
			sum=a^b;
			temp=(a&b)<<1;
			
			System.out.print(sum+"======>");
			System.out.println(Integer.toString(sum,2));
			System.out.print(temp+"=====>");
			System.out.println(Integer.toString(temp,2));
			
			System.out.println("**********");
			
			a=sum;
			b=temp;
		}
		
		System.out.println("---------------------");
		System.out.println(a);
	}
}
