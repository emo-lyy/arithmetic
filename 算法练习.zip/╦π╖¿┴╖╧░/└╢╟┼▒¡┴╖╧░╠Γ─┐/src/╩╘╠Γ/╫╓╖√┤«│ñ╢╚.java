package ����;

import java.util.Scanner;

public class �ַ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		System.out.println(str.length());
	}
}
