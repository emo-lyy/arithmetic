package ����;

import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int count=scanner.nextInt();
		scanner.close();
		boolean ret=true;
		for(int i=10000;i<1000000;i++) {
			String str=i+"";
			if(str.length()==5) {
				int a=i/10000;
				int b=i%10000/1000;
				int c=i%1000/100;
				int d=i%100/10;
				int e=i%10;
				if(a==e && b==d) {
					if(a+b+c+d+e==count) {
						System.out.println(i);
						ret=false;
					}
				}
			}else {
				int a=i/100000;
				int b=i%100000/10000;
				int c=i%10000/1000;
				int d=i%1000/100;
				int e=i%100/10;
				int f=i%10;
				if(a==f && b==e && c==d) {
					if(a+b+c+d+e+f==count) {
						System.out.println(i);
						ret=false;
					}
				}
			}
		}
		if(ret) {
			System.out.println(-1);
		}
	}
}
