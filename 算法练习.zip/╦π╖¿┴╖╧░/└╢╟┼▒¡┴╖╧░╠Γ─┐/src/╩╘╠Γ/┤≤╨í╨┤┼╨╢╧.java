package ����;

import java.util.Scanner;

public class ��Сд�ж� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] data=scanner.next().toCharArray();
		scanner.close();
		int n=(int)data[0];
		if(n>=65 && n<97) {
			System.out.println("upper");
		}
		else {
			System.out.println("lower");
		}
	}
}
