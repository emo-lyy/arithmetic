package ����;

public class ��_��ˮ�ɻ��� {
	public static void main(String[] args) {
		/*System.out.println(123/100);
		System.out.println(123/10%10);
		System.out.println(123%10);*/
		
		for(int i=100;i<1000;i++) {
			if(f(i)) {
				System.out.println(i);
			}
		}
	}
	
	public static boolean f(int n) {
		int a=n/100;
		int b=n/10%10;
		int c=n%10;
		int sum=a*a*a+b*b*b+c*c*c;
		if(sum==n) {
			return true;
		}
		else {
			return false;
		}
	}
}
