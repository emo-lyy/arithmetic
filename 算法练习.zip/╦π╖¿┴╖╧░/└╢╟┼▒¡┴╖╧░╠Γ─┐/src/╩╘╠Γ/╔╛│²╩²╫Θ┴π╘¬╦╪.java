package ����;

import java.util.ArrayList;
import java.util.Scanner;

public class ɾ��������Ԫ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.nextLine();
		String[] box=scanner.nextLine().split("\\s+");
		scanner.close();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=Integer.valueOf(box[i]);
		}
		CompactIntegers(data,n);
	}
	
	public static void CompactIntegers(int[] data,int n) {
		ArrayList<Integer> list=new ArrayList<>();
		
		for (int i : data) {
			if(i!=0) {
				list.add(i);
			}
		}
		
		int count=list.size();
		System.out.println(count);
		for (Integer i : list) {
			System.out.print(i+" ");
		}
	} 
}
