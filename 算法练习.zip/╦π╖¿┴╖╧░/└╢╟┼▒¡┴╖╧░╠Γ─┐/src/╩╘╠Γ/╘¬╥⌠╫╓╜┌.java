package ����;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * ����һ �������ʽ
 * ������ �Ȱ����Ը���ͳһ���һ���ַ� Ԫ�����һ���ַ� ȥ�Ա�  ��� count=3  ���ǶԵ�
 * @author ��ħ
 *
 */
public class Ԫ���ֽ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		f1(str);
		System.out.println("------------------------");
		f2(str);
	}
	
	public static void f1(String str) {
		String If="[^aeiou]+[aeiou]+[^aeiou]+[aeiou]+";
		Boolean b=str.matches(If);
		if(b) {
			System.out.println("yes");
		}
		else {
			System.out.println("no");
		}
		
	}
	
	public static void f2(String str) {
		ArrayList<String> temp=new ArrayList<>();
		temp.add("a");
		temp.add("e");
		temp.add("i");
		temp.add("o");
		temp.add("u");
		String[] data=str.split("");
		for(int i=0;i<data.length;i++) {
			if(temp.contains(data[i])) {
				data[i]="1";
			}
			else {
				data[i]="0";
			}
		}
		
		
		String l=data[0];
		if(l.equals("0")) {
			int count=0;
			for(int i=1;i<data.length;i++) {
				if(!l.equals(data[i])) {
					count++;
					l=data[i];
				}
			}
			if(count!=3) {
				System.out.println("no");
			}
			else {
				System.out.println("yes");
			}
		}
		else {
			System.out.println("no");
		}
	}
}
