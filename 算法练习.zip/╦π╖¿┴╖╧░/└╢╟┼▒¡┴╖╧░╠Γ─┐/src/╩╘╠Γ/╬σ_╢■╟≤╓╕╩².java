package ����;

import java.util.Scanner;

public class ��_����ָ�� {
	private static int sum=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		scanner.close();
		for(int i=1;i<=m;i++) {
			f(n,i);
		}
	}
	
	public static void f(int n,int number) {
		int count=1;
		for(int i=0;i<number;i++) {
			count=count*n;
		}
		sum++;
		if(sum<5) {
			System.out.print("          "+count);
		}
		else if(sum==5) {
			System.out.print("          "+count);
			System.out.println();
		}
		else {
			System.out.print("      "+count);
		}
		
	}
}
