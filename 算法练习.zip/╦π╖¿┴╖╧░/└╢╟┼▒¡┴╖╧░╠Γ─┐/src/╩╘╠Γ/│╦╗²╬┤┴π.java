package ����;

import java.math.BigInteger;
import java.util.Scanner;

public class �˻�δ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int[] data=new int[100];
		for(int i=0;i<100;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		BigInteger bi=new BigInteger("1");
		for (int i : data) {
			bi=bi.multiply(new BigInteger(i+""));
		}
		//System.out.println(bi);
		String str=bi.toString();
		int len=str.length()-1;
		int count=0;
		while(true) {
			if(str.charAt(len)=='0') {
				count++;
				len--;
			}
			else {
				break;
			}
		}
		//System.out.println(str);
		System.out.println(count);
	}
}
