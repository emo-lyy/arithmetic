package ��������;

import java.util.HashSet;
import java.util.Set;

public class ƽ��ĩβ {
	public static void main(String[] args) {
		Set<String> set=new HashSet<>();
		for(int i=10;i<100;i++) {
			String s=(int)Math.pow(i, 2)+"";
			String k=s.substring(s.length()-2, s.length());
			//System.out.println(k);
			set.add(k);
		}
		System.out.println(set.size());
	}
}
