package ��������;

import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int EX=scanner.nextInt();
		int EY=scanner.nextInt();
		scanner.close();
		
		int BX=0;
		int BY=0;
		int count=0;
		String[] check= {"left","top","right","bottom"};
		int index=0;
		int d=1;
		while(true) {
			if(index==check.length)index=0;
			//left
			if(check[index].equals("left")) {
				for(int i=1;i<=d;i++) {
					BX-=1;
					count++;
					if(BX==EX && BY==EY) {
						System.out.println(count);
						System.exit(0);
					}
				}
				index++;
			}
			//top
			if(check[index].equals("top")) {
				for(int i=1;i<=d;i++) {
					BY+=1;
					count++;
					if(BX==EX && BY==EY) {
						System.out.println(count);
						System.exit(0);
					}
				}
				index++;
				d+=1;
			}
			//right
			if(check[index].equals("right")) {
				for(int i=1;i<=d;i++) {
					BX+=1;
					count++;
					if(BX==EX && BY==EY) {
						System.out.println(count);
						System.exit(0);
					}
				}
				index++;
			}
			//bottom
			if(check[index].equals("bottom")) {
				for(int i=1;i<=d;i++) {
					BY-=1;
					count++;
					if(BX==EX && BY==EY) {
						System.out.println(count);
						System.exit(0);
					}
				}
				index++;
				d+=1;
			}
		}
	}
}
