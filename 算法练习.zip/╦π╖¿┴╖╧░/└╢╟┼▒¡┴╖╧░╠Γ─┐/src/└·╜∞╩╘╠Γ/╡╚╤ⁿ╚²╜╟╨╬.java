package ��������;

import java.util.Scanner;

public class ���������� {
	static char[] C;
	public static void main(String[] args) {
		String s="";
		for(int i=1;i<500;i++) {
			s+=i+"";
		}
		C=s.toCharArray();
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		char[][] A=new char[n][2*n-1];
		
		int count=0;
		//���
		int k=n;
		for(int i=0;i<n;i++) {
			A[i][k-1]=C[count];
			k--;
			count++;
		}
		
		//�±�
		for(int i=1;i<2*n-1;i++) {
			A[n-1][i]=C[count];
			count++;
		}
		
		//�ұ� 
		int l=A[0].length-2;
		for(int i=A.length-2;i>=1;i--) {
			A[i][l]=C[count];
			for(int j=n-1;j<l;j++) {
				A[i][j]='.';
			}
			/*//ȥ���ұߵĿո�
			for(int j=l+1;j<A[0].length;j++) {
				A[i][j]=' ';
			}*/
			l--;
			count++;
		}
		//�ѵ�һ�еĿ�λ���ɿո�
		/*for(int i=n;i<A[0].length;i++) {
			A[0][i]=' ';
		}*/
		
		//��ǰ��Ŀո���С����
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				if(A[i][j]==0) {
					A[i][j]='.';
				}
			}
		}
		
		out(A);		//�������
	}
	static void out(char[][] A) {
		for(int i=0;i<A.length;i++) {
			for(int j=0;j<A[0].length;j++) {
				System.out.print(A[i][j]);
			}
			System.out.println();
		}
	}
}
