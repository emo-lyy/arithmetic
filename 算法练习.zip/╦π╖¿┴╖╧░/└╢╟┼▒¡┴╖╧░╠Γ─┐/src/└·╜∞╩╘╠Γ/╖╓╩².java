package ��������;

import java.math.BigInteger;
import java.util.Scanner;

public class ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		BigInteger k=BigInteger.ONE;		//��ĸ
		for(int i=1;i<=n;i++) {
			int l=(int)Math.pow(2, i-1);
			//System.out.println(l);
			k=k.multiply(new BigInteger(l+""));
		}
		//System.out.println(k);
		BigInteger sum=BigInteger.ZERO;	//����
		for(int i=1;i<=n;i++) {
			int l=(int)Math.pow(2, i-1);
			BigInteger temp=k.divide(new BigInteger(l+""));
			sum=sum.add(temp);
		}
		//System.out.println(sum);
		BigInteger temp=gcd(sum,k);
		BigInteger zi=sum.divide(temp);
		BigInteger mu=k.divide(temp);
		if(zi==mu) {
			System.out.println(zi.divide(mu));
		}
		else {
			System.out.println(zi+"/"+mu);
		}
	}
	
	static BigInteger gcd(BigInteger a,BigInteger b) {
		if(b==BigInteger.ZERO) {
			return a;
		}
		return gcd(b,a.mod(b));
	}
}
