package ��������;

import java.util.Arrays;
import java.util.Scanner;

public class ��׺����ʽ {
	static int[] A;
	static int res=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		A=new int[n+m+1];
		for(int i=0;i<n+m+1;i++) A[i]=scanner.nextInt();
		scanner.close();
		Arrays.sort(A);
		long sum=0;
		for(int i=A.length-1;i>=A.length-n-1;i--) {
			sum+=A[i];
		}
		for(int i=A.length-n-2;i>=0;i--) {
			sum-=A[i];
		}
		System.out.println(sum);
	}
}
