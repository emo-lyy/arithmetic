package ��������;

public class ֽ�������� {
	
	static int count=0;
	public static void main(String[] args) {
		char[] arr="123456789".toCharArray();
		dfs(arr,0);
		System.out.println(count/3/2);
	}
	public static void dfs(char[] arr,int k) {
		if(k==arr.length) {
			//System.out.println(new String(arr));
			String s=new String(arr);
			String a=s.substring(0,4);
			String b=s.substring(3,7);
			String c=s.substring(6,9)+arr[0];
			/*System.out.println(a);
			System.out.println(b);
			System.out.println(c);
			System.out.println("------------------");*/
			int sum1=0;
			int sum2=0;
			int sum3=0;
			String[] A=a.split("");
			String[] B=b.split("");
			String[] C=c.split("");
			for (int i = 0; i < 4; i++) {
				sum1+=Integer.valueOf(A[i]);
				sum2+=Integer.valueOf(B[i]);
				sum3+=Integer.valueOf(C[i]);
			}
			if(sum1==sum2 && sum2==sum3 && sum3==sum1) {
				System.out.println(s);
				System.out.println(a);
				System.out.println(b);
				System.out.println(c);
				System.out.println("------------------");
				count++;
			}
		}
		for(int i=k;i<arr.length;i++) {
			swap(arr,k,i);
			dfs(arr,k+1);
			swap(arr,k,i);
		}
		
	}
	
	public static void swap(char[] arr,int i,int j) {
		char temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
	}
}
