package ��������;

/**
 * ����˼·������ȫ���н���ö��
 * @author ��ħ
 *
 */
public class ���ľ {
	static long count=0;
	public static void main(String[] args) {
		int[] A= {0,1,2,3,4,5,6,7,8,9};
		dfs(A,0,A.length);
		System.out.println(count);
	}
	static void dfs(int[] A,int k,int n) {
		if(k==n) {
			if(A[0]==0) {
				int index=0;
				int[][] L=new int[4][4];
				for(int i=0;i<4;i++) {
					for(int j=0;j<=i;j++) {
						L[i][j]=A[index];
						index++;
					}
				}
				if(check(L)) {
					for(int i=0;i<4;i++) {
						for(int j=0;j<=i;j++) {
							System.out.print(L[i][j]+" ");
						}
						System.out.println();
					}
					System.out.println("----------------------");	
					count++;
				}	
			}	
		}
		for(int i=k;i<n;i++ ) {
			swap(A,i,k);
			dfs(A,k+1,n);
			swap(A,i,k);
		}
	}
	
	static void swap(int[] A,int i,int j) {
		int temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
	
	static boolean check(int[][] A) {
		for(int i=0;i<3;i++) {
			for(int j=0;j<=i;j++) {
				if(A[i][j]>A[i+1][j] || A[i][j]>A[i+1][j+1]) {
					return false;
				}
			}
		}
		return true;
	}
}
