package ��������;

import java.util.Calendar;
import java.util.Scanner;

public class �ڼ��� {
	public static void main(String[] args) {
		//���� - �ָ�
		Scanner scanner=new Scanner(System.in);
		String begin=scanner.next();
		String end=scanner.next();
		scanner.close();
		String[] A=begin.split("-");
		String[] B=end.split("-");
		
		Date beginDate=new Date(Integer.valueOf(A[0]),Integer.valueOf(A[1]),Integer.valueOf(A[2]));
		Date endDate=new Date(Integer.valueOf(B[0]),Integer.valueOf(B[1]),Integer.valueOf(B[2]));
		
		int sum=0;
		Calendar c=Calendar.getInstance();
		for(int i=beginDate.getMonth();i<endDate.getMonth();i++) {
			c.set(beginDate.getYear(), i-1, beginDate.getTime());
			int k=c.getActualMaximum(Calendar.DATE);
			//System.out.println(k);
			sum+=k;
		}
		sum+=endDate.getTime();
		System.out.println(sum);
	}
	
	
	private static class Date {
		private int year;
		private int month;
		private int time;
		
		public int getYear() {
			return year;
		}
		public int getMonth() {
			return month;
		}
		public int getTime() {
			return time;
		}
		public Date(int year, int month, int time) {
			super();
			this.year = year;
			this.month = month;
			this.time = time;
		}
		
		
		
	}
}
