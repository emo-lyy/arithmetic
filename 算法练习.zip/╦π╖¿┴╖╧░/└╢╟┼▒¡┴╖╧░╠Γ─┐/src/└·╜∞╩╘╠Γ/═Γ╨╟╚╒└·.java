package ��������;

import java.math.BigInteger;

public class �������� {
	public static void main(String[] args) {
		/*Scanner scanner=new Scanner(System.in);
		String data=scanner.next();
		scanner.close();*/
		final String data="651764141421415346185";
		BigInteger b=new BigInteger(data);
		String[] A="ABCDEFGHI".split("");
		b=b.subtract(new BigInteger("190"));
		b=b.mod(new BigInteger("9"));
		int index=Integer.valueOf(b.toString());
		System.out.println(A[index]);
	}
}
