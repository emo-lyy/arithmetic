package ��������;

import java.util.*;
public class ��ӡ��X {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
           int n=in.nextInt();
           int m=in.nextInt();
           in.close();
           for(int i=0;i<m/2+1;i++) {
        	   for(int j=0;j<i;j++) {
        		   System.out.print(".");
        	   }
        	   for(int k=0;k<n;k++) {
        		   System.out.print("*");
        	   }
        	if(m-n-1-(i*2)>0)
        	   {
        	   for(int p=0;p<m-n-1-(i*2);p++) {
        		   System.out.print(".");
        	   }
        	   for(int q=0;q<n;q++) {
        		   System.out.print("*");
        	   }
        	   for(int w=0;w<i;w++) {
        		   System.out.print(".");
        	   }
        	         }
        	   
        	 else {
        	   for(int q=0;q<m-1-(i*2);q++) {
        		   System.out.print("*");
        	   }
        	   for(int p=0;p<i;p++) {
        		   System.out.print(".");
        	   }
        	        }
        	   System.out.println();
           }//�ϰ�X
              for(int i=m/2-1;i>=0;i--) {
            	  for(int j=0;j<i;j++) {
            		  System.out.print(".");
            	  }
            	  for(int k=0;k<n;k++) {
           		   System.out.print("*");
           	   }
            	  
         if(m-n-1-(i*2)<0) { 
            	  for(int q=0;q<m-1-(i*2);q++) {
           		   System.out.print("*");
           	   }
           	   for(int p=0;p<i;p++) {
           		   System.out.print(".");
           	   }
           	       }
         else {
            		  for(int p=0;p<m-n-1-(i*2);p++) {
               		   System.out.print(".");
               	   }
               	   for(int q=0;q<n;q++) {
               		   System.out.print("*");
               	   }
               	   for(int w=0;w<i;w++) {
               		   System.out.print(".");
               	   }  
            	  }
           	   System.out.println();
              }//�°�X
        	}
      }
