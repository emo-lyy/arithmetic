package ��������;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class ���ǹ� {
	static int count=0;	//��ʦҪ�����ǹ���Ŀ
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] A=new int[n];
		for(int i=0;i<n;i++)A[i]=scanner.nextInt();
		scanner.close();
		dfs(A);
	}
	
	static void dfs(int[] A) {
		if(check(A)) {
			System.out.println(count);
			return;
		}
		int[] temp=new int[A.length];
		for(int i=0;i<A.length;i++) {
			temp[i]=A[i]/2;
			A[i]-=temp[i];
		}
		for(int i=1;i<A.length;i++) {
			A[i]+=temp[i-1];
		}
		A[0]+=temp[A.length-1];
		add(A);
		dfs(A);
	}
	
	/**
	 * �ж��Ƿ�ֹͣ
	 * @param A
	 * @return
	 */
	static boolean check(int[] A) {
		Set<Integer> set=new HashSet<>();
		for(int i=0;i<A.length;i++) {
			set.add(A[i]);
			if(set.size()!=1)return false;
		}
		return true;
	}
	
	static int[] copy(int[] A) {
		int[] res=new int[A.length];
		for(int i=0;i<A.length;i++) {
			res[i]=A[i];
		}
		return res;
	}
	
	static void add(int[] A) {
		for(int i=0;i<A.length;i++) {
			if(A[i]%2==1) {
				count++;
				A[i]++;
			}
		}
	}
	
	static void out(int[] A) {
		for (int i : A) {
			System.out.print(i+" ");
		}
		System.out.println();
	}
}
