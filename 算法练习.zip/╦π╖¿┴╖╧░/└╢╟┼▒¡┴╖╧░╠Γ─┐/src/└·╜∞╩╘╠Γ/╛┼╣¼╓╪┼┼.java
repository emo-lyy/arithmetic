package ��������;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class �Ź����� {
	static String end;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String begin=scanner.next();
		end=scanner.next();
		scanner.close();
		Set<String> S=new HashSet<>();
		S.add(begin);
		dfs(S,0);
	}
	
	static void dfs(Set<String> S,int count) {
		if(S.contains(end)) {
			System.out.println(count);
			return ;
		}
		Set<String> A=new HashSet<>();
		for (String s : S) {
			char[][] C=decompose(s);
			for(int i=0;i<3;i++) {
				for(int j=0;j<3;j++) {
					if(C[i][j]=='.') {
						//top
						if(i-1>=0) {
							swap(C,i,j,i-1,j);
							String temp=merge(C);
							swap(C,i,j,i-1,j);
							A.add(temp);
						}
						//bottom
						if(i+1<C.length) {
							swap(C,i,j,i+1,j);
							String temp=merge(C);
							swap(C,i,j,i+1,j);
							A.add(temp);
						}
						//left
						if(j-1>=0) {
							swap(C,i,j,i,j-1);
							String temp=merge(C);
							swap(C,i,j,i,j-1);
							A.add(temp);
						}
						//right
						if(j+1<C[0].length) {
							swap(C,i,j,i,j+1);
							String temp=merge(C);
							swap(C,i,j,i,j+1);
							A.add(temp);
						}
					}
				}
			}
		}
		dfs(A,count+1);
	}
	
	static char[][] decompose(String s){
		char[][] res=new char[3][3];
		int index=0;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				res[i][j]=s.charAt(index);
				index++;
			}
		}
		return res;
	}
	
	static void swap(char[][] A,int x1,int y1,int x2,int y2) {
		char temp=A[x1][y1];
		A[x1][y1]=A[x2][y2];
		A[x2][y2]=temp;
	}
	
	static String merge(char[][] A) {
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<A.length;i++) {
			for(int j=0;j<A[0].length;j++) {
				sb.append(A[i][j]);
			}
		}
		return sb.toString();
	}
	
	static void out(char[][] A) {
		for (char[] I : A) {
			for (char i : I) {
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}
}
