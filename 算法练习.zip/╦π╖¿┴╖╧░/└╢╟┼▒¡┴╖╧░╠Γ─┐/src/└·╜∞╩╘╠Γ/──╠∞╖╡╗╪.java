package ��������;

public class ���췵�� {
	public static void main(String[] args) {
		int sum=0;
		for(int i=1;i<100;i++) {
			int n=2*i-1;
			//System.out.println(n);
			sum+=n;
			//System.out.println(sum);
			if(sum>=108) {
				System.out.println(i);
				break;
			}
			
		}
	}
}
