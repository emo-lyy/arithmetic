package ��������;

import java.util.Scanner;

public class ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int r=scanner.nextInt();
		scanner.close();
		
		int sum=0;
		for(int i=1;i<=r;i++) {
			for(int j=1;j<r;j++) {
				if(i*i+j*j<=r*r) {
					//System.out.println(i+" "+j);
					sum++;
				}
			}
		}
		System.out.println(sum*4);
	}
}
