package ��������;

import java.util.Scanner;

public class Excel��ַ {
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		long n = scanner.nextLong();
		scanner.close();
		char[] c = new char[100];
		int cnt = 0;
		while(n!=0){
			if(n%26==0){
				c[cnt++]=26+64;//65-A 90-Z
				n/=26;
				n--;//��Ϊֻ��Z����û��ǰ���1
			}else{
				c[cnt++]=(char) (n%26+64);
				n/=26;
			}
			
		}
		for(int i=cnt-1;i>=0;i--)
			System.out.print(c[i]);	
	}
}
