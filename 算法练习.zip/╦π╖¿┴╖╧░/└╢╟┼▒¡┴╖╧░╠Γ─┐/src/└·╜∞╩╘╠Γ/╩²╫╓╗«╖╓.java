package ��������;

import java.util.ArrayList;

public class ���ֻ��� {
	static long count=0;
	static int[] arr= {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
	public static void main(String[] args) {
		dfs(new ArrayList<>(),new ArrayList<>(),0);
	}
	static void dfs(ArrayList<Integer> A,ArrayList<Integer> B,int index) {
		if(index==arr.length) {
			if(check1(A,B) && check2(A,B) && check3(A,B)) {
				System.out.println(count+++":");
				System.out.println(A);
				System.out.println(B);
				System.out.println("---------------------");	
			}
			return;
		}
		A.add(arr[index]);
		dfs(A,B,index+1);
		A.remove(A.size()-1);
		B.add(arr[index]);
		dfs(A,B,index+1);
		B.remove(B.size()-1);
	}
	
	static boolean check1(ArrayList<Integer> A,ArrayList<Integer> B) {
		long sum1=0;
		long sum2=0;
		for (Integer i : A) {
			sum1+=i;
		}
		for (Integer i : B) {
			sum2+=i;
		}
		
	//	System.out.println(sum1+" "+sum2);
		if(sum1==sum2)return true;
		else return false;
	}
	
	static boolean check2(ArrayList<Integer> A,ArrayList<Integer> B) {
		long sum1=0;
		long sum2=0;
		for (Integer i : A) {
			sum1+=Math.pow(i, 2);
		}
		for (Integer i : B) {
			sum2+=Math.pow(i, 2);
		}
		if(sum1==sum2)return true;
		else return false;
	}
	
	static boolean check3(ArrayList<Integer> A,ArrayList<Integer> B) {
		long sum1=0;
		long sum2=0;
		for (Integer i : A) {
			sum1+=Math.pow(i, 3);
		}
		for (Integer i : B) {
			sum2+=Math.pow(i, 3);
		}
		if(sum1==sum2)return true;
		else return false;
	}
}
