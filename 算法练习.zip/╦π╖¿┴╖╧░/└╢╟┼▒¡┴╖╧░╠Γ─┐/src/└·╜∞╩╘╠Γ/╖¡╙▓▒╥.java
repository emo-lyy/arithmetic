package ��������;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class ��Ӳ�� {
	static String end;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String begin=scanner.next();
		end=scanner.next();
		scanner.close();
		Set<String> S=new HashSet<>();
		S.add(begin);
		dfs(S,0);
	}
	static void dfs(Set<String> S,int count) {
		if(check(S)) {
			System.out.println(count);
			return;
		}
		Set<String> res=new HashSet<>();
		for (String s : S) {
			char[] A=s.toCharArray();
			for(int i=0;i<A.length-1;i++) {
					//��ת�������ڵ�����
				reversal(i,A);
				reversal(i+1,A);
					
				String temp=new String(A);
				
				res.add(temp);
					//���ݣ���ԭ�ȷ�ת�����һ�����
				reversal(i,A);
				reversal(i+1,A);
			}
		}
		dfs(res,count+1);
	}
	
	//��ת����
	static void reversal(int index,char[] A) {
		if(A[index]=='*') A[index]='o';
		else if(A[index]=='o') A[index]='*';
	} 
	
	static boolean check(Set<String> S) {
		if(S.contains(end))return true;
		else return false;
	}
}
