package ��������;

/**
 * ע����������Ĵ���
 * @author ��ħ
 *
 */
public class ƽ��ʮλ�� {
	static Long res=(long)0;	//����ƽ��ֵ
	public static void main(String[] args) {
		long begin=System.currentTimeMillis();
		char[] A="0123456789".toCharArray();
		dfs(A,0);
		System.out.println("------------------------");
		System.out.println(res);
		System.out.println(Math.sqrt(res));
		long end=System.currentTimeMillis();
		System.out.println("time:"+(end-begin)+"ms");
	}
	
	static void dfs(char[] A,int n) {
		if(n==A.length) {
			String s=new String(A);
			//System.out.println(s);
			Long k=Long.parseLong(s);
			System.out.println(k);
			long temp=(long)Math.sqrt(k);
			if(temp*temp==k) {
				res=res>k?res:k;
			}
			return;
		}
		for(int i=n;i<A.length;i++) {
			swap(A,i,n);
			dfs(A,n+1);
			swap(A,i,n);	//����
		}
	}
	
	static void swap(char[] A,int i,int j) {
		char temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
}
