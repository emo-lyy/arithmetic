package ��������;

import java.util.Scanner;

public class ���б�ɫ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int begin=scanner.nextInt();
		int end=scanner.nextInt();
		scanner.close();
		int count=0;
		for(int i=begin;i<=end;i++) {
			if(i%2==1) {
				count++;
			}
		}
		System.out.println(count);
	}
}
