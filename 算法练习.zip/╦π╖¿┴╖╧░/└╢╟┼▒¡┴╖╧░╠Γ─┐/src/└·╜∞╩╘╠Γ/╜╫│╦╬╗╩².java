package ��������;

import java.math.BigInteger;
import java.util.Scanner;

public class �׳�λ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		BigInteger count=BigInteger.ONE;
		for(int i=2;i<=n;i++) {
			count=count.multiply(new BigInteger(i+""));
		}
		String res=count.toString(2);
		System.out.println(res.length());
	}
}
