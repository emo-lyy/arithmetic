package ��������;

import java.util.Scanner;

/*
 * ע��n>m
 */
public class �ƶ����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int w=scanner.nextInt();
		int m=scanner.nextInt();
		int n=scanner.nextInt();
		scanner.close();
		if(m>n) {
			int temp=m;
			m=n;
			n=temp;
		}
		int row=n/w+1;
		int[][] A=new int[row][w];
		boolean b=true;		//���ڿ������г���
		int count=1;
		
		int x1=-1;
		int y1=-1;
		int x2=-1;
		int y2=-1;
		for(int i=0;i<row;i++) {
			if(b) {
				for(int j=0;j<w;j++) {
					A[i][j]=count;
					if(count==m) {
						x1=i;
						y1=j;
					}
					if(count==n) {
						x2=i;
						y2=j;
					}
					if(j==w-1) {
						b=false;
					}
					count++;
				}
			}
			else {
				for(int j=w-1;j>=0;j--) {
					A[i][j]=count;
					
					if(count==m) {
						x1=i;
						y1=j;
					}
					if(count==n) {
						x2=i;
						y2=j;
					}
					
					if(j==0) {
						b=true;
					}
					count++;
				}
			}
		}
	//	out(A);		//�������鱣�����
		int x=Math.abs(x2-x1);
		int y=Math.abs(y2-y1);
		System.out.println(x+y);
	}
	
	static void out(int[][] A) {
		for(int i=0;i<A.length;i++) {
			for(int j=0;j<A[0].length;j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
}
