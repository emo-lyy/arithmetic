package ��������;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class �ӷ���˷� {
	public static void main(String[] args) {
		dfs(48,2,"49");
	}
	static void dfs(int n,int k,String s){
		if(n==0) {
			 ScriptEngine js = new ScriptEngineManager().getEngineByName("js");	//�������㷽��--���ַ�����������ִ�
			 try {
				int sum=(int)js.eval(s);
				if(sum==2015) {
					System.out.println(s);
				}
			} catch (Exception e) {
				System.out.println("app error");
			}
			return;
		}
		String temp1=s;
		String temp2=s;
		if(k>0) {
			temp1+="+"+n;
			dfs(n-1,k,temp1);
			temp2+="*"+n;
			dfs(n-1,k-1,temp2);
		}
		else {
			temp1+="+"+n;
			dfs(n-1,k,temp1);
		}
		
	}
	
 	
}
