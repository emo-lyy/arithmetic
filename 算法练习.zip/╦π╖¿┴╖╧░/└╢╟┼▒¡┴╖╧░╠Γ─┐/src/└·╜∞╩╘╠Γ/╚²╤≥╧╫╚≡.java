package ��������;

public class �������� {
	public static void main(String[] args) {
		for(int i=1000;i<10000;i++) {
			for(int j=1000;j<10000;j++) {
				int a1=i/1000;
				int b1=i%1000/100;
				int c1=i%100/10;
				int d1=i%10;
				
				int a2=j/1000;
				int b2=j%1000/100;
				int c2=j%100/10;
				int d2=j%10;
				if(a1!=b1 && b1!=c1 && c1!=d1 && d1!=a1 
					&& a2!=b2 && b2!=c2 && c2!=d2 && d2!=a2 
					&& a1!=a2 && a1!=b2 && a1!=c2 && a1!=d2 && 
					b1!=a2 && b1!=b2 && a1!=c2&& c1!=a2 && c1!=b2 
					&& c1!=c2	 && c1!=d2	&& d1 !=a2 && d1!=b2 && d1!=c2 && d1!=d2
					) {
					if(b1==d2) {
						for(int k=0;k<10;k++) {
							if(k!=a2 && k!=b2 && k!=c1 && k!=b1) {
								int temp=Integer.valueOf(a2+""+b2+""+c1+""+b1+""+k);
								if(i+j==temp) {
									System.out.println(i+"+"+j+"="+(i+j));
								}
							}	
						}
					}
				}	
			}
		}
	}
}
