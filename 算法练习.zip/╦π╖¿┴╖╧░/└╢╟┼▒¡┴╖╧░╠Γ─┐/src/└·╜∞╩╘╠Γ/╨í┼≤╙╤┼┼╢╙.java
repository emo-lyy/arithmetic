package ��������;

import java.util.Scanner;

public class С�����Ŷ� {
	static int[] B;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] A=new int[n];
		B=new int[n];
		for(int i=0;i<n;i++)A[i]=scanner.nextInt();
		scanner.close();
		f(A);
	}
	static void f(int[] A) {
        for(int i =0 ; i<A.length-1 ; i++) { 
            for(int j=0 ; j<A.length-1-i ; j++) {  
            	if(A[j]>A[j+1]) {
            		B[j]++;
            		B[j+1]++;
            		swap(A,j,j+1);
            		swap(B,j,j+1);
            	} 
            }    
        }
        close();
    }
	
	static void close() {
		long sum=0;
		for(int i : B) {
			sum+=count(i);
		}
		System.out.println(sum);
	}
	
	static long count(int n) {
		long res=0;
		for(int i=1;i<=n;i++) {
			res+=i;
		}
		return res;
	}
	
	static void swap(int[] A,int i,int j) {
		int temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
	
	static void out(int[] A) {
		for (int i : A) {
			System.out.print(i+" ");
		}
		System.out.println();
	}
}
