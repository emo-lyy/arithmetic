package ��������;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ��ѹ���� {
	public static void main(String[] args) {
		int[][] data=new int[30][30];
		Scanner scanner=new Scanner(System.in);
		for(int i=0;i<29;i++) {
			for(int j=0;j<=i;j++) {
				data[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		f(data);
	}
	public static void f(int[][] data) {
		double[][] res=new double[30][30];
		res[0][0]=data[0][0];
		/*for(int i=0;i<30;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(data[i][j]+" ");
			}
			System.out.println();
		}*/
		double[][] temp=dfs(data,res,0);
		/*for(int i=0;i<30;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(temp[i][j]+" ");
			}
			System.out.println();
		}*/
		ArrayList<Double> box=new ArrayList<>();
		for(int i=0;i<30;i++) {
			box.add(temp[29][i]);
		}
		Collections.sort(box);
		double min=box.get(0);
		double max=box.get(29);
		System.out.println((2086458231/min)*max);
	}
	public static double[][] dfs(int[][] data,double[][] res,int i) {
		if(i==data.length-1) {
			return res;
		}
		for(int j=0;j<=i+1;j++) {
			res[i+1][j]+=data[i+1][j];
			//System.out.print(i+1+","+j+" ");
		}
		for(int j=0;j<=i;j++) {
			res[i+1][j+1]+=res[i][j]/2.0;
			res[i+1][j]+=res[i][j]/2.0;
		}
		//System.out.println();
		return dfs(data,res,i+1);
		
	}
}
