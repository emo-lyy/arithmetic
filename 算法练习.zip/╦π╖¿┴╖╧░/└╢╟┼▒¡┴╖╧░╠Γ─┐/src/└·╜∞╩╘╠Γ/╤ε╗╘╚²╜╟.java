package ��������;

public class ������� {
	public static void main(String[] args) {
		System.out.println(f(6,2));
		System.out.println(f(6,3));		
	}
	// ��������εĵ�row�е�col��
		static long f(int row, int col){
			if(row<2) return 1;
			if(col==0) return 1;
			if(col==row) return 1;
			
			long[] a = new long[row+1];
			a[0]=1;
			a[1]=1;
			
			int p = 2;
			
			while(p<=row){
				a[p] = 1;
				for(int q=p-1;q>0;q--) {
					a[q] = a[q] + a[q-1];
					System.out.println("p: "+p+"   q: "+q+"  "+"  a["+q+"]:  "+a[q]);
				}
				
				p++;
			}
			System.out.println("--------------------------");
			return a[col];
		}
}
