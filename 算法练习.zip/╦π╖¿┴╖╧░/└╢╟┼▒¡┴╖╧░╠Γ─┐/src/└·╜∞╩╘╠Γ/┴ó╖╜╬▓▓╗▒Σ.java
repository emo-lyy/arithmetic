package ��������;

import java.math.BigInteger;
import java.util.Scanner;

public class ����β���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int count=0;
		for(int i=1;i<=n;i++) {
			BigInteger A=BigInteger.ONE;
			for(int j=1;j<=3;j++) {
				A=A.multiply(new BigInteger(i+""));
			}
			String s1=i+"";
			String s2=A.toString();
			String s3=s2.substring(s2.length()-s1.length(), s2.length());
			
			if(s1.equals(s3)) {
				System.out.println(s1);
				System.out.println(s2);
				System.out.println(s3);
				System.out.println("-------------------");
				count++;
			}
		}
		System.out.println(count);
	}
}
