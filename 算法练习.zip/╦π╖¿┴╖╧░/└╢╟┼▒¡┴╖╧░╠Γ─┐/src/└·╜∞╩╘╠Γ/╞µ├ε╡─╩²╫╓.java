package ��������;

public class ��������� {
	public static void main(String[] args) {
		int n=10;
		while(n++<1000) {
			int a=(int)Math.pow(n, 2);
			int b=(int)Math.pow(n, 3);
			String s=a+""+b;
			if(check(s)) {
				//System.out.println(s);
				System.out.println(n);
				break;
			}
		}
	}
	static boolean check(String s) {
		if(s.length()!=10)return false;
		boolean[] B=new boolean[10];
		int[] A= {0,1,2,3,4,5,6,7,8,9};
		char[] C=s.toCharArray();
		for(int i=0;i<C.length;i++) {
			for(int j=0;j<A.length;j++) {
				if(C[i]-'0'==A[j]) {
					if(B[j]==false) {
						B[j]=true;
					}
					else {
						return false;
					}
					break;
				}
			}
		}
		return true;
	}
}
