package ��������;

import java.util.Scanner;

public class ��λ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		String n=s;		//����һ��
		while(n.length()>1) {
			int temp=0;
			for(int i=0;i<n.length();i++) {
				temp+=Integer.valueOf(n.charAt(i)+"");
			}
			n=temp+"";
		}
		System.out.println(n);
	}
}
