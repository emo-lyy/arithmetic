package ��������;

import java.util.Scanner;

public class ��λ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int begin=scanner.nextInt();
		int end=scanner.nextInt();
		scanner.close();
		long res=f(begin,end);
		System.out.println(res);
	}
	public static long f(int begin,int end) {
		long sum=0;
		for(int i=begin;i<=end;i++) {
			String[] S=(i+"").split("");
			for (String s : S) {
				sum+=Integer.valueOf(s);
			}
		}
		return sum;
	}
}
