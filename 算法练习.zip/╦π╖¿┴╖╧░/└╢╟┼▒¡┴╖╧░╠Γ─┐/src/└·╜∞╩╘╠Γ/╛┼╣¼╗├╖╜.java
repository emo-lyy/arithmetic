package ��������;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class �Ź��÷� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int[][] A=new int[3][3];
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++)A[i][j]=scanner.nextInt();
		}
		scanner.close();
		f(A);
	}
	//��ڷ��������￪ʼ
	static void f(int[][] A) {
		dfs(0,0,A);
		System.out.println("Too Many");
	}
	
	static void dfs(int x,int y,int[][] A) {
		if(x==3) {
			if(check2(A)) {
				for(int i=0;i<A.length;i++) {
					for(int j=0;j<A[0].length;j++) {
						System.out.print(A[i][j]+" ");
					}
					System.out.println();
				}
				System.exit(0);
			}
			return;
		}
		if(A[x][y]==0) {
			for(int i=1;i<=10;i++) {
				if(check1(i,A)) {
					A[x][y]=i;
					dfs(x+(y+1)/3,(y+1)%3,A);
					A[x][y]=0;
				}
			}
		}
		else {
			dfs(x+(y+1)/3,(y+1)%3,A);
		}
	}
	
	/**
	 * �жϸ���ֵ�ɲ�������������
	 * @param n	Ҫ�������ֵ
	 * @param A	�����������
	 * @return
	 */
	static boolean check1(int n,int[][] A) {
		for(int i=0;i<A.length;i++) {
			for(int j=0;j<A[0].length;j++) {
				if(A[i][j]==n)return false;
			}
		}
		return true;
	}
	
	/**
	 * �жϸ���ֵ�ǲ�����������
	 * @param A
	 * @return
	 */
	static boolean check2(int[][] A) {
		Set<Integer> x=new HashSet<>();
		Set<Integer> y=new HashSet<>();
			
		for(int i=0;i<3;i++) {
			int tempx=0;
			int tempy=0;
			for(int j=0;j<3;j++) {
				tempx+=A[i][j];
				tempy+=A[j][i];
			}
			
			x.add(tempx);
			y.add(tempy);
			if(x.size()!=1 || y.size()!=1)return false;
		}
			
		int n=0;
		int m=0;
		for(int i=0;i<A.length;i++) { 
			for(int j=0;j<A[0].length;j++) {
				if(i==j) {
					n+=A[i][j];
				}
				if(i+j==A[0].length-1) {
					m+=A[i][j];
				}
			} 
		}
		if(n!=m)return false;
		return true;
	}
}
