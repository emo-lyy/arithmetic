package ����ѵ��;

import java.math.BigInteger;
import java.util.Scanner;

public class ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		//BigInteger sum=BigInteger.ZERO;
		long sum=0;
		for(int i=1;i<=n;i++) {
			//sum=sum.add(BigInteger.valueOf(i));
			sum+=i;
		}
		System.out.println(sum);
	}
}
