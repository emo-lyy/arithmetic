package ����ѵ��;

import java.util.Scanner;

public class Fibonacci���� {
	private static int mod=10007;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		long res=f(n);
		System.out.println(res);
	}
	public static long f(int n) {
		if(n==1 || n==2)return 1;
		long a=1;
		long b=1;
		long sum=a+b;
		int count=3;
		while(count<n) {
			a=b;
			long temp=b;
			b=sum;
			sum+=temp%mod;
			count++;
		}
		return sum%mod;
	}
}
