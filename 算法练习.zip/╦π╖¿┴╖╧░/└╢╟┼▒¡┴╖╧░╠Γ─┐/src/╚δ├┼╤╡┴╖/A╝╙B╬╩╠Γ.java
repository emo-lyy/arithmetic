package ����ѵ��;

import java.util.Scanner;

public class A��B���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		scanner.close();
		System.out.println(a+b);
	}
}
