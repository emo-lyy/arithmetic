package ������ϰ;

import java.util.Scanner;

public class �ַ����Ա� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s1=scanner.next();
		String s2=scanner.next();
		scanner.close();
		f(s1,s2);
	}
	
	public static void f(String s1,String s2) {
		if(s1.length()==s2.length()) {
			if(s1.equals(s2)) System.out.println(2);
			else {
				String temp1=s1.toLowerCase();
				String temp2=s2.toLowerCase();
				if(temp1.equals(temp2))System.out.println(3);
				else System.out.println(4);
			}
		}
		else System.out.println(1);
	}
}
