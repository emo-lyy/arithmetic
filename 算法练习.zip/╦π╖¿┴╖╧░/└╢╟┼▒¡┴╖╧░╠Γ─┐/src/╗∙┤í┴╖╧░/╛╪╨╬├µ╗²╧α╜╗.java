package ������ϰ;

import java.util.Scanner;

public class ��������ཻ {
	public static void main(String[] args) {
		Coordinates[] A=new Coordinates[2];
		Coordinates[] B=new Coordinates[2];
		Coordinates[] temp=new Coordinates[2];
		Scanner scanner=new Scanner(System.in);
		for(int i=0;i<2;i++) {
			A[i]=new Coordinates(scanner.nextDouble(),scanner.nextDouble());
		}
		for(int i=0;i<2;i++) {
			B[i]=new Coordinates(scanner.nextDouble(),scanner.nextDouble());
		}
		scanner.close();
		//���Ͻǵ�����
		double x1=Math.min((Math.max(A[0].getX(), A[1].getX())),(Math.max(B[0].getX(), B[1].getX())));
		//System.out.println(x1);
		double y1=Math.min((Math.max(A[0].getY(), A[1].getY())),(Math.max(B[0].getY(), B[1].getY())));
		//System.out.println(y1);
		temp[0]=new Coordinates(x1,y1);
		
		//���½�����
		double x2=Math.max((Math.min(A[0].getX(), A[1].getX())), (Math.min(B[0].getX(),B[1].getX())));
		double y2=Math.max((Math.min(A[0].getY(), A[1].getY())), (Math.min(B[0].getY(), B[1].getY())));
		//System.out.println(x2);
		//System.out.println(y2);
		temp[1]=new Coordinates(x2,y2);
		
		if(temp[0].getX()<temp[1].getX() || temp[0].getY()<temp[1].getY()) {
			System.out.println("0.00");
		}
		else {
			double width=temp[0].getX()-temp[1].getX();
			double hight=temp[0].getY()-temp[1].getY();
			System.out.printf("%.2f",width*hight);
		}
		
	}

	public static class Coordinates{
		private double x;
		private double y;
		public Coordinates(double x, double y) {
			super();
			this.x = x;
			this.y = y;
		}
		/**
		 * @return the x
		 */
		public double getX() {
			return x;
		}
		/**
		 * @param x the x to set
		 */
		public void setX(double x) {
			this.x = x;
		}
		/**
		 * @return the y
		 */
		public double getY() {
			return y;
		}
		/**
		 * @param y the y to set
		 */
		public void setY(double y) {
			this.y = y;
		}
		
		public Coordinates() {};
		
	}
}
