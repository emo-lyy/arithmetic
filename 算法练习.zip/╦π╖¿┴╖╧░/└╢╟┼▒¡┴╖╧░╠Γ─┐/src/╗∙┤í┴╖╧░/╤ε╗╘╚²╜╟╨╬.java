package ������ϰ;

import java.util.Scanner;

public class ��������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int[][] data=new int[n][n];
		f(data);
	}
	
	public static void f(int[][] data) {
		for(int i=0;i<data.length;i++) {
			for(int j=0;j<=i;j++) {
				if(j==0)data[i][j]=1;
				if(i==j) data[i][j]=1;
				if(i>1 && j<i && j>0) data[i][j]=data[i-1][j-1]+data[i-1][j];
				System.out.print(data[i][j]+" ");
			}
			System.out.println();
		}
	}
}
