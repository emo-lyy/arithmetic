package ������ϰ;

import java.math.BigInteger;
import java.util.Scanner;

public class ʮ������תʮ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		String n=new BigInteger(s,16).toString(10);
		System.out.println(n);
	}
}
