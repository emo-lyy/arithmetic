package ������ϰ;

import java.util.Scanner;

public class ��������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		f(n);
	}
	public static void f(int n) {
		for(int i=10000;i<1000000;i++) {
			if(check(i,n)) {
				System.out.println(i);
			}
		}
	}
	
	public static boolean check(int n,int k) {
		String s=n+"";
		if(s.length()%2==0) {
			int a=n/100000;
			int b=n%100000/10000;
			int c=n%10000/1000;
			int d=n%1000/100;
			int e=n%100/10;
			int f=n%10;
			/*System.out.println(a);
			System.out.println(b);
			System.out.println(c);
			System.out.println(d);
			System.out.println(e);
			System.out.println(f);*/
			int sum=a+b+c+d+e+f;
			if(a==f && b==e && c==d && sum==k)return true;
		}
		else {
			int b=n%100000/10000;
			int c=n%10000/1000;
			int d=n%1000/100;
			int e=n%100/10;
			int f=n%10;
			int sum=b+c+d+e+f;
			if(b==f && c==e && sum==k)return true;
		}
		return false;
	}
}
