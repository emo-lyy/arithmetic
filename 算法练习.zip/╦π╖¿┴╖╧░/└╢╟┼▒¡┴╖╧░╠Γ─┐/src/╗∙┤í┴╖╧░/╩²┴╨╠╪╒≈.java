package ������ϰ;

import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++)data[i]=scanner.nextInt();
		scanner.close();
		f(data);
	}
	public static void f(int[] data) {
		int max=data[0];
		int min=data[0];
		long sum=data[0];
		for(int i=1;i<data.length;i++) {
			max=max>data[i]?max:data[i];
			min=min<data[i]?min:data[i];
			sum+=data[i];
		}
		System.out.println(max);
		System.out.println(min);
		System.out.println(sum);
	}
}
