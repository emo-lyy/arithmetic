package ������ϰ;

import java.math.BigInteger;
import java.util.Scanner;

public class ʮ������ת�˽��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String[] data=new String[n];
		for(int i=0;i<n;i++)data[i]=scanner.next();
		scanner.close();
		f(data);
	}
	public static void f(String[] data) {
		for(int i=0;i<data.length;i++) {
			String s=data[i];
			String b=new BigInteger(s,16).toString(8);
			System.out.println(b);
		}
	}
}
