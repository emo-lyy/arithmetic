package ������ϰ;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * ˼·:��Ϊ���ǺõĶ࣬���Բ��Խ��һ���ľӶ�
 * @author ��ħ
 *
 */
public class оƬ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String[] S=new String[n];
		int[][] data=new int[n][n];
		for(int i=0;i<n;i++) {
			String temp="";
			for(int j=0;j<n;j++) {
				data[i][j]=scanner.nextInt();
				temp+=data[i][j]+"";
			}
			S[i]=temp;
		}
		scanner.close();
		f(n,S);
	}
	public static void f(int n,String[] data) {
		ArrayList<String> temp=new ArrayList<>();
		for (String s : data) {
			if(!temp.contains(s)) {
				temp.add(s);
			}
		}
		int max=0;
		String maxName="";
		for (String s1 : temp) {
			int c=0;
			for (String s2 : data) {
				if(s1.equals(s2))c++;
			}
			if(c>max) {
				max=c;
				maxName=s1;
			}
		}
		
		for(int i=0;i<n;i++) {
			if(maxName.equals(data[i]))System.out.print(i+1+" ");
		}
	}
	
}
