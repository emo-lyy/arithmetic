package ������ϰ;

import java.util.Scanner;

public class Sine֮�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		String res=Sn(n,n);
		System.out.println(res);
	}
	public static String Sn(int n, int index) {
		 if (index == 1) {
	            return An(1, 1, "")+"+"+n;
	        }
	        return "("+Sn(n,index-1)+")"+An(index,1,"")+"+"+(n - index + 1);
	}
	
	public static String An(int n,int index,String s) {
		if (n == index) {
            return "sin("+index+")";
        }
        String operation = "-";
        if (index % 2 == 0) {
            operation = "+";
        }
        return s+"sin("+index+operation+An(n, index + 1, s)+")";
	}
}
