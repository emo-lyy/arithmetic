package ������ϰ;

import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		int k=scanner.nextInt();
		scanner.close();
		int res=f(data,k);
		System.out.println(res);
	}
	public static int f(int[] data,int k) {
		for(int i=0;i<data.length;i++) {
			if(data[i]==k)return i+1;
		}
		return -1;
	}
}
