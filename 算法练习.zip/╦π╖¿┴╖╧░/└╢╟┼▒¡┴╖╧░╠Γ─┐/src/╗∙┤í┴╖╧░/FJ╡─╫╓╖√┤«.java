package ������ϰ;

import java.util.Scanner;

public class FJ���ַ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		String res=f(n);
		System.out.println(res);
	}
	public static String f(int n) {
		if(n==1)return "A";
		return f(n-1)+(char)('A'+(n-1))+f(n-1);
	}
}
