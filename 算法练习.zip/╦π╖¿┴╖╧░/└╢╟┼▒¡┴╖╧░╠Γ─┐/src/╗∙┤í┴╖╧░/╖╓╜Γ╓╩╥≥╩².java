package ������ϰ;

import java.util.ArrayList;
import java.util.Scanner;

public class �ֽ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int begin=scanner.nextInt();
		int end=scanner.nextInt();
		scanner.close();
		for(int i=begin;i<=end;i++) {
			f(i);
		}
	}
	public static void f(int n) {
		System.out.print(n+"=");
		ArrayList<Integer> temp=new ArrayList<>();
		for(int i=2;i<=Math.sqrt(n);i++) {
			while(n%i==0) {
				temp.add(i);
				n/=i;
			}
		}
		if(n!=1) temp.add(n);
		for(int i=0;i<temp.size();i++) {
			System.out.print(temp.get(i));
			System.out.print((i==temp.size()-1)?' ':'*');
		}
		System.out.println();
	}
}
