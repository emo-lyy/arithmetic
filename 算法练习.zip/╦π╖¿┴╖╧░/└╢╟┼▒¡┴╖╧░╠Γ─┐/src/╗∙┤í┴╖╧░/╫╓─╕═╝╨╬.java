package ������ϰ;

import java.util.Scanner;

public class ��ĸͼ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int x=scanner.nextInt();
		int y=scanner.nextInt();
		scanner.close();
		f(x,y);
	}
	public static void f(int x,int y) {
		char[][] A=new char[x][y];
		for(int i=0;i<x;i++) {
			for(int j=0;j<y;j++) {
				if(i==j) {
					A[i][j]='A';
				}
				else {
					int k=t(i-j);
					A[i][j]=(char)('A'+k);
				}
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public static int t(int n) {
		if(n<0)return -n;
		return n;
	}
}
