package ������ϰ;

public class ��һ�ִ� {
	public static void main(String[] args) {
		for(int a=0;a<2;a++) {
			for(int b=0;b<2;b++) {
				for(int c=0;c<2;c++) {
					for(int d=0;d<2;d++) {
						for(int f=0;f<2;f++) {
							System.out.println(a+""+b+""+c+""+d+""+f);
						}
					}
				}
			}
		}
	}
}
