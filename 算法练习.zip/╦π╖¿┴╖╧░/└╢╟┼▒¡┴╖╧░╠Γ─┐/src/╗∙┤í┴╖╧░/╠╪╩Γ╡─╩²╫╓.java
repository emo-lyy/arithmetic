package ������ϰ;

public class ��������� {
	public static void main(String[] args) {
		for(int i=100;i<1000;i++) {
			if(check(i)) {
				System.out.println(i);
			}
		}
	}
	public static boolean check(int n) {
		int a=n/100;
		int b=n%100/10;
		int c=n%10;
		if(a*a*a+b*b*b+c*c*c==n)return true;
		return false;
	}
}
