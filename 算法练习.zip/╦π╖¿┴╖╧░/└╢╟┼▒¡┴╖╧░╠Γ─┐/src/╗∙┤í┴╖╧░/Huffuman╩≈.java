package ������ϰ;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Huffuman�� {
	private static long sum=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		ArrayList<Integer> data=new ArrayList<>();
		for(int i=0;i<n;i++)data.add(scanner.nextInt());
		scanner.close();
		dfs(data);
		System.out.println(sum);
	}
	public static void dfs(ArrayList<Integer> data) {
		Collections.sort(data);
		//System.out.println(data);
		if(data.size()==1) {
			return;
		}
		else {
			ArrayList<Integer> temp=new ArrayList<>();
			for(int i=2;i<data.size();i++) {
				temp.add(data.get(i));
			}
			int count=data.get(0)+data.get(1);
			//System.out.println(count);
			temp.add(count);
			sum+=count;
			dfs(temp);
		}
	}
}
