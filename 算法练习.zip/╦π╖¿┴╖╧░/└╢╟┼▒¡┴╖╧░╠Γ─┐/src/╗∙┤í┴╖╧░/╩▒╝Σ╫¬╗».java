package ������ϰ;

import java.util.Scanner;

public class ʱ��ת�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int h=n/(60*60);
		//System.out.println(h);
		n-=h*60*60;
		int m=n/60;
		//System.out.println(m);
		int s=n-m*60;
		//System.out.println(f);
		System.out.println(h+":"+m+":"+s);
	}
}
