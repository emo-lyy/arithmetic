package ����_11_7;

import java.util.Scanner;

public class ������� {
	static int n;
	static int[] dp=new int[60];
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		scanner.close();
		initDP();
		int res=f(n);
		System.out.println(res);
	}
	
	static int f(int n) {
		if(n<=3)return dp[n-1];
		for (int i = 4; i <= n; i++) {
			for (int j = 1; j <= i/2; j++) {
				dp[i]=Math.max(dp[i], dp[j]*dp[i-j]);
			}
		}
		return dp[n];
	}
	
	static void initDP() {
		dp[0]=0;
		dp[1]=1;	
		dp[2]=2;
		dp[3]=3;
	}
}
