package ����_11_7;

import java.util.Scanner;

public class ��Ʊ���� {
	static int n;
	static int[] A;
	static int max=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new int[n];
		for (int i = 0; i < n; i++) {
			A[i]=scanner.nextInt();
		}
		scanner.close();
		f(A);
	}
	
	static void f(int[] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = i+1; j < A.length; j++) {
				int k=A[j]-A[i];
				max=Math.max(max, k);
			}
		}
		System.out.println(max);
	}
}
