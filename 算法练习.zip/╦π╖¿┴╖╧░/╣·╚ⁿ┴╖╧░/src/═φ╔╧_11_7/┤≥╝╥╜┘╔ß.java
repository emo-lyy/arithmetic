package ����_11_7;

import java.util.Scanner;

public class ��ҽ��� {
	static int n;
	static int[] A;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new int[n];
		for (int i = 0; i < n; i++) {
			A[i]=scanner.nextInt();
		}
		scanner.close();
		f(A);
	}
	
	static void f(int[] A) {
		int[] dp=new int[A.length];
		dp[0]=A[0];
		dp[1]=Math.max(A[0], A[1]);
		for (int i = 2; i < A.length; i++) {
			dp[i]=Math.max(dp[i-1], A[i]+dp[i-2]);
		}
		System.out.println(dp[n-1]);
	}
}
