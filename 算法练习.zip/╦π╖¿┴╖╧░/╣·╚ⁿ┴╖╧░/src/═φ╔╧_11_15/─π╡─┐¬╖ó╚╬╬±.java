package ����_11_15;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ��Ŀ������� {
	static int n;
	static List<String> A;
	static String S;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new ArrayList<String>();
		for (int i = 0; i < n; i++) {
			A.add(scanner.next().toLowerCase());		//ȫ����Сд�ж�
		}
		scanner.nextLine();		//ȥ��ǰ��Ŀո�
		S=scanner.nextLine();
		scanner.close();
		
		String[] data=S.split(" ");
		
		//System.out.println(Arrays.toString(data));
		
		for (int i = 0; i < data.length; i++) {
			if(A.contains(data[i].toLowerCase())) {
				//�������дʻ�
				System.out.print(isPwd(data[i])+" ");
			}else {
				System.out.print(data[i]+" ");
			}
		}
	}
	
	static String isPwd(String s) {
		String res=s.charAt(0)+"";
		for (int i = 1; i < s.length(); i++) {
			res+='*';
		}
		return res;
	}
}
