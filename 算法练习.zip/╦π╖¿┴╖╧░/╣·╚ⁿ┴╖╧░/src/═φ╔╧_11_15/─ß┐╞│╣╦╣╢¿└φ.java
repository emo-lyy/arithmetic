package ����_11_15;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ��Ƴ�˹���� {
	static int n;
	static long square;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		square=n*n;
		scanner.close();	
		System.out.print(n+"*"+n+"*"+n+" = ");
		
		List<Long> box=new ArrayList<Long>();
		for (long i = square-n; i <= square+n; i++) {
			if(i%2==1) {
				box.add(i);
			}
		}
		for (int i = 0; i < box.size(); i++) {
			if(i!=box.size()-1) {
				System.out.print(box.get(i)+" + ");
			}else {
				System.out.println(box.get(i));
			}
		}
	}
}
