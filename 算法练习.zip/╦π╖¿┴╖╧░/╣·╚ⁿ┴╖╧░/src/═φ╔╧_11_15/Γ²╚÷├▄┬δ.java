package ����_11_15;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class �������� {
	static String ciphertext="V W X Y Z A B C D E F G H I J K L M N O P Q R S T U ";		//����
	static String proclaimed="A B C D E F G H I J K L M N O P Q R S T U V W X Y Z";
	static List<String> A=new ArrayList<String>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		while (true) {
			String s=scanner.nextLine();
			if(s.equals("ENDOFINPUT")) {
				break;
			}else {
				if(!s.equals("START") && !s.equals("END")) {
					A.add(s);
				}
			}
			
		}
		scanner.close();
		for (String s : A) {
			char[] data=s.toCharArray();
			for (int i = 0; i < data.length; i++) {
				char key=data[i];
				int index=proclaimed.indexOf(key);
				if(index!=-1) {
					data[i]=ciphertext.charAt(index);
				}	
			}
			System.out.println(new String(data));
		}
	}
}
