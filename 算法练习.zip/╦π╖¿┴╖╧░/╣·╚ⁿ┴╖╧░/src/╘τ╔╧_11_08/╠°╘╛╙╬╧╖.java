package ����_11_08;

import java.util.Scanner;

public class ��Ծ��Ϸ {
	static int n;
	static int[] A;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new int[n+1];
		for (int i = 1; i < A.length; i++) {
			A[i]=scanner.nextInt();
		}
		scanner.close();
		dfs(1,A[1]);
		System.out.println("no");
	}
	
	/**
	 * 
	 * @param cur		��ǰ����λ��
	 * @param k		����Ծ�ĳ���
	 */
	static void dfs(int cur,int k) {
		if(cur>=n) {
			System.out.println("yes");
			System.exit(0);
		}
		for (int i = cur+1; i <= cur+k; i++) {
			dfs(i,A[i]);
		}
	}
}
