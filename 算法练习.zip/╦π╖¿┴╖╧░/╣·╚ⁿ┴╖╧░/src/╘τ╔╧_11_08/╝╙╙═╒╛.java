package ����_11_08;

import java.util.Scanner;

public class ����վ {
	static int n;
	static int[] add;
	static int[] sub;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		add=new int[n];
		sub=new int[n];
		for (int i = 0; i < n; i++) {
			add[i]=scanner.nextInt();
		}
		for (int i = 0; i < n; i++) {
			sub[i]=scanner.nextInt();
		}
		scanner.close();
		
		for (int i = 0; i < n; i++) {
			if(add[i]>=sub[i]) {
				if(dfs(i, add[i], 0)) {
					System.out.println(i);
					return;
				}
			}
		}
		
		System.out.println(-1);
	}
	
	/**
	 * �Ƿ񷵳�
	 * @param cur
	 * @param p
	 * @param k
	 * @return
	 */
	static boolean dfs(int cur,int p,int b) {
		if(p<0)return false;
		if(b==n-1) return true;
		
		if(cur==n-1) {
			//�������һ������վ
			if(p>=sub[cur]) 
				return dfs(0,p-sub[cur]+add[0],b+1);
			else 
				return false;
				
		}else {
			if(p>=sub[cur])
				return dfs(cur+1,p-sub[cur]+add[cur+1],b+1);
			else 
				return false;
		}
	}
}
