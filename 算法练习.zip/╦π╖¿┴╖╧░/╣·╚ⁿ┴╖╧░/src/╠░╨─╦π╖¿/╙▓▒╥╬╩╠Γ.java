package ̰���㷨;

import java.util.Scanner;

public class Ӳ������ {
	static int[] faceValue= {1,5,10,50,100,500};
	static int[] number=new int[6];
	static int totalValue;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		for (int i = 0; i < 6; i++) {
			number[i]=scanner.nextInt();
		}
		totalValue=scanner.nextInt();
		scanner.close();
		dp(faceValue.length-1,totalValue,0);
	}
	
	static void dp(int cur,int residue,int k) {
		if(residue==0) {
			System.out.println(k);
			return;
		}
		if(cur<0 || residue<0)return;
		if(residue>faceValue[cur]) {
			int p=Math.min(residue/faceValue[cur], number[cur]);
			dp(cur-1,residue-faceValue[cur]*p,k+p);
		}
	}
}
