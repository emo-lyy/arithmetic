package ̰���㷨;

import java.util.Arrays;
import java.util.Scanner;

public class Comparable��ʹ�� {
	static int n;
	static Obj[] objs;
	
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		objs=new Obj[n];
		
		//��ʼ������
		for (int i = 0; i < n; i++) {
			objs[i] = new Obj(scanner.nextInt(),scanner.nextInt());
		}
		scanner.close();
		
		System.out.println("����ǰ�� ");
		System.out.println("======================================");
		out(objs);
		
		
		System.out.println();
		
		Arrays.sort(objs);
		
		System.out.println("����� ");
		System.out.println("======================================");
		out(objs);
		
		
		
	}
	
	private static class Obj implements Comparable<Obj>{
		private int a;
		private int b;
		public int getA() {
			return a;
		}
		public void setA(int a) {
			this.a = a;
		}
		public int getB() {
			return b;
		}
		public void setB(int b) {
			this.b = b;
		}
		public Obj() {}
		public Obj(int a,int b) {
			this.a=a;
			this.b=b;
		}
		
		
		
		/**
		 * ��д���򷽷�
		 * @param o
		 * @return
		 */
		@Override
		public int compareTo(Obj o) {
			// TODO Auto-generated method stub
			return -(this.a-o.a);		//����  ������ ����		==>		(ǰ��Ӹ��ž��ǽ���)
		}
	}
	
	
	static void out(Obj[] objs) {
		for (int i = 0; i < objs.length; i++) {
			System.out.println(objs[i].getA() + " " + objs[i].getB());
		}
	}
}
