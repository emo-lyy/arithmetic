package ̰���㷨;

import java.util.Scanner;

public class ��ҩ_DFS {
	static int n;
	static int cnt;
	static long[][][] box;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		cnt=0;
		scanner.close();
		box=new long[n+1][n+1][2*n+1];
//		Arrays.fill(box, -1); 			//��ȫ��Ԫ�ر��-1
		long res=dfs(0,0,0);
		System.out.println(res);
	}
	
	static long dfs(int A,int B,int K) {
		if(box[A][B][K]!=0)return box[A][B][K];
		
		long res=0L;
		if(B>A)return 0;
		if(K==2*n) {
			//System.out.println(A +" "+ B);
			//cnt++;
			return 1;
		}
		if(A>B) {
			long p=dfs(A,B+1,K+1);		//�� B
			box[A][B+1][K+1]=p;
			res+=p;
					
			if(A+1<=n) {
				long q=dfs(A+1,B,K+1);
				box[A+1][B][K+1]=q;
				res+=q;
			}
			
		}else if(A==B) {
			long p=dfs(A+1,B,K+1);
			box[A+1][B][K+1]=p;
			res+=p;
		}
		return res;
	}
}
