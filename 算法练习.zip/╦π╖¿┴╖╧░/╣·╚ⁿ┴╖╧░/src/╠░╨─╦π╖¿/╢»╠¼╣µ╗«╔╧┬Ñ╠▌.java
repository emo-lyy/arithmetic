package ̰���㷨;

import java.util.Arrays;
import java.util.Scanner;

public class ��̬�滮��¥�� {
	static long[] A;
	static int n;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new long[n+1];
		Arrays.fill(A, -1);
		scanner.close();
		System.out.println(F(n));
	}
	
	static long F(int n) {
		if(A[n]!=-1) {
			return A[n];
		}
		
		if(n==1) {
			return A[n]=1;
		}
		
		if(n==2) {
			return A[n]=2;
		}
		
		return A[n]=F(n-1)+F(n-2);
	}
}
