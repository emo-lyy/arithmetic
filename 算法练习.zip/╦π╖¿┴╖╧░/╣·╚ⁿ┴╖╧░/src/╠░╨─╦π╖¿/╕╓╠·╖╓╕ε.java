package ̰���㷨;

import java.util.Scanner;

/**
 * δ����
 * @author ��ħ
 *
 */
public class �����ָ� {
	static int n;
	static int[] len;
	static int[] price;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		len=new int[n+1];
		price=new int[n+1];
		for (int i = 1; i <= n; i++) {
			len[i]=scanner.nextInt();
		}
		for (int i = 1; i <= n; i++) {
			price[i]=scanner.nextInt();
		}
		scanner.close();
		int res=F(n);
		System.out.println(res);
	}
	
	static int[] dp = new int[n+1]; 
	
	static int F(int l) {
		if(n==0)return 0;
		if(dp[l]!=0)return dp[l];
		
		int k=0;
		for (int i = 1; i <= l/2; i++) {
			int p=i;
			int f=l-i;
			k=Math.max(k, P(p) + F(f));
		}
		
		return dp[l]=k;
	}
	
	static int P(int n) {
		return price[n];
	}
}
