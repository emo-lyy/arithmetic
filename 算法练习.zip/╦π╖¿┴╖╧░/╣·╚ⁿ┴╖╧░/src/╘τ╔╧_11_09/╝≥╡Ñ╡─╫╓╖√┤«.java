package ����_11_09;

import java.util.Scanner;

public class �򵥵��ַ��� {
	static int n;
	static String[] S; 
	public static void main(String[] args) { 
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		S=new String[n];
		for (int i = 0; i < n; i++) {
			S[i]=scanner.next();
		}
		scanner.close();
		f();
	}
	
	static void f() {
		for (String s : S) {
			String res=f(s);
			System.out.println(res);
		}
	}
	
	static String f(String s) {
		StringBuffer sb=new StringBuffer();
		String[] data=s.split("");
		for (int i = 0; i < data.length; i++) {
			String p=data[i];
			//System.out.println(p);
			int count=1;
			
			for (int j = i+1; j < data.length; j++) {
				if(p.equals(data[j])) {
					count++;
				}
			}
			
			i+=count-1;
			
			if(count>1) sb.append(count);
			sb.append(p);
			
			
		}
		return sb.toString();
	}
}
