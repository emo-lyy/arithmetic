package ����_11_09;

import java.util.Scanner;

public class Ѱ������Ļ����� {
	static int n;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		scanner.close();
		f();
	}
	
	static void f() {
		for (int i = 1; i < 10000000; i++) {
			int a=n+i;		//������
			int b=n-i;		//������
			if(check(a+"")) {
				System.out.println(a);
				return;
			}
			if(check(b+"")) {
				System.out.println(b);
				return;
			}
		}
	}
	
	static boolean check(String s) {
		int len=s.length();
		String s1=null;
		String s2=null;
		if(len%2==0) {
			s1=s.substring(0,len/2);
			s2=new StringBuffer(s.substring(len/2,len)).reverse().toString();
		}else {
			s1=s.substring(0,len/2);
			s2=new StringBuffer(s.substring(len/2+1, len)).reverse().toString();
		}
		if(s1.equals(s2))return true;
		return false;
	}
}
