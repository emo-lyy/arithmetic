package ����_11_09;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class �ع�ȡ�� {
	static int n,m,k;
	static int[][] A;
	static int mod=1000000007;
	static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		k=scanner.nextInt();
		A=new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				A[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		
		//out(A);
		List<Coordinates> coordinates=new ArrayList<>();
		coordinates.add(new Coordinates(0, 0));
		dfs(0,0,coordinates);
		
		System.out.println(count%mod);
		//System.out.println("�ܹ��� : "+count%mod);
	}
	
	/**
	 * 
	 * @param y	��ǰ��y����
	 * @param x	��ǰ��x����
	 * @param coordinates		�������
	 */
	static void dfs(int y,int x,List<Coordinates> coordinates) {
		if(y==n-1 && x==m-1) {
			//out(coordinates);
			choose(coordinates,0,new ArrayList<>());
			return ;
		}
		
		if(y+1<n) {
			coordinates.add(new Coordinates(y+1, x));
			dfs(y+1,x,coordinates);
			coordinates.remove(coordinates.size()-1);
		}
		
		if(x+1<m) {
			coordinates.add(new Coordinates(y, x+1));
			dfs(y,x+1,coordinates);
			coordinates.remove(coordinates.size()-1);
		}
		
	}
	
	/**
	 * ѡȡ��Ʒ
	 * @param coordinates	���꼯��
	 */
	static void choose(List<Coordinates> coordinates,int cur,List<Integer> data) {
		if(data.size()>k)return;
		if(cur==coordinates.size()) {
			if(data.size()==k) {
		//		System.out.println(data);
				count++;
			}
			return;
		}
		
		Coordinates coordinate=coordinates.get(cur);		//��ǰ��ֵ
		int k=A[coordinate.y][coordinate.x];
		
		if(checkAdd(k, data)) {		//�����߸���Ʒ
			data.add(k);				//����
			choose(coordinates,cur+1,data);
			data.remove(data.size()-1);
			
			choose(coordinates,cur+1,data);				//������
		}else {					//�������߸���Ʒ
			choose(coordinates,cur+1,data);
		}
	}
	
	
	static boolean checkAdd(int k,List<Integer> data) {
		if(data.size()==0)return true;
		for (Integer i : data) {
			if(i>=k)return false;
		}
		return true;
	}
	
	static void out(int[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[0].length; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	
	static void out(List<Coordinates> coordinates) {
		System.out.print("("+coordinates.get(0).y +" , "+coordinates.get(0).x+")" +"		==>		");
		for (int i = 1; i < coordinates.size()-1; i++) {
			System.out.print("("+coordinates.get(i).y +" , "+coordinates.get(i).x+")" +"		==>		");
		}
		System.out.println("("+coordinates.get(coordinates.size()-1).y +" , "+coordinates.get(coordinates.size()-1).x+")");
	}
	
	private static class  Coordinates{
		public int y;
		public int x;
		public Coordinates(int y,int x) {
			this.y=y;
			this.x=x;
		}
	}
}
