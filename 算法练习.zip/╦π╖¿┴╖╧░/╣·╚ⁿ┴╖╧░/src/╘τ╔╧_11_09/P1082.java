package ����_11_09;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class P1082 {
	static int n;
	static List<String> S;
	static List<Long> A; 
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		S=new ArrayList<>();
		A=new ArrayList<>();
		n=scanner.nextInt();
		for (int i = 0; i < n; i++) {
			S.add(scanner.next());
		}
		
		for (int i = 0; i < n; i++) {
			A.add(scanner.nextLong());
		}
		scanner.close();
		f();
	}
	
	static void f() {
		Collections.sort(S);
		Collections.sort(A);
		for (int i = 0; i < n; i++) {
			System.out.println(S.get(i)+" "+A.get(i));
		}
	}
}
