package ����_11_09;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Ϊ�߶���������� {
	static int n,m;		//����ĳ���
	static int[][] A;		//����
	static int[] P;		//���ĸ߶�
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		P=new int[n*m];
		
		int index=0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				int k=scanner.nextInt();
				A[i][j]=k;
				P[index]=k;
				index++;
			}
		}
		scanner.close();
		Arrays.sort(P);
		f();
	}
	
	static void f() {
		//YX begin_yx=new YX(0,0);		//��ʼ����
		
		//System.out.println(Arrays.toString(P));;
		
		int y=0;
		int x=0;
		
		int count=0;
		while(true) {
			int len=getLen(A[y][x]);		//��һ��Ҫ�������߶�
			
			if(len==-1) break;
			
			//System.out.println(len);
			
			YX end_yx=getYX(len);
			
			List<YX> box=new ArrayList<>();
			box.add(new YX(y,x));			
			int res=bfs(box,0,end_yx,System.currentTimeMillis());
			count+=res;
			
			y=end_yx.y;
			x=end_yx.x;
		}
		System.out.println(count);
	}
	
	
	static boolean check(List<YX> YX,YX end_yx) {
		for (YX Q : YX) {
			if(Q.y==end_yx.y && Q.x==end_yx.x)return true;
		}
		return false;
	}
	
	static int bfs(List<YX> YX,int cur,YX end_yx,long time) {
		if(check(YX,end_yx)) {
			return cur;
		}
		
		List<YX> box=new ArrayList<YX>();
		for (YX q : YX) {
			int y=q.y;
			int x=q.x;
			
			//top
			if(y-1>=0 && A[y-1][x]!=0) {
				box.add(new YX(y-1,x));
			}
			
			//left
			if(x-1>=0 && A[y][x-1]!=0) {
				box.add(new YX(y,x-1));
			}
			
			//right
			if(x+1<m && A[y][x+1]!=0) {
				box.add(new YX(y,x+1));
			}
			
			//down
			if(y+1<n && A[y+1][x]!=0) {
				box.add(new YX(y+1,x));
			}
		}
		long t=System.currentTimeMillis();
		if(t-time>800) {
			System.out.println(-1);
			System.exit(0);
		}
		return bfs(box,cur+1,end_yx,time);
	}
	
	/**
	 * ��ȡ��һ�����ĸ߶�
	 * @return
	 */
	static int getLen(int len) {
		for (int i = 0; i < P.length; i++) {
			if(P[i]>len)return P[i];
		}
		return -1;
	}
	
	/**
	 * �������ĸ߶ȣ���ȡ����λ��
	 * @param len
	 * @return
	 */
	static YX getYX(int len) {
		YX yx=new YX(0,0);
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(A[i][j]==len) {
					return new YX(i,j);
				}
			}
		}
		return yx;
	}
	
	private static class YX{
		public int y;
		public int x;
		public YX(int y,int x) {
			this.y=y;
			this.x=x;
		}
	}
}
