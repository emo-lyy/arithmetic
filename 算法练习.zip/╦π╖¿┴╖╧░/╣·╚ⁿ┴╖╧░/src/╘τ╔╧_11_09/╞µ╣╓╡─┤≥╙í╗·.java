package ����_11_09;

import java.util.Scanner;

public class ��ֵĴ�ӡ�� {
	static String s;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		s=scanner.next();
		scanner.close();
		f();
	}
	static void f() {
		int res=number(s);
		System.out.println(res+1);
	}
	
	static int number(String s) {
		int count=0;
		for (int i = 0; i < s.length()-1; i++) {
			char a=s.charAt(i);
			char b=s.charAt(i+1);
			
			if(a!=b) {
				//System.out.println(a+""+b);
				count++;
				i+=1;
			}
			
		}
		return count;
	}
	
}
