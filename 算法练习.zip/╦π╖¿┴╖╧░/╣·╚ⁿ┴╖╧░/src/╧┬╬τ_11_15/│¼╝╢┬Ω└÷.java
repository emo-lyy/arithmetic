package ����_11_15;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class �������� {
	static List<Integer> A;
	static int n;
	static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		int m=scanner.nextInt();
		A=new ArrayList<Integer>();
		for (int i = 0; i < m; i++) {
			A.add(scanner.nextInt());
		}
		scanner.close();
		f(1);
		System.out.println(count);
	}
	
	static void f(int cur) {
		if(A.contains(cur) || cur>n)return;
		
		if(cur==n) {
			count++;
			return;
		}

		f(cur+1);
		f(cur+2);
	}
}
