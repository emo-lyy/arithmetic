package ����_11_15;

import java.util.Scanner;

public class ����ĸ��� {
	static int n,m;
	static char[][] A;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new char[n][];
		for (int i = 0; i < n; i++) {
			A[i]=scanner.next().toCharArray();
		}
		m=A[0].length;
		scanner.close();
		
		int sum=0;
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[0].length; j++) {
				if(A[i][j]=='1') {
					sum++;
					dfs(i,j,A);
				}
			}
		}
		System.out.println(sum);
	}
	
	static void dfs(int y,int x,char[][] A) {
		//top
		if(y-1>=0 && A[y-1][x]=='1') {
			A[y-1][x]='0';
			dfs(y-1,x,A);
		}
		//down
		if(y+1<n && A[y+1][x]=='1') {
			A[y+1][x]='0';
			dfs(y+1,x,A);
		}
		//right
		if(x+1<m && A[y][x+1]=='1') {
			A[y][x+1]='0';
			dfs(y,x+1,A);
		}
		//left
		if(x-1>=0 && A[y][x-1]=='1') {
			A[y][x-1]='0';
			dfs(y,x-1,A);
		}
	}
}
