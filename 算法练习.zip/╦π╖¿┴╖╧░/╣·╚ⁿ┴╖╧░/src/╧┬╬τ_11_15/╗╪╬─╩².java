package ����_11_15;

import java.util.Scanner;

public class ������ {
	static int n;
	static String m;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.next();
		scanner.close();
		int index=0;
		String s=m;
		while(index++<=30) {
			if(check(s)) {
				//System.out.println(s);
				System.out.println("STEP��"+(index-1));
				return;
			}
			String s1=s;
			String s2=new StringBuffer(s1).reverse().toString();		//��ת
			
			int sum=toSystemTen(s1)+toSystemTen(s2);
			s=toSystemN(sum);
			
		}
		System.out.println("Impossible!");
	}
	
	//10==>n
	static String toSystemN(int k) {
		return Integer.toString(k, n);
	}
	
	//n==>10
	static int toSystemTen(String k) {
		return Integer.parseInt(k, n);
	}
	
	//�ж��ǲ��ǻ�����
	static boolean check(String s) {
		int len=s.length();
		String s1,s2;
		if(len%2==0) {
			s1=s.substring(0,len/2);
			s2=new StringBuffer(s.substring(len/2,len)).reverse().toString();
		}else {
			s1=s.substring(0,len/2);
			s2=new StringBuffer(s.substring(len/2+1,len)).reverse().toString();
		}
		if(!s1.equals(s2))return false;
		return true;
	}
}
