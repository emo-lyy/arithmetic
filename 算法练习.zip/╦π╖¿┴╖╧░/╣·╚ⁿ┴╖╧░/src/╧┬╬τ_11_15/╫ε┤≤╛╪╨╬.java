package ����_11_15;

import java.util.Scanner;

public class ������ {
	static int n,m;
	static int[][] A;
	static int maxS=0;
	static int k=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				A[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		
		for (int i = n; i >= 1; i--) {
			for (int j = m; j >= 1; j--) {
				//����ĳ���
				for (int y = 0; y+i <= n; y++) {
					for (int x = 0; x+j <= m; x++) {
						if(check(y,y+i,x,x+j) && i+j>=k) {
							if(i*j>maxS) {
								maxS=i*j;
								k=i+j;
							}
						}
					}
				}
			}
		}
		System.out.println(maxS);
	}
	
	static boolean check(int beginY,int endY,int beginX,int endX) {
		for (int y = beginY; y < endY; y++) {
			for (int x = beginX; x < endX; x++) {
				if(A[y][x]==0) {
					return false;
				}
			}
		}
		return true;
	}
	
}
