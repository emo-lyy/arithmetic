package ����_11_15;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ȥ���ظ���ĸ {
	static String S;
	static List<String> A;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		S=scanner.next();
		scanner.close();
		String[] data=S.split("");
		A=new ArrayList<String>();
		for (int i = 0; i < data.length; i++) {
			String key=data[i];
			if(A.contains(key)) {
				//����key
				if(check(A,key)) {
					A.remove(A.indexOf(key));
					A.add(key);
				}
			}else{
				//������
				A.add(key);
			}
		}
		System.out.println(A);
	}
	
	/**
	   *     ����true	����е���
	 * @param A
	 * @param index
	 * @param key
	 * @return
	 */
	static boolean check(List<String> A,String key) {
		String s1="";			//ԭ��
		String s2="";			//����
		for (String s : A) {
			if(!s.equals(key)) {
				s2+=s;
			}
			s1+=s;
		}
		s2+=key;
		int k=s1.compareTo(s2);
		if(k<0)return false;
		return true;
	}
}
