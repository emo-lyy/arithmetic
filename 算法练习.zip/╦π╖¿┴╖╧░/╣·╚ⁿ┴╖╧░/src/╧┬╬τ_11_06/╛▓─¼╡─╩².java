package ����_11_06;

import java.util.Scanner;

public class ��Ĭ���� {
	 public static int sum(int x){
	        int sum = x;
	        while (x>0){
	            sum += x%10;
	            x = x/10;
	        }
	        return sum;
	    }
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        int n = sc.nextInt();
	        int a[] = new int[n];//�����ڴ�0��ʾ�Ǽ�į��
	        for (int i = 0;i<n;i++){
	            int tmp = i+1;
	            int happy = sum(tmp);
	            while (happy<=n){
	                a[happy-1] = 1;//����į���ڵ�λ��Ϊ1
	                happy = sum(happy);
	            }
	        }
	        for (int i = 0;i<n;i++){
	            if (a[i] == 0){
	                System.out.println(i+1);
	            }
	        }
	    }
}
