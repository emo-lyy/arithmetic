package ����_11_06;

import java.math.BigInteger;
import java.util.Scanner;

public class ������ {
	static BigInteger mod=new BigInteger("15");
	static String s1,s2;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		s1=scanner.next();
		s2=scanner.next();
		scanner.close();
		StringBuffer sb=new StringBuffer();
		BigInteger begin=new BigInteger(s1);
		BigInteger end=new BigInteger(s2);
		while (begin.compareTo(end)<=0) {
			sb.append(begin.toString(16));
			begin=begin.add(BigInteger.ONE);
		}
		String res=new BigInteger(new BigInteger(sb.toString(), 16).toString(10)).mod(mod).toString();
		System.out.println(res);
	}
}
