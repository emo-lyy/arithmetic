package ����_11_06;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ����˹��� {
	static int n,m;
	static int[][] A;
	static int max=0;		//�������
	
	static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				A[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		f(A);
		System.out.println(max);
	}
	
	static void f(int[][] A) {
		boolean check=true;
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[0].length; j++) {
				if(A[i][j]==0) {
					check = false;
					count=0;
					List<YX> coordinates=new ArrayList<>();
					YX yx=new YX();
					yx.y=i;
					yx.x=j;
					coordinates.add(yx);
					bfs(coordinates,A);
					
					max=max>count?max:count;
				}
			}
		}
		
		if(check) {
			//û��0
			max=n*m;
		}
	}
	

	static void bfs(List<YX> coordinates,int[][] A) {
		if(coordinates.size()==0) {
			return;
		}
		
		count+=coordinates.size();
		
		List<YX> box=new ArrayList<����˹���.YX>();
		for( YX yx : coordinates) {
			int y=yx.y;
			int x=yx.x;
			
			//top
			if(y-1>=0 && A[y-1][x]==1) {
				YX coordinate=new YX();
				coordinate.y=y-1;
				coordinate.x=x;
				box.add(coordinate);
				A[y-1][x]=0;
			}
			
			//left
			if(x-1>=0 && A[y][x-1]==1) {
				YX coordinate=new YX();
				coordinate.y=y;
				coordinate.x=x-1;
				box.add(coordinate);
				A[y][x-1]=0;
			}
			
			//right
			if(x+1<m && A[y][x+1]==1) {
				YX coordinate=new YX();
				coordinate.y=y;
				coordinate.x=x+1;
				box.add(coordinate);
				A[y][x+1]=0;
			}
			
			//down
			if(y+1<n && A[y+1][x]==1) {
				YX coordinate=new YX();
				coordinate.y=y+1;
				coordinate.x=x;
				box.add(coordinate);
				A[y+1][x]=0;
			}
		}
		
		bfs(box,A);
		
		//����
		for( YX yx : box) {
			int y=yx.y;
			int x=yx.x;
			A[y][x]=1;
		}
	}
	
	
	private static class YX{
		public int y;
		public int x;
	}
}
