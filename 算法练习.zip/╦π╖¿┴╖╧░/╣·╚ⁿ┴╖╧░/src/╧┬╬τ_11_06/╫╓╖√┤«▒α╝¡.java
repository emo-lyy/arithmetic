package ����_11_06;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class �ַ����༭ {
	static String S;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		S=scanner.nextLine();
		String operation=scanner.next();
		if(operation.equals("D")) {
			del(S,scanner.next());
		}else if(operation.equals("I")) {
			insert(S,scanner.next(),scanner.next());
		}else {
			update(S, scanner.next(), scanner.next());
		}
		scanner.close();
	}
	
	static void del(String s,String d) {
		for (int i = 0; i < s.length(); i++) {
			if(i!=s.indexOf(d)) {
				System.out.print(s.charAt(i));
			}
		}
	}
	
	static void insert(String s,String s1,String s2) {
		List<String> data=new ArrayList<String>();
		for (int i = 0; i < s.length(); i++) {
			if(i==data.lastIndexOf(s1)) {
				System.out.print(s2);
			}
			System.out.print(s.charAt(i));
		}
		
	}
	
	static void update(String s,String s1,String s2) {
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)==s1.charAt(0)) {
				System.out.print(s2);
			}else {
				System.out.print(s.charAt(i));
			}
		}
	}
}
