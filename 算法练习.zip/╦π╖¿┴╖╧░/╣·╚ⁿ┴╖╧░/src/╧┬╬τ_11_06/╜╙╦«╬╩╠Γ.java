package ����_11_06;

import java.util.ArrayList;
import java.util.Scanner;

public class ��ˮ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		int[] data=new int[n];
		for (int i = 0; i < data.length; i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		int time=0;
		if(n<=m) {
			for (int i : data) {
				time=(time>i)?time:i;
			}
		}
		else {
			ArrayList<ArrayList<Integer>> temp=new ArrayList<>();
			for(int i=0;i<m;i++) {
				temp.add(new ArrayList<Integer>());
				temp.get(i).add(data[i]);
			}
			
			//���ڲ���
			/*for (ArrayList<Integer> arrayList : temp) {
				for (Integer i : arrayList) {
					System.out.print(i);
				}
				System.out.println();
			}*/
			int end=m;
			int index=0;
			while(end<n) {
				for(int i=0;i<temp.size();i++) {
					for(int j=0;j<temp.get(i).size();j++) {
						System.out.print(temp.get(i).get(j));
					}
					System.out.println();
				}
				end++;
			}
		}
	}
}
