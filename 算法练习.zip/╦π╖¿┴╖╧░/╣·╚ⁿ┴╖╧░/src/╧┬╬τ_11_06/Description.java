package ����_11_06;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Description {
	static int sum=0;
	static List<Integer> A;
	public static void main(String[] args) {
		A=new ArrayList<Integer>();
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		for (int i = 0; i < n; i++) {
			A.add(scanner.nextInt());
		}
		scanner.close();
		f(A);
		System.out.println(sum);
	}
	
	static void f(List<Integer> A) {
		if(A.size()==1) {
			return;
		}
		Collections.sort(A);
		A.add(A.remove(0)+A.remove(0));
		sum+=A.get(A.size()-1);
		f(A);
	}
}
