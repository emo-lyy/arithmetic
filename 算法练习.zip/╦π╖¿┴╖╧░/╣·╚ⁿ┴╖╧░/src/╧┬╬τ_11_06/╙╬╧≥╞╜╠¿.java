package ����_11_06;

import java.util.Scanner;

public class ����ƽ̨ {
	static int min,max;
	static int n;
	static int[][] A;
	static boolean check=true;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new int[n][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				int k=scanner.nextInt();
				A[i][j]=k;
				if(check) {
					min=k;
					check=false;
				}
				min=min<k?min:k;
				max=max>k?max:k;
			}
		}
		scanner.close();
		
		//out(A);
		for (int t = min; t <= max; t++) {
			int[][] nextA=nextA(A, t);
			//out(nextA);
			check=false;
			dfs(0,0,nextA);
			if(check) {
				System.out.println(t);
				return;
			}
		}
	}
	
	
	static void dfs(int y,int x,int[][] A) {
		if(y==n-1 && x==n-1) {
			check=true;
			return;
		}
		
		if(y-1>=0 && A[y][x]>=A[y-1][x] && A[y-1][x]!=-1) {
			int temp=A[y][x];
			A[y][x]=-1;
			dfs(y-1, x, A);
			A[y][x]=temp;
		}
		
		if(y+1<n && A[y][x]>=A[y+1][x] && A[y+1][x]!=-1) {
			int temp=A[y][x];
			A[y][x]=-1;
			dfs(y+1, x, A);
			A[y][x]=temp;
		}
		
		if(x-1>=0 && A[y][x]>=A[y][x-1] && A[y][x-1]!=-1) {
			int temp=A[y][x];
			A[y][x]=-1;
			dfs(y, x-1, A);
			A[y][x]=temp;
		}
		
		if(x+1<n && A[y][x]>=A[y][x+1] && A[y][x+1]!=-1) {
			int temp=A[y][x];
			A[y][x]=-1;
			dfs(y, x+1, A);
			A[y][x]=temp;
		}
	}
	
	static int[][] nextA(int[][] A,int t){
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if(A[i][j]<t) {
					A[i][j]=t;
				}
			}
		}
		return A;
	}
	
	static void out(int[][] A) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
}
