package ����_11_06;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ��ȫ�������� {
	static int n;
	static int[][] A;
	static int w;
	static int max=0;		//����ֵ
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new int[n][2];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < 2; j++) {
				A[i][j]=scanner.nextInt();
			}
		}
		w=scanner.nextInt();
		scanner.close();
		F(0,w,0,new ArrayList<>());
		
		System.out.println(max);
	}
	
	/**
	 * 
	 * @param cur		��ǰ����
	 * @param w		��ǰ�ռ�
	 * @param value	��ǰ��ֵ
	 */
	static void F(int cur,int W,int V ,List<Integer> Q) {
		if(W<0)return;
		if(cur==n) {
			//System.out.println(Q);
			max=max>V?max:V;
			return;
		}
		
		
		int w=A[cur][0];
		int v=A[cur][1];
		
		//System.out.println(w+" "+v);
		
		Q.add(cur);
		F(cur+1,W-w,V+v,Q);
		Q.remove(Q.size()-1);
		
		F(cur+1,W,V,Q);
	}
}
