package ��ʮ�����ű��������������;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * δ���
 * @author ��ħ
 *
 */
public class Ӯ��Ʊ {
	static int n;
	static int max;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		List<Integer> A=new ArrayList<Integer>();
		for (int i = 0; i < n; i++) {
			A.add(scanner.nextInt());
		}
		max=0;
		scanner.close();
		for (int i = 0; i < n; i++) {
			dfs(i,1,0,new ArrayList<>(A));	
		}
		System.out.println(max);
	}
	
	static void dfs(int index,int cur,int sum,List<Integer> A) {
		if(cur>n || A.size()==0) {
			max=max>sum?max:sum;
			return;
		}
		if(A.get(index)==cur) {
			A.remove(index);
			if(A.size()==0) {
				dfs(-1,1,sum+cur,A);
				return;
			}else {
				dfs(index%A.size(),1,sum+cur,A);
			}
		}else {
			dfs((index+1)%A.size(),cur+1,sum,A);
		}
	}
}
