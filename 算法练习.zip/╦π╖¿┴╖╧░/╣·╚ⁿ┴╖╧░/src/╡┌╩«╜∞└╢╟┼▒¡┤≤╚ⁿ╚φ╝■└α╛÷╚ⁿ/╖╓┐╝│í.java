package ��ʮ�����ű��������������;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class �ֿ��� {
	static int n,m;
	static List<List<Integer>> data=new ArrayList<List<Integer>>();
	static boolean[] check;
	static List<List<Integer>> plan=new ArrayList<>();		//���ڰ������
	
	public static void main(String[] args) {
		inputData();
		//out(data);
		
		for (int cur = 1; cur <= n && check[cur]==false; cur++) {
			List<Integer> box=new ArrayList<>();
			box.add(cur);
			check[cur]=true;		//�Ѿ������˿���
			
			List<Integer> temp=data.get(cur);
			
			for (int k = cur+1; k <= n ; k++) {
				//����ѡ�����
				if(!temp.contains(k)) {
					if(check[k]==false && check(k,cur)) {
						//��������
						box.add(k);
						check[k]=true;
					}
				}
			}
			
			plan.add(box);
			
		}
		
		System.out.println(plan.size());
		
	}
	
	
	static boolean check(int k,int cur) {
		List<Integer> box=data.get(k);
		if(box.contains(cur)) {
			return false;
		}else {
			return true;
		}
	}
	
	static void inputData() {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		
		check=new boolean[n+1];		
		
		for (int i = 0; i < n+1; i++) {
			data.add(new ArrayList<>());
		}
		
		for (int i = 0; i < m; i++) {
			int q=scanner.nextInt();
			int p=scanner.nextInt();
			List<Integer> box=new ArrayList<>(data.get(q));
			box.add(p);
			data.set(q, box);
		}
		scanner.close();
	}
	
	static void out(List<List<Integer>> data) {
		for(List<Integer> list : data) {
			for(Integer i : list) {
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}
}
