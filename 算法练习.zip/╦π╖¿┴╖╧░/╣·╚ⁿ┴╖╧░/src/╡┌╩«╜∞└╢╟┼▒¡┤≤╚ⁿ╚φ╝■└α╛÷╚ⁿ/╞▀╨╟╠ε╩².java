package ��ʮ�����ű��������������;

import java.util.Arrays;

/**
 * 
 
	A: [6, 9, 4, 11, 5, 2, 12, 1, 7, 10, 3, 8, 13, 14]


	0	1	2	3
	3	4	5	6
	6	7	8	9
	9	10	1	11		==>	��	[10	3	9	8]
	11	2	4	12
	12	5	7	13
	13	8	10	0
	
	
	
 * @author ��ħ
 *
 */
public class �������� {
	 static int[] A=new int[] {1,2,3,4,5,7,8,9,10,12,13};
	 static int[][] locations=new int[][] {
		 {0,1,2,3},
		 {3,4,5,6},
		 {6,7,8,9},
		 {9,10,1,11},
		 {11,2,4,12},
		 {12,5,7,13},
		 {13,8,10,0}
	 };
	 public static void main(String[] args) {
		dfs(0,A);
	}
	 
	 static void dfs(int cur,int[] A) {
		 if(cur==A.length) {
			 int[] nextA=merge(A);
			// System.out.println(Arrays.toString(A));
			 if (check(nextA)) {
				 System.out.println("=======================");
				//System.out.println(Arrays.toString(nextA));
				 System.out.println(nextA[9]+" "+nextA[10]+" "+nextA[1]+" "+nextA[11]);
				System.exit(0);
			}
			 return;
		 }
		 for (int i = cur; i < A.length; i++) {
			swap(A,cur,i);
			dfs(cur+1,A);
			swap(A,cur,i);
		}
	 }
	 
	 static void swap(int[] A,int i,int j) {
		 int temp=A[i];
		 A[i]=A[j];
		 A[j]=temp;
	 }
	 
	 static int[] merge(int[] A) {
		 int[] res=new int[] {6,A[0],A[1],11,A[2],A[3],A[4],A[5],A[6],A[7],A[8],A[9],A[10],14};
		 return res;
	 }
	 
	 static boolean check(int[] A) {
		 int sum=0;
		 for (int i = 0; i < locations[0].length; i++) {
			sum+=A[locations[0][i]];
		}
		 
		 for (int i = 1; i < locations.length; i++) {
			 int temp=0;
			for (int j = 0; j < locations[0].length; j++) {
				temp+=A[locations[i][j]];
			}
			if(sum!=temp)return false;
		}
		 return true;
	 }
}
