package ��ʮ�����ű��������������;

import java.math.BigInteger;
import java.util.Scanner;

public class С����nλ {
	static long a,b,n;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		a=scanner.nextLong();
		b=scanner.nextLong();
		n=scanner.nextLong();
		scanner.close();
		f(a,b);
	}
	
	static void f(long a,long b) {
		BigInteger A=BigInteger.valueOf(a);
		BigInteger B=BigInteger.valueOf(b);
		
		String k=A.divide(B).toString();
		
		int len =k.equals("0")?0:k.length();
		
		for (int i = 1; i < 3+n+len; i++) {
			A=A.multiply(BigInteger.valueOf(10));
		}
		
		
		String Q=A.divide(B).toString();
		
		System.out.println(Q.substring((int)n+len - 1,3+(int)n+len -1));
	}
}
