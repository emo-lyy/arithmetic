package ��ʮ�����ű��������������;

import java.util.ArrayList;
import java.util.List;

public class ���ֻ��� {
	public static void main(String[] args) {
		dfs(1,new ArrayList<Integer>(),new ArrayList<>());
	}
	
	static void dfs(int cur,List<Integer> A,List<Integer> B) {
		if(cur==17) {
			if(check(A,B)) {
				System.out.println(A);
				System.out.println(B);
				System.out.println("-------------------------");
			}	
			return;
		}
		
		//����A
		A.add(cur);
		dfs(cur+1,A,B);
		A.remove(A.size()-1);
		
		
		//����B
		B.add(cur);
		dfs(cur+1,A,B);
		B.remove(B.size()-1);
		
	}
	
	
	
	static boolean check(List<Integer> A,List<Integer> B) {
		long sum1=0L,sum2=0L,square1=0L,square2=0L,cube1=0L,cube2=0L;
		for( Integer a : A) {
			sum1+=a;
			square1+=a*a;
			cube1+=a*a*a;
		}
		for( Integer b : B) {
			sum2+=b;
			square2+=b*b;
			cube2+=b*b*b;
		}
		if(sum1!=sum2)return false;
		if(square1!=square2)return false;
		if(cube1!=cube2)return false;
		return true;
	}
}
