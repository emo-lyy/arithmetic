package ��ʮ�����ű��������������;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ������� {
	static int n;
	static int[] data=new int[] {2,3,5,7,11,13,17};
	
	static BigInteger Q=BigInteger.ONE;
	
	static BigInteger sum=BigInteger.ZERO;
	
	public static void main(String[] args) {
//		Scanner scanner=new Scanner(System.in);
//		n=scanner.nextInt();
//		scanner.close();
//		
//		for (int i = 1; i < n; i++) {
//			Q=Q.multiply(new BigInteger(data[0]+""));
//		}
//		
//		dfs(n,new ArrayList<>());
//		
//		System.out.println(Q);
//
		for (int i = 1; i <= 60; i++) {
			
			for (int j = 1; j < i; j++) {
				Q=Q.multiply(new BigInteger(data[0]+""));
			}
			
			dfs(i,new ArrayList<>());
			
			sum=sum.add(Q);
		}
		
		System.out.println(sum);
		
	}
	
	static BigInteger count(List<Integer> A) {
		BigInteger res=BigInteger.ONE;
		for (int i = 0; i < A.size(); i++) {
			int number=A.get(i);
			for (int k = 0; k < number-1; k++) {
				res=res.multiply(new BigInteger(data[i]+""));
			}
		}
		return res;
	}
	
	
	/**
	 * ��ȡ���ɵļ���
	 * @param k
	 * @param A
	 */
	static void dfs(int k,List<Integer> A) {
		if(k==1) {
			//sort(A);
			//System.out.println(A);
			BigInteger res=count(A);
			//System.out.println(res);
			if(Q.compareTo(res)==1) {
				Q=res;
			}
			return;
		}
		for (int i = 2; i <= k; i++) {
			if(k%i==0) {
				A.add(i);
				dfs(k/i,A);
				A.remove(A.size()-1);
			}
		}
	}
	
	/**
	 * ��������
	 * @param A
	 */
	static void sort(List<Integer> A) {
		for (int i = 0; i < A.size()-1; i++) {
			for (int j = 0; j < A.size()-1-i; j++) {
				if(A.get(j)<A.get(j+1)) {
					int temp=A.get(j);
					A.set(j, A.get(j+1));
					A.set(j+1, temp);
				}	
			}
		}
	}
	
	
	
}
