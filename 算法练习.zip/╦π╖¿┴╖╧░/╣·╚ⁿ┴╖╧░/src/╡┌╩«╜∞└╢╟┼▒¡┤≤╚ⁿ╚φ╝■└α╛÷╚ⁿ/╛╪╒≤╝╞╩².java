package ��ʮ�����ű��������������;

import java.util.Scanner;

public class ������� {
	static int N,M;
	static int count=0;
	public static void main(String[] args) {	
		Scanner scanner=new Scanner(System.in);
		N=scanner.nextInt();
		M=scanner.nextInt();
		scanner.close();
		int[][] A=new int[N][M];
		dfs(0,0,A);
		System.out.println(count);
	}
	
	static void dfs(int y,int x,int[][] A) {
		if(y==N) {
			count++;
			/*out(A);
			System.out.println("------------------------------------------------");*/
			return;
		}
		
		//��O
		A[y][x]=500;
		dfs(y+(x+1)/M,(x+1)%M,A);
		A[y][x]=0;		//����
		
		
		//��X
		if(check(y,x,A)) {
			A[y][x]=200;
			dfs(y+(x+1)/M,(x+1)%M,A);
			A[y][x]=0;		//����
		}
	}
	
	/**
	 * �ж�X�ɲ���������
	 * @param x
	 * @param y
	 * @param A
	 * @param K
	 * @return
	 */
	static boolean check(int y,int x,int[][] A) {
		int countX=0;
		int countY=0;
		for(int i = 0; i<A[0].length; i++) {
			//System.out.println(y+" "+i);
			if(A[y][i]==200) {
				countX++;
			}
		}
		for (int i = 0; i < A.length; i++) {
//			System.out.println(i+" "+x);
			if(A[i][x]==200) {
				countY++;
			}
		}
		if(countX>=2 || countY>=2)return false;
		else return true;
	}
	
	
	static void out(int[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[0].length; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
}
