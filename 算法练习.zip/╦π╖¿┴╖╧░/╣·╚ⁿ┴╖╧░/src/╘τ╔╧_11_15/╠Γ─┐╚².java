package ����_11_15;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ��Ŀ�� {
	static List<Integer> data;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		data=new ArrayList<Integer>();
		String[] S=scanner.nextLine().split(" ");
		for (int i = 0; i < S.length; i++) {
			data.add(Integer.valueOf(S[i]));
		}
		scanner.close();
		System.out.println(data);
		
	}
	
}
