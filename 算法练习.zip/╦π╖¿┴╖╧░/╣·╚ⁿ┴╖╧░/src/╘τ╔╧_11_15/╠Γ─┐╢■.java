package ����_11_15;

import java.util.Scanner;

public class ��Ŀ�� {
	static int n,m;
	static char[][] A;
	static int time;
	static int beginY,beginX,endY,endX;
	static boolean check=true;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new char[n][m];
		for (int i = 0; i < n; i++) {
			A[i]=scanner.next().toCharArray();
		}
		scanner.close();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(A[i][j]=='@') {
					beginY=i;
					beginX=j;
				}
				if(A[i][j]=='*') {
					endY=i;
					endX=j;
				}
			}
		}
		
		//out(A);
		dfs(beginY,beginX,0,A);
		if(check) {
			System.out.println("Impossibility!");
		}else {
			System.out.println(time);
		}
	}
	
	/**
	 * �ƶ�����	==> ����/�߹��ĵط���������
	 * @param y
	 * @param x
	 * @param t	//ʱ��
	 */
	static void dfs(int y,int x,int t,char[][] A) {
		if(y==endY && x==endX) {
			//System.out.println(t);
			if(check) {
				check=false;
				time=t;
			}else {
				time=time<t?time:t;
			}
			return;
		}
		
		//right
		if(x+1<m && A[y][x+1]!='#') {
			A[y][x]='#';
			dfs(y,x+1,t+1,A);
			A[y][x]='.';
		}
		
		//down
		if(y+1<n && A[y+1][x]!='#') {
			A[y][x]='#';
			dfs(y+1,x,t+1,A);
			A[y][x]='.';
		}	
		
		//left
		if(x-1>=0 && A[y][x-1]!='#') {
			A[y][x]='#';
			dfs(y,x-1,t+1,A);
			A[y][x]='.';
		}
		
		
		//top 
		if(y-1>=0 && A[y-1][x]!='#') {
			A[y][x]='#';
			dfs(y-1,x,t+1,A);
			A[y][x]='.';
		}
	
	}	
	
	
	static void out(char[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[0].length; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
}
