package ����_11_15;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * @author ��ħ
 *
 */
public class ��Ŀһ {
	static Map<String, List<String>> rule;
	static Set<String> box;
	static Set<String> end;		//��ֹ		
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		int m=scanner.nextInt();
		rule=new HashMap<>();
		for (int i = 0; i < m; i++) {
			String key=scanner.next();
			String value=scanner.next();
			if(rule.containsKey(key)) {
				//����
				rule.get(key).add(value);
			}else {
				//������
				List<String> temp=new ArrayList<>();
				temp.add(key);		//��������
				temp.add(value);
				rule.put(key, temp);
			}
		}
		scanner.close();
		box=new HashSet<>();
		Set<String> Q=new HashSet<>();
		Q.add(s);
		f(Q);
		System.out.println(box);
	}
	
	
	static void f(Set<String> A) {
		box.addAll(A);
		if(A.equals(end)){
			return;
		}else {
			end=new HashSet<>(A);
			//����ת����ϵ
			Set<String> Q=new HashSet<>();
			for (String a : A) {
				//System.out.println(a);
				String[] S=a.split("");
				for (int i = 0; i < S.length; i++) {
					String key=S[i];
					//System.out.println(key);
					if(rule.containsKey(key)) {
						List<String> P=rule.get(key);
						for (String p : P) {
							S[i]=p;
							//System.out.println(toString(S));
							Q.add(toString(S));
							S[i]=key;
						}
					}
				}
			}
			//System.out.println(Q);
			f(Q);
		}
		
	}
	
	static String toString(String[] S) {
		StringBuffer sb=new StringBuffer();
		for (int i = 0; i < S.length; i++) {
			sb.append(S[i]);
		}
		return sb.toString();
	}
	
	
	/**
	 * ��ֹ����
	 * @param S
	 * @return
	 */
	static boolean check(Set<String> S) {
		for (String s : S) {
			String[] Q=s.split("");
			for (String k : Q) {
				if(rule.containsKey(k)) {
					//������ת����ϵ
					return false;
				}
			}
		}
		return true;
	}
}
