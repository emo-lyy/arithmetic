package ����_11_08;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class �ֿ��� {
	static int n,m;
	static Map<Integer, List<Integer>> Q;
	static boolean[] check;
	static List<List<Integer>> P;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		check=new boolean[n];
		m=scanner.nextInt();
		Q=new HashMap<Integer, List<Integer>>();
		for (int i = 0; i < m; i++) {
			int key=scanner.nextInt();
			int value=scanner.nextInt();
			if(Q.containsKey(key)) {
				Q.get(key).add(value);
			}else {
				List<Integer> k=new ArrayList<Integer>();
				k.add(value);
				Q.put(key, k);
			}
		}
		scanner.close();
		f();
	}
	
	static void f() {
		P=new ArrayList<>();
		for (int i = 1; i <= n; i++) {
			if(!check[i-1]) {
				//System.out.println(i+" : "+Q.get(i));
				List<Integer> U=new ArrayList<>();
				U.add(i);
				check[i-1]=true;
				
				for (int j = i+1; j <= n; j++) {
					//System.out.println(j+":"+check[j-1]);
					if(!check[j-1]) {
						if(check(i, j) && check(j, i)) {
							U.add(j);
							check[j-1]=true;
						}
					}
				}
				P.add(U);
			}
		}
		
		System.out.println(P.size());
	}
	
	/**
	 * �������ӷ���true
	 * @param key
	 * @param value
	 * @return
	 */
	static boolean check(int key,int value) {
		if(Q.get(key)==null) {
			return true;
		}else {
			if(Q.get(key).contains(value)) {
				return false;
			}else {
				return true;
			}
		}
	}
}
