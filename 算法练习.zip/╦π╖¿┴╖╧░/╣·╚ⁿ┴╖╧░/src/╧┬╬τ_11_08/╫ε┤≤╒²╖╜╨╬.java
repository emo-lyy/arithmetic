package ����_11_08;

import java.util.Scanner;

public class ��������� {
	static int n,m;
	static int[][] A;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				A[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		
		for (int i = Math.min(n, m); i >= 1; i--) {
			if(f(i, A)) {
				System.out.println((int)Math.pow(i+1, 2));
				return;
			}
		}
	}
	
	static boolean f(int len,int[][] A) {
		for (int i = 0; i + len < A.length; i++) {
			for (int j = 0; j + len < A[0].length; j++) {
				if(check(i, i+len, j, j+len)) {
					return true;
				}
			}
		}
		return false;
	}
	
	static boolean check(int beginY,int endY,int beginX,int endX) {
		for (int y = beginY; y <= endY; y++) {
			for (int x = beginX; x <= endX; x++) {
				if(A[y][x]==0)return false;
			}
		}
		return true;
	}
}
