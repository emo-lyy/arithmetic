package ����_11_08;


import java.util.Scanner;

public class �ϳ����� {
	static int[][] ADD;		//ǰ��һ������  a�������������и����� x������
	static int a,n,m,x;
	static int[][] NUMBER;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		a=scanner.nextInt();
		n=scanner.nextInt();
		m=scanner.nextInt();
		x=scanner.nextInt();
		scanner.close();
		ADD=new int[n+1][2];
		NUMBER=new int[n+1][2];
		initA();
		f();
	}
	
	static void f() {
		for (int i = 3; i <= n; i++) {
			ADD[i][0]=ADD[i-1][0]+ADD[i-2][0];			//a������
			ADD[i][1]=ADD[i-1][1]+ADD[i-2][1];			//b������
			
			NUMBER[i][0]=NUMBER[i-1][0]+ADD[i-2][0];
			NUMBER[i][1]=NUMBER[i-1][1]+ADD[i-2][1];
		}
		int a_number=NUMBER[n-1][0];
		int x_number=NUMBER[n-1][1];
		
		int k=(m-a_number*a)/x_number;
		
		int p=a*NUMBER[x][0]+k*NUMBER[x][1];
		System.out.println(p);
	}
	
	static void initA() {
		ADD[1][0]=1;
		ADD[1][1]=0;
		
		ADD[2][0]=0;
		ADD[2][1]=1;
		
		
		NUMBER[1][0]=1;
		NUMBER[1][1]=0;
		
		NUMBER[2][0]=1;
		NUMBER[2][1]=0;
		
		
	}
	
	
}
