package ����_11_08;

/**
 * ���ȡ��26
 * @author ��ħ
 *
 */
public class С�������� {
	static int k=2014;
	public static void main(String[] args) {
		for (int i = 1000; i < 10000; i++) {
			int a=i/1000;
			int b=i%1000/100;
			int c=i%100/10;
			int d=i%10;
			//System.out.println(a+" "+b+" "+c+" "+d);
			if(a+b+c+d == k-i) {
				System.out.println(a+b+c+d);
			}
		}
	}
}
