package ����_11_10;

import java.util.Scanner;

//ABCDEABCD
// lcabz
public class ������� {
	static String s1,s2;
	static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		s1=scanner.next();
		s2=scanner.next();
		scanner.close();
		f();
	}
	
	static void f() {
		int index=0;		//���ڼ�¼s2���±�
		for (int i = 0; i < s1.length(); i++) {
			if(s1.charAt(i)==s2.charAt(index)) {
				count++;
				index++;
			}
		}
		System.out.println(count);
	}
}
