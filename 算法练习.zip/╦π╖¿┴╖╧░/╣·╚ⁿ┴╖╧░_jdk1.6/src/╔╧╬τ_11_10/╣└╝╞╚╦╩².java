package ����_11_10;

import java.util.Scanner;

public class �������� {
	static int n,m;
	static int[][] A;
	static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		for (int i = 0; i < n; i++) {
			String s=scanner.next();
			for (int j = 0; j < m; j++) {
				A[i][j]=s.charAt(j)-'0';
			}
		}
		scanner.close();
		f();
	}
	
	
	static void f() {
		int count=0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(A[i][j]==1) {
					dfs(i,j,A);
					count++;
				}
			}
		}
		System.out.println(count);
	}
	
	
	static void dfs(int y,int x,int[][] A) {
		//����û�߹�	==>	���������	==>	��������
		if(x+1<m && A[y][x+1]==1) {
			A[y][x+1]=2;
			dfs(y,x+1,A);
		}else if(y+1<n && A[y+1][x]==1) {
			A[y+1][x]=2;
			dfs(y+1,x,A);
		}else if(x+1<m && A[y][x+1]==2) {
			dfs(y,x+1,A);
		}else if(y+1<n && A[y+1][x]==2) {
			dfs(y+1,x,A);
		}
		
	}
	
}
