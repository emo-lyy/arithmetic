package ����_11_10;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

/**
 * �ݹ����˳�������Ҫ�ж�
 * @author ��ħ
 *
 */
public class ���������Թ� {
	static int n,k;
	static char[][] A;
	static YX begin,end;
	static int weight=5;		//����
	public static void main(String[] args) {
		inputData();
		List<YX> yxs=new ArrayList<YX>();
		yxs.add(begin);
		
		bfs(yxs,0);
	}

	static void bfs(List<YX> yxs,int t) {
		
		if(yxs.contains(end)) {
			System.out.println(t);
			System.exit(0);
		}
		
		
		int p=getPadding(t);
		
		List<YX> box=new ArrayList<YX>(yxs);
		
		for (YX yx : yxs) {
			int y=yx.y;
			int x=yx.x;
			
			if(Top(y, x, p, A)) {
				YX top=new YX(y-1, x);
				if(!box.contains(top)) {
					box.add(top);
				}
			}
			
			if(Left(y, x, p, A)) {
				YX left=new YX(y, x-1);
				if(!box.contains(left)) {
					box.add(left);
				}
			}
			
			if(Down(y, x, p, A)) {
				YX down=new YX(y+1, x);
				if(!box.contains(down)) {
					box.add(down);
				}
			}
			
			if(Right(y, x, p, A)) {
				YX right=new YX(y, x+1);
				if(!box.contains(right)) {
					box.add(right);
				}
			}
			
		}
		
		bfs(box,t+1);
		
	}
	
	
	/**
	 * ��ȡ����ľ���
	 * @param t
	 * @return
	 */
	static int getPadding(int t) {
		if(t<k) {
			return 2;
		}else if(t>=k && t<2*k) {
			return 1;
		}else {
			return 0;
		}
	}
	
	
	/**
	 * �����ƶ�
	 * @param y
	 * @param x
	 * @param p
	 * @param A
	 * @return
	 */
	static boolean Top(int y,int x,int p,char[][] A) {
		int nextY=y-p-1;		//������������
		
		if(nextY<0)return false;		
		
		int beginX=x-p;
		int endX=x+p;
		
		for (int i = beginX; i <= endX; i++) {
			if(A[nextY][i]=='*')return false;
		}
		
		return true;
	}
	
	
	/**
	 * ������
	 * @param y
	 * @param x
	 * @param p
	 * @param A
	 * @return
	 */
	static boolean Left(int y,int x,int p,char[][] A) {
		int nextX=x-1-p;
		if(nextX<0)return false;
		
		int beginY=y-p;
		int endY=y+p;
				
		for (int i = beginY; i <= endY; i++) {
			if(A[i][nextX]=='*')return false;
		}
		
		return true;
	}
	
	
	/**
	 * �����ƶ�
	 * @param y
	 * @param x
	 * @param p
	 * @param A
	 * @return
	 */
	static boolean Down(int y,int x,int p,char[][] A) {
		int nextY=y+p+1;
		if(nextY>=n)return false;
		
		int beginX=x-p;
		int endX=x+p;
		
		for (int i = beginX; i <= endX; i++) {
			if(A[nextY][i]=='*')return false;
		}
		
		return true;
	}
	
	/**
	 * �����ƶ�
	 * @param y
	 * @param x
	 * @param p
	 * @param A
	 * @return
	 */
	static boolean Right(int y,int x,int p,char[][] A) {
		int nextX=x+p+1;
		if(nextX>=n)return false;
		
		int beginY=y-p;
		int endY=y+p;
		
		for (int i = beginY; i <= endY; i++) {
			if(A[i][nextX]=='*')return false;
		}
		
		return true;
	}
	
	/**
	 * ��ʼ������
	 */
	static void inputData() {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		k=scanner.nextInt();
		A=new char[n][];
		for (int i = 0; i < n; i++) {
			A[i]=scanner.next().toCharArray();
		}
		scanner.close();
		begin=new YX(2,2);
		end=new YX(n-3,n-3);
	}
	
	static boolean check(Set<YX> set) {
		for (YX yx : set) {
			if(yx.y==end.y && yx.x==end.x) {
				return true;
			}
		}
		return false;
	}
	
	
	private static class YX{
		public int y;
		public int x;
		public YX(int y,int x) {
			this.y=y;
			this.x=x;
		}
		
		@Override
		public boolean equals(Object  o) {
			YX obj=(YX)o;
			if(this.y==obj.y && this.x==obj.x)return true;
			else return false;
		}
	}
}
