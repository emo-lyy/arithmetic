package ����_11_10;

import java.util.ArrayList;
import java.util.List;

public class ƽ����� {
	static int k=(int)Math.sqrt(2019)+1;

	static int count=0;
	
	public static void main(String[] args) {
		dfs(1,0,new ArrayList<Integer>());		//��1 ~ k
		System.out.println(count);
	}
	
	/**
	 * 
	 * @param cur		��ǰҪ���ӵ�ֵ
	 * @param sum		��ǰ�ĺ�
	 */
	static void dfs(int cur,int sum,List<Integer> data) {
		if(sum>2019 || cur>k)return;
		if(sum==2019) {
			count++;
			//System.out.println(data);
			return;
		}
		
		//����
		data.add(cur);
		dfs(cur+1,sum+cur*cur,data);
		data.remove(data.size()-1);
		//������
		dfs(cur+1,sum,data);
	}
	
}
