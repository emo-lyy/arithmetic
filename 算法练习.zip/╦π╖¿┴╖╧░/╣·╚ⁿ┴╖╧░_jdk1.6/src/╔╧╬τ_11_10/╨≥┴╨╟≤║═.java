package ����_11_10;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class ������� {
	static int[] prime= {2,3,5,7,11,13,17,23};		//��������
	static BigInteger Q=BigInteger.valueOf(Long.MAX_VALUE);
	
	static BigInteger sum = BigInteger.ZERO;
	
	public static void main(String[] args) {
		for (int i = 1; i <= 60; i++) {
			Q=BigInteger.valueOf(Integer.MAX_VALUE);
			dfs(i,new ArrayList<Integer>());
		//	System.out.println(Q);
			sum=sum.add(Q);
		}
		System.out.println(sum);
	}
	
	/**
	 * ��ȡ���ɵļ���
	 * @param k
	 * @param A
	 */
	static void dfs(int k,List<Integer> A) {
		if(k==1) {
			//System.out.println(A);
			BigInteger res=count(A);
			//System.out.println(res);
			if(Q.compareTo(res)==1) {		//���Q��res�� �����滻
				Q=res;		//���
			}
			return;
		}
		for (int i = 2; i <= k; i++) {
			if(k%i==0) {
				A.add(i);
				dfs(k/i,A);
				A.remove(A.size()-1);
			}
		}
	}
	
	
	static BigInteger count(List<Integer> A) {
		BigInteger res=BigInteger.ONE;
		for (int i = 0; i < A.size(); i++) {
			int number=A.get(i);
			for (int k = 0; k < number-1; k++) {
				res=res.multiply(new BigInteger(prime[i]+""));
			}
		}
		return res;
	}

}
