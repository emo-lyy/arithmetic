package ����_11_10;

import java.util.Arrays;
import java.util.Scanner;

public class ������� {
	static int n,m;
	static String[][] A;
	static int[][] data;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		scanner.close();
		
		A=new String[n][m];
		data=new int[n+1][m+1];
		
		//�����ʼ��
		for (int i = 0; i < n; i++) {
			Arrays.fill(A[i], "");
			Arrays.fill(data[i], -1);
		}
		
		
		int res=dfs(0,0,A);
		System.out.println(res);
	}
	
	static int dfs(int y,int x,String[][] A) {
		//System.out.println(y+" "+x);
		
	//	if(data[y][x]!=-1)return data[y][x];
		
		int res=0;
		
		if(y==A.length) {
			return 1;
		}
		
		if(check(y, x, A)) {
			//������X
			A[y][x]="X";
			int p=dfs(y+(x+1)/m, (x+1)%m, A);
			res+=p;
			A[y][x]="";		//����
			
			A[y][x]="Y";
			int q=dfs(y+(x+1)/m, (x+1)%m, A);
			res+=q;
			A[y][x]="";		//����
		}else {
			A[y][x]="Y";
			int q=dfs(y+(x+1)/m, (x+1)%m, A);
			res+=q;
			A[y][x]="";		//����
		}
		
		//data[y][x]=res;
		
		return res;
	}
	
	static boolean check(int y,int x,String[][] A) {	
		int countX=0;
		for (int i = 0; i < m; i++) {
			//x�仯
			String s=A[y][i];
			if(s.equals("X"))countX++;
			if(countX>=2)return false;
		}
		
		int countY=0;
		for (int i = 0; i < n; i++) {
			//y�仯
			String s=A[i][x];
			if(s.equals("X"))countY++;
			if(countY>=2)return false;

		}
		return true;
	}
}
