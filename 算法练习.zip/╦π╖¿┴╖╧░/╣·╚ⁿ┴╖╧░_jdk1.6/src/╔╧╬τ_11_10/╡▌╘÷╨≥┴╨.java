package ����_11_10;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import ����.Out;

/**
 * 		���ݷ���	
		����		x�����		==>		���
		�ϵ���		y�����		==>		���
		���ϵ�����	y�����		==>		���
		���µ�����	x�����		==>		���
		���ϵ�����	y�����		==>		
		
		���µ�����	������


		��������
		
		
		
���԰���

		
		30 50
VLPWJVVNNZSWFGHSFRBCOIJTPYNEURPIGKQGPSXUGNELGRVZAG
SDLLOVGRTWEYZKKXNKIRWGZWXWRHKXFASATDWZAPZRNHTNNGQF
ZGUGXVQDQAEAHOQEADMWWXFBXECKAVIGPTKTTQFWSWPKRPSMGA
BDGMGYHAOPPRRHKYZCMFZEDELCALTBSWNTAODXYVHQNDASUFRL
YVYWQZUTEPFSFXLTZBMBQETXGXFUEBHGMJKBPNIHMYOELYZIKH
ZYZHSLTCGNANNXTUJGBYKUOJMGOGRDPKEUGVHNZJZHDUNRERBU
XFPTZKTPVQPJEMBHNTUBSMIYEGXNWQSBZMHMDRZZMJPZQTCWLR
ZNXOKBITTPSHEXWHZXFLWEMPZTBVNKNYSHCIQRIKQHFRAYWOPG
MHJKFYYBQSDPOVJICWWGGCOZSBGLSOXOFDAADZYEOBKDDTMQPA
VIDPIGELBYMEVQLASLQRUKMXSEWGHRSFVXOMHSJWWXHIBCGVIF
GWRFRFLHAMYWYZOIQODBIHHRIIMWJWJGYPFAHZZWJKRGOISUJC
EKQKKPNEYCBWOQHTYFHHQZRLFNDOVXTWASSQWXKBIVTKTUIASK
PEKNJFIVBKOZUEPPHIWLUBFUDWPIDRJKAZVJKPBRHCRMGNMFWW
CGZAXHXPDELTACGUWBXWNNZNDQYYCIQRJCULIEBQBLLMJEUSZP
RWHHQMBIJWTQPUFNAESPZHAQARNIDUCRYQAZMNVRVZUJOZUDGS
PFGAYBDEECHUXFUZIKAXYDFWJNSAOPJYWUIEJSCORRBVQHCHMR
JNVIPVEMQSHCCAXMWEFSYIGFPIXNIDXOTXTNBCHSHUZGKXFECL
YZBAIIOTWLREPZISBGJLQDALKZUKEQMKLDIPXJEPENEIPWFDLP
HBQKWJFLSEXVILKYPNSWUZLDCRTAYUUPEITQJEITZRQMMAQNLN
DQDJGOWMBFKAIGWEAJOISPFPLULIWVVALLIIHBGEZLGRHRCKGF
LXYPCVPNUKSWCCGXEYTEBAWRLWDWNHHNNNWQNIIBUCGUJYMRYW
CZDKISKUSBPFHVGSAVJBDMNPSDKFRXVVPLVAQUGVUJEXSZFGFQ
IYIJGISUANRAXTGQLAVFMQTICKQAHLEBGHAVOVVPEXIMLFWIYI
ZIIFSOPCMAWCBPKWZBUQPQLGSNIBFADUUJJHPAIUVVNWNWKDZB
HGTEEIISFGIUEUOWXVTPJDVACYQYFQUCXOXOSSMXLZDQESHXKP
FEBZHJAGIFGXSMRDKGONGELOALLSYDVILRWAPXXBPOOSWZNEAS
VJGMAOFLGYIFLJTEKDNIWHJAABCASFMAKIENSYIZZSLRSUIPCJ
BMQGMPDRCPGWKTPLOTAINXZAAJWCPUJHPOUYWNWHZAKCDMZDSR
RRARTVHZYYCEDXJQNQAINQVDJCZCZLCQWQQIKUYMYMOVMNCBVY
ABTCRRUXVGYLZILFLOFYVWFFBZNFWDZOADRDCLIRFKBFBHMAXX
		
 * @author ��ħ
 *
 */
public class �������� {
	static int n,m;
	static String[][] A;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new String[n][m];
		for (int i = 0; i < n; i++) {
			String[] s=scanner.next().split("");
			//System.out.println(Arrays.toString(s));
			for (int j = 1; j < s.length; j++) {
				//System.out.println(s[j]);
				A[i][j-1]=s[j];
			}
		}
		scanner.close();
		f();
	}
	
	
	static void f() {
		List<List<String>> VAH=new ArrayList<List<String>>();		//�ݺ�
		for(int i=0;i<n;i++) {
			List<String> data1=new ArrayList<String>();		//����
			for (int j = 0; j < m; j++) {
				data1.add(A[i][j]);		
			}
			VAH.add(data1);
		}
		
		for (int i = 0; i < m; i++) {
			List<String> data2=new ArrayList<String>();		//�ϵ���
			for (int j = 0; j < n; j++) {
				data2.add(A[j][i]);
			}
			VAH.add(data2);
		}
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(i==0 || j==0) {
					//�� ��
					List<String> data3=LT_TO_RD(i,j,new ArrayList<String>());
					//System.out.println(data3);
					VAH.add(data3);
				}
			}
		}
		
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(i==n-1 || j==0) {
					//�� ��
					List<String> data4=LD_TO_RT(i,j,new ArrayList<String>());		//���µ�����
					//System.out.println(data4);
					VAH.add(data4);
				}
			}
		}
		
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(j==m-1 || i==0) {
					//�� ��
					List<String> data5=RT_TO_LD(i,j,new ArrayList<String>());
				//	System.out.println(data5);
					VAH.add(data5);
				}
			}
		}
		
		//System.out.println(VAH);
		long res=count(VAH);
		System.out.println(res);
	}
	
	/**
	 * ���ϵ�����
	 * @param y
	 * @param x
	 * @param data
	 * @return
	 */
	static List<String> LT_TO_RD(int y,int x,List<String> data){
		if(x==m || y==n) {
			return data;
		}
		data.add(A[y][x]);
		return LT_TO_RD(y+1,x+1,data);
	}
	
	
	/**
	 * ���µ�����
	 * @param y
	 * @param x
	 * @param data
	 * @return
	 */
	static List<String> LD_TO_RT(int y,int x,List<String> data){
		if(y==-1 || x==m) {
			return data;
		}
		data.add(A[y][x]);
		return LD_TO_RT(y-1,x+1,data);
	}
	
	
	/**
	 * ���ϵ�����
	 * @param y
	 * @param x
	 * @param data
	 * @return
	 */
	static List<String> RT_TO_LD(int y,int x,List<String> data){
		if(y==n || x==-1) {
			return data;
		}
		data.add(A[y][x]);
		return RT_TO_LD(y+1,x-1,data);
	}
	
	
	static long count(List<List<String>> A) {
		long res=0L;
		
		for (List<String> list : A) {
			if(list.size()>1) {
				for (int i = 0; i < list.size(); i++) {
					for (int j = i+1; j < list.size(); j++) {
						if(list.get(i).charAt(0)<list.get(j).charAt(0)) {
							//System.out.println(list.get(i)+" "+list.get(j));
							res++;
						}
					}
				}
			}
		}
		
		return res;
	}
}
