package ����_11_10;

import java.util.Scanner;

public class �������� {
	static int mod=100000000+7;
	
	static int n;
	
	static int count=0;
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		scanner.close();
		f();
	}
	
	static void f() {
		if(n<=1) {
			System.out.println(0);
			return;
		}
		
		n-=1;
		for (int i = 1; i <= n; i++) {
			int a=i;				//����ı߳�
			int b=(int)Math.pow(n-i+1, 2);		//����ĸ���
			//System.out.println(a+" "+b);
			count+=(a*b)%mod;
		}
		System.out.println(count);
		
	}
	
}
