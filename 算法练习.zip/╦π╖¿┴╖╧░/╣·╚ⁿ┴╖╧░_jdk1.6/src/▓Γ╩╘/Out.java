package ����;

import java.util.List;

public class Out {
	/**
	 * ���һά����
	 * @param A
	 */
	public static void print(int[] A) {
		for (int i = 0; i < A.length; i++) {
			System.out.print(A[i]+" ");
		}
	}
	
	public static void print(String[] A) {
		for (int i = 0; i < A.length; i++) {
			System.out.print(A[i]+" ");
		}
	}
	
	/**
	 * �����ά����
	 * @param A
	 */
	public static void print(int[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	
	public static void print(String[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	
	/**
	 * �����ά����
	 * @param A
	 */
	public static void print(int[][][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				for (int k = 0; k < A[i][j].length; k++) {
					System.out.print(A[i][j][k]+" ");
				}
				System.out.println();
			}
			System.out.println();
		}
	}
}
