package ����;

public class StringCompare {
	public static void main(String[] args) {
		String s1="ABC";
		String s2="ECD";
		System.out.println(s1.compareTo(s2));
	}
}
