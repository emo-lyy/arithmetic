package ����;

public class Split {
	static String s="ABCDEFG";
	public static void main(String[] args) {
		String[] S=s.split("");
		System.out.println(S[1]);
	}
}
