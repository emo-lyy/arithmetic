package ����;

public class One {
    static int count  = 0;
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        atb(1000);
        System.out.println(count);
    }
    public static void atb(float s) {
        //С���a�ɵ�b
        s=s-10*(s/30);
        if(s <= 1) {
            return;
        }
        else {
            count++;    //ײa�Ĵ���
            bta(s);
        }
    }
    public static void bta(float s) {
        //С���b�ɵ�a
        s=s-10*(s/30);
        if(s <= 1) {
            return;
        }
        else {
            atb(s);
        }
    }
}
