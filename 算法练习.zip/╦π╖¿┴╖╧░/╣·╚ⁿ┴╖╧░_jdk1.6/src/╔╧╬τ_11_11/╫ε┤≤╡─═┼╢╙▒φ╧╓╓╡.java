package ����_11_11;

import java.util.Scanner;

public class �����Ŷӱ���ֵ {	
	static int n;
	static int[] speed;
	static int[] efficiency;
	static int k;
	static int mod=100000000+7;
	
	static int[][][][] data;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		speed=new int[n];
		efficiency=new int[n];
		
		for (int i = 0; i < n; i++) {
			speed[i]=scanner.nextInt();
		}
		
		for (int i = 0; i < n; i++) {
			efficiency[i]=scanner.nextInt();
		}
		
		k=scanner.nextInt();
		
		scanner.close();
		
		int res=maxPerformance(n,speed,efficiency,k);
		System.out.println(res);
	}
	
	 static int maxPerformance(int n, int[] speed, int[] efficiency, int k) {
		// data=new int[100000][100000][100000][100000];
		 
		return dfs(0,0,Integer.MAX_VALUE,k,n,speed,efficiency);
	 }
	 
	 /**
	  * 
	  * @param index		��ǰλ��
	  * @param sumSpeed	��ǰ���ٶȺ�
	  * @param minEfficiency		��ǰЧ�����
	  * @param k		��ѡȡ��������
	  * @param n		������
	  * @param speed	�ٶȼ���
	  * @param efficiency	Ч�ʼ���
	  * @return
	  */
	 static int dfs(int index,int sumSpeed,int minEfficiency,int k,int n,int[] speed,int[] efficiency) {
		// if(data[index][sumSpeed][minEfficiency][k]!=0)return data[index][sumSpeed][minEfficiency][k];
		 if(index==n || k<0)return 0;	
		 if(k==0) {
			 return sumSpeed*minEfficiency%mod;
		 }
		 //ѡ
		 int a = dfs(index+1,sumSpeed+speed[index],Math.min(minEfficiency, efficiency[index]),k-1,n,speed,efficiency);
		 
	//	 data[index+1][sumSpeed+speed[index]][Math.min(minEfficiency, efficiency[index])][k-1]=a;
		 
		 //��ѡ
		 int b = dfs(index+1,sumSpeed,minEfficiency,k,n,speed,efficiency);
//		 data[index+1][sumSpeed][minEfficiency][k]=b;
		 
		 return Math.max(a, b);
	 }
}
