package ����_11_11;

import java.util.Arrays;
import java.util.Scanner;

public class ѡ�� {
	static int n,k;
	static long[] A;
	static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		k=scanner.nextInt();
		A=new long[n];
		for (int i = 0; i < n; i++) {
			A[i]=scanner.nextLong();
		}
		scanner.close();
		dfs(0L,k,0);
		//System.out.println(Arrays.toString(A));
		System.out.println(count);
	}
	
	
	static void dfs(long sum,int k,int cur) {
		if(k==0) {
		//	System.out.println(sum);
			if(isPrime(sum)) {
				count++;
			}
			return;
		}
		
		if(cur==n)return;			//�˳�������
		
		//ѡ
		dfs(sum+A[cur],k-1,cur+1);
		//��ѡ
		dfs(sum,k,cur+1);
	}
	
	public static boolean isPrime(long n) {
	    if (n <= 3) {
	        return n > 1;
	    }
	    long sqrt = (long)Math.sqrt(n);
	    for (long i = 2; i <= sqrt; i++) {
	        if(n % i == 0) {
	            return false;
	        }
	    }
	    return true;
	}
	 
}
