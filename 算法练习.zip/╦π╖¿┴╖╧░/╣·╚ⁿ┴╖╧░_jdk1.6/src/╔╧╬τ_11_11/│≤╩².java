package ����_11_11;

import java.util.Arrays;
import java.util.Scanner;

public class ���� {
	static int n;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n = scanner.nextInt();
		scanner.close();
		int[] dp=new int[n];
		dp[0]=1;
		
		int a = 0,b = 0,c = 0;		//ָ��λ��
		for (int i = 1; i < dp.length; i++) {
			int A = dp[a]*2;
			int B = dp[b]*3;
			int C = dp[c]*5;
			
			dp[i] = Math.min(A, Math.min(B, C));
			
			if(dp[i]==A)a++;
			if(dp[i]==B)b++;
			if(dp[i]==C)c++;
		}
		System.out.println(Arrays.toString(dp));
	}
}
