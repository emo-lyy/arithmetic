package ����_11_11;

import java.util.Scanner;

public class ��ϸ������ {
	static int n,m;
	static int[][] A;
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		for (int i = 0; i < n; i++) {
			char[] k=scanner.next().toCharArray();
			for (int j = 0; j < k.length; j++) {
				A[i][j]=k[j]-'0';
			}
		}
		scanner.close();
		
		int count=0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(A[i][j]!=0) {
					count++;
					bfs(i,j,A);
				}
			}
		}
		System.out.println(count);
	}
	
	static void bfs(int y,int x,int[][] A) {
		//top
		if(y-1>=0 && A[y-1][x]!=0) {
			A[y-1][x]=0;
			bfs(y-1,x,A);
		}
		
		//left
		if(x-1>=0 && A[y][x-1]!=0) {
			A[y][x-1]=0;
			bfs(y,x-1,A);
		}
		
		//right
		if(x+1<m && A[y][x+1]!=0) {
			A[y][x+1]=0;
			bfs(y,x+1,A);
		}
		
		//down
		if(y+1<n && A[y+1][x]!=0) {
			A[y+1][x]=0;
			bfs(y+1,x,A);
		}
	}
}
