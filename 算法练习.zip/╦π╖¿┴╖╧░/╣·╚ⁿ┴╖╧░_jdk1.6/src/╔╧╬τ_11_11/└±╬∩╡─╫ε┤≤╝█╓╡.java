package ����_11_11;

import java.util.Arrays;
import java.util.Scanner;

public class ���������ֵ {
	static int n,m;
	static int[][] A;
	static int[][] dp;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		dp=new int[n+1][m+1];
		for (int i = 0; i < n; i++) {
			Arrays.fill(dp[i], -1);
			for (int j = 0; j < m; j++) {
				A[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		int res=dfs(0,0);
		System.out.println(res);
	}
	
	static int dfs(int y,int x) {
		if(dp[y][x]!=-1)return dp[y][x];
		
		if(y==n-1 && x==m-1)return A[y][x];
		
		int a=0;
		if(y+1<n) {
			int k=dfs(y+1,x);
			dp[y+1][x]=k;
			a=A[y][x]+k;			//����
		}
		
		int b=0;
		if(x+1<m) {
			int k=dfs(y,x+1);
			dp[y][x+1]=k;
			b=A[y][x]+k;
		}
		
		return dp[y][x]=Math.max(a, b);
	}
}
