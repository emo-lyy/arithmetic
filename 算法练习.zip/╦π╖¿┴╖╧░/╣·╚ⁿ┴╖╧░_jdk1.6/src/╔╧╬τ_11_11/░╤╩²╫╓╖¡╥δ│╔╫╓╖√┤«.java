package ����_11_11;


import java.util.Scanner;

public class �����ַ�����ַ��� {
	static int n;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		scanner.close();
		int res= translateNum(n);
		System.out.println(res);
	}
	static int translateNum(int num) {
		String s=Integer.toString(num);
		int len=s.length();
		int[] A=new int[len+1];
		A[0]=1;
		A[1]=1;
		for (int i = 2; i <= len; i++) {
			Integer p=Integer.valueOf(s.substring(i-2,i));
			if(p>=10 && p<=25) {
				A[i]=A[i-1]+A[i-2];
			}else {
				A[i]=A[i-1];
			}
		}
		return A[len];
    }
}
