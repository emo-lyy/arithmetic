package ����_11_11;
public class Ѱ�����������������λ�� {
	public static void main(String[] args) {
		int[] num1=new int[]{1,3};
		int[] num2=new int[] {2,4};
		String res=findMedianSortedArrays(num1,num2);
		System.out.println(res);
	}
	
	public static String findMedianSortedArrays(int[] nums1, int[] nums2) {
		double res=0.0;
		int len=nums1.length+nums2.length;
		int a=0;
		int b=0;
		if(len%2==0) {
			//ȡ���м�����ֵ��ӳ���2����
			int[] Q=new int[len/2+1];
			while(a+b<=len/2) {
				if(nums1[a]<=nums2[b]) {
					Q[a+b]=nums1[a];
					if(a+1<nums1.length) {
						a++;
					}else {
						b++;
					}
				}else {
					Q[a+b]=nums2[b];
					if(b+1<nums2.length) {
						b++;
					}else {
						a++;
					}
				}
			}
			
			//System.out.println(Arrays.toString(Q));
			res+=(Q[len/2]+Q[len/2-1])/2.0;
		}else {
			//ȡ���м�ֵ����
			int k=0;
			while(a+b<=len/2) {
				if(nums1[a]<=nums2[b]) {
					k=nums1[a];
					if(a+1<nums1.length) {
						a++;
					}else {
						b++;
					}
				}else {
					k=nums2[b];
					if(b+1<nums2.length) {
						b++;
					}else {
						a++;
					}
				}
			}
			res+=k;
		}
		return String.format("%.5f",res);
    }
}
