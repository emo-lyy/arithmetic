package ����_11_11;

import java.util.Scanner;

public class �ؼ� {
	static int n,m;
	static int[][] A;
	
	static int beginY,beginX,endY,endX;
	static int min=Integer.MAX_VALUE;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				A[i][j]=scanner.nextInt();
				if(A[i][j]==2) {
					beginY=i;
					beginX=j;
				}
				if(A[i][j]==3) {
					endY=i;
					endX=j;
				}
			}
		}
		scanner.close();
		dfs(beginY,beginX,5,0);
		if(min!=Integer.MAX_VALUE) {
			System.out.println(min);
		}else {
			System.out.println(-1);
		}
	}
	
	/**
	 * 
	 * @param y	��ǰ��y����
	 * @param x	��ǰ��x����
	 * @param k	��ǰ������ֵ
	 * @param t	��ǰ�Ĳ���
	 */
	static void dfs(int y,int x,int k,int t) {
		if(k<=0 || t>n*m || t>min)return;
		if(y==endY && x==endX) {
			min=Math.min(min, t);
			return;
		}
		
		//int temp=A[y][x];
		
		//top
		if(y-1>=0 && A[y-1][x]!=0) {
			//A[y][x]=0;
			if(A[y-1][x]==4) {
				//A[y-1][x]=0;
				dfs(y-1,x,6,t+1);
				//A[y-1][x]=4;		//����
			}else {
				dfs(y-1,x,k-1,t+1);
			}
			//A[y][x]=temp;
		}
		
		
		// left
		if(x-1>=0 && A[y][x-1]!=0) {
			//A[y][x]=0;
			if(A[y][x-1]==4) {
				//A[y][x-1]=0;
				dfs(y,x-1,6,t+1);
				//A[y][x-1]=4;
			}else {
				dfs(y,x-1,k-1,t+1);
			}
			//A[y][x]=temp;
		}
		
		
		// right
		if(x+1<m && A[y][x+1]!=0) {
		//	A[y][x]=0;
			if(A[y][x+1]==4) {
				//A[y][x+1]=0;
				dfs(y,x+1,6,t+1);
				//A[y][x+1]=4;
			}else {
				dfs(y,x+1,k-1,t+1);
			}
		//	A[y][x]=temp;
		}
		
		
		// down
		if(y+1<n && A[y+1][x]!=0) {
		//	A[y][x]=0;
			if(A[y+1][x]==4) {
				//A[y+1][x]=0;
				dfs(y+1,x,6,t+1);
				//A[y+1][x]=4;
			}else {
				dfs(y+1,x,k-1,t+1);
			}
		//	A[y][x]=temp;
		}
		
		
	}
}
