package ����_11_11;

public class ��Ʊ��������� {
	 static int maxProfit(int[] prices) {
	        int cost = Integer.MAX_VALUE, profit = 0;
	        for(int price : prices) {
	            cost = Math.min(cost, price);
	            profit = Math.max(profit, price - cost);
	        }
	        return profit;
	    }

}
