package ����_11_11;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ȫ���ů {
	public static int n;
	public static char[][] A;
	//����λ��
	public static int[][] YX=new int[][]{
		{-1,0},		//top
		{1,0},		//down
		{0,-1},		//left
		{0,1}		//right
	};	
	
	public static int count=0;		//��û�˶��ٸ�����
	public static int remove=0;		//�Ƴ��� # ����
	public static int in=0;			//�ܹ��ж��ٸ� #
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new char[n][n];
		for (int i = 0; i < n; i++) {
			A[i]=scanner.next().toCharArray();
		}
		scanner.close();
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if(A[i][j]=='#') {
					A[i][j]='@';
					remove = 1;	
					in = 0;
					List<int[]> yxs=new ArrayList<int[]>();
					yxs.add(new int[] {i,j});
					bfs(yxs,A);
					
//					System.out.println("======================");
//					out(A);
//					System.out.println(remove+" "+in);
					
					if(remove==in)count++;
					
				}
			}
		}
		System.out.println(count);
	}
	
	/**
	 * 	���� => (����)
	 * @param yxs
	 * @param A
	 */
	public static void bfs(List<int[]> yxs,char[][] A) {
		if(yxs.size()==0)return;
		in+=yxs.size();		//�ܹ�������
		List<int[]> box=new ArrayList<int[]>();
		for (int[] yx : yxs) {
			for (int i = 0; i < 4; i++) {
				int nextY=yx[0]+YX[i][0];
				int nextX=yx[1]+YX[i][1];
				if(nextY>=0 && nextX>=0 && nextY<n && nextX<n && A[nextY][nextX]=='#') {
					if(check(nextY, nextX, A)) {
						remove++;
					}
					A[nextY][nextX]='@';
					box.add(new int[] {nextY,nextX});
				}
			}
		}
		bfs(box, A);
	}
	
	
	/**
	 *      �ж��Ƿ�ᱻ��û
	 * @param y
	 * @param x
	 * @param A
	 * @return
	 */
	public static boolean check(int y,int x,char[][] A){
		for(int i = 0;i < 4;i++){
			int nextY=y+YX[i][0];		//��Y����
			int nextX=x+YX[i][1];		//��X����
			if(nextY>=0 && nextX>=0 && nextY<n && nextX<n && A[nextY][nextX]=='.') {
				return true;
			}
		}
		return false;
	}
	
	/**
	   *    �������
	 * @param A
	 */
	public static void out(char[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				System.out.print(A[i][j]+"  ");
			}
			System.out.println();
		}
	}
}
