package ����_11_11;

import java.util.Scanner;

public class ������ִ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		String res=longestPalindrome(s);
		System.out.println(res);
	}
	 static String longestPalindrome(String s) {
		for (int i = s.length(); i > 0 ; i--) {
			//����
			for (int j = 0; j+i <= s.length(); j++) {
				//���
				String q=s.substring(j,j+i);
				if(check(q)) {
					return q;
				}
				//System.out.println(q);
			}
		}
		 return null;
	 }
	 
	 static boolean check(String s) {
		 String s1,s2="";
		 s1=s.substring(0, s.length()/2);
		 if(s.length()%2==0) {
			 s2=new StringBuffer(s.substring(s.length()/2)).reverse().toString();
		 }else {
			 s2=new StringBuffer(s.substring(s.length()/2+1)).reverse().toString();
		 }
		 if(s1.equals(s2))return true;
		 else return false;
	 }
}
