package ����_11_11;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ���ظ��ַ�����Ӵ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		int res=lengthOfLongestSubstring(s);
		System.out.println(res);
	}
	
	static int lengthOfLongestSubstring(String s) {
		if(s.length()<=0)return 0;
		int max=1;
		String[] S=s.split("");
		for (int i = 1; i < S.length; i++) {
			List<String> box=new ArrayList<String>();
			box.add(S[i]);
			for (int j = i+1; j < S.length; j++) {
				String q=S[j];
				if(box.contains(q)) {
					break;
				}else {
					box.add(q);
				}
			}
			//System.out.println(box);
			max=Math.max(max, box.size());
		}
		
		
		return max;
    }
}
