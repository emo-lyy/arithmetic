package ����_11_12;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class �������� {
	static int[] A= {1,2,3,4,5,7,8,9,10,12,13};
	
	static int[][] Q=new int[][] {
		{0,1	,2,3},
		{3,4,5,6},
		{6,7,8,9},
		{9,10,1,11},
		{11,2,4,12},
		{12,5,7,13},
		{13,8,10,0}
	};
	
	public static void main(String[] args) {
		dfs(0,A);
	}
	
	static void dfs(int cur,int[] A) {
		if(cur==A.length) {
			//System.out.println(Arrays.toString(A));
			
			List<Integer> data=merge(A);
			System.out.println(data);
			if(check(data)) {
				System.out.println(data.get(10) +" "+ data.get(3) +" "+ data.get(9) +" "+ data.get(8));
			}
			return;
		}
		for (int i = cur; i < A.length; i++) {
			swap(A,cur,i);
			dfs(cur+1,A);
			swap(A,cur,i);
		}
	}
	
	static void swap(int[] A,int i,int j) {
		int temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
	
	static List<Integer> merge(int[] A){
		List<Integer> data=new ArrayList<Integer>();
		for (int i = 0; i < A.length; i++) {
			if(i==0) {
				data.add(6);
			}
			if(i==2) {
				data.add(11);
			}
			data.add(A[i]);
		}
		data.add(14);
		return data;
	}
	
	static boolean check(List<Integer> data) {
		int sum1=0;
		for (int i = 0; i < Q[0].length; i++) {
			sum1+=data.get(Q[0][i]);
		}
		
		for (int i = 1; i < Q.length; i++) {
			int sum2=0;
			for (int j = 0; j < Q[i].length; j++) {
				sum2+=data.get(Q[i][j]);
			}
			if(sum1!=sum2)return false;
		}
		return true;
	}
}
