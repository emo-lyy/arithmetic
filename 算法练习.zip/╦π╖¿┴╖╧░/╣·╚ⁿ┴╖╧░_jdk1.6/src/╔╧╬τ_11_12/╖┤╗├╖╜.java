package ����_11_12;

import java.util.HashSet;
import java.util.Set;

public class ���÷� {
	static int count=0;
	static int[] A= {1,2,3,4,5,6,7,8,9};
	
	public static void main(String[] args) {
		dfs(0,A);
		System.out.println(count/8);
	}
	
	static void dfs(int cur,int[] A) {
		if(cur==A.length) {
			//System.out.println(Arrays.toString(A));
			int[][] data=Arrays(A);
			if(check(data)) {
				count++;
			}
			return;
		}
		for (int i = cur; i < A.length; i++) {
			swap(A,cur,i);
			dfs(cur+1,A);
			swap(A,cur,i);
		}
	}
	
	static void swap(int[] A,int i,int j) {
		int temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
	
	/**
	 * �ж�
	 * @param A
	 * @return
	 */
	static boolean check(int[][] A) {
		Set<Integer> set=new HashSet<Integer>();
		int p=0;		//��Խ���
		int q=0;		//�ҶԽ���
		for (int i = 0; i < A.length; i++) {
			int a=0;	//����
			int b=0;	//����
			for (int j = 0; j < A.length; j++) {
				a+=A[i][j];
				b+=A[j][i];		//��Ϊ�� 3*3 ���Բ���Ҫ���࿼�Ǳ߽�ֵ
				
				if(i==j) p+=A[i][j];
				if(i+j==2)q+=A[i][j];
			}
			set.add(a);
			set.add(b);
		}
		set.add(p);
		set.add(q);
		if(set.size()!=8)return false;
		else return true;
	}
	
	/**
	 * ��һλ���� ת��� ��ά����
	 * @param A
	 * @return
	 */
	static int[][] Arrays(int[] A){
		int[][] res=new int[][] {
			{A[0],A[1],A[2]},
			{A[3],A[4],A[5]},
			{A[6],A[7],A[8]}
		};
		return res;
	}
}
