package ����_11_12;

import java.util.Arrays;

public class �и��������ĵ��� {
	static int mod=100000000+7;
	public static void main(String[] args) {
		int res=maxArea(5,4,new int[] {1,2,4},new int[] {1,3});
		System.out.println(res);
	}
	
	 public static int maxArea(int h, int w, int[] horizontalCuts, int[] verticalCuts) {
		 Arrays.sort(horizontalCuts);
		 Arrays.sort(verticalCuts);
		 
		 int maxH=0;
		 if(horizontalCuts.length==0) {
			 maxH=h;
		 }else {
			 for (int i = 0; i < horizontalCuts.length; i++) {
				 if(i==0) {
					 //��һ�ηָ�
					 maxH=horizontalCuts[0];
				 }else {
					 maxH=Math.max(maxH, horizontalCuts[i]-horizontalCuts[i-1]);
				 }
			 }
			 maxH=Math.max(maxH, h-horizontalCuts[horizontalCuts.length-1]);
		 } 
		 
		 int maxW=0;
		 if(verticalCuts.length==0) {
			 maxW=w;
		 }else {
			 for (int i = 0; i < verticalCuts.length; i++) {
				 if(i==0) {
					 //��һ�ηָ�
					 maxW=verticalCuts[0];
				 }else {
					 maxW=Math.max(maxW, verticalCuts[i]-verticalCuts[i-1]);
				 }
			 }
			 maxW=Math.max(maxW, w-verticalCuts[verticalCuts.length-1]);
		 } 
		 return (maxH*maxW)%mod;
	 }
}
