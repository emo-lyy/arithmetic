package ����_11_12;

public class ��ŭ��С�� {
	static int count=0;
	static int a=0;
	static int b=1000;
	public static void main(String[] args) {
		while(b-a>1) {
			toRight();
			//System.out.println(a+" "+b);
			toLeft();
			//System.out.println(a+" "+b);
		}
		System.out.println(count);
	}
	
	static void toRight() {
		int len=b-a;
		b-=len/6+1;
		a+=len/6;
		System.out.println(a+" "+b);
		count++;
	}
	
	static void toLeft() {
		int len=b-a;
		b-=len/6;
		a+=len/6+1;
	}
}


	
	
	