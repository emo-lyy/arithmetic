package ����_11_12;

import java.util.Scanner;

public class ������ {
	static int mod=1000000007;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int res=cuttingRope(n);
		System.out.println(res);
	}
	
	 public static int cuttingRope(int n) {
		 if(n<=1)return 0;
	     if(n==2)return 1;
	     if(n==3)return 2;
	     if(n==4)return 4;
		 int[] A=new int[n+1];
		 initA(A);
		 for (int i = 5; i <= n; i++) {
			for (int j = 1; j <= i/2; j++) {
				A[i]=Math.max(A[i], (A[j]*A[i-j])%mod);
			}
		}
		 return A[n];
	 }
	 
	 static void initA(int[] A) {
		 A[0]=0;
		 A[1]=1;
		 A[2]=2;
		 A[3]=3;
		 A[4]=4;
	 }
}
