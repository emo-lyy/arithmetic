package ����_11_12;

import java.util.Scanner;

public class ����BW {
	static int n,m;
	static char[][] A;
	static int[][] YX=new int[][] {
		{-1,0},		//top
		{1,0},		//down
		{0,-1},		//left
		{0,1}		//right
	};
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new char[n][m];
		for (int i = 0; i < n; i++) {
			A[i]=scanner.next().toCharArray();
		}
		scanner.close();
		dfs(0,0,A);
		out(A);
	}
	
	static void dfs(int y,int x,char[][] A) {
		if(y==n) {
			return;
		}
		if(check(y, x, A, 'B')) {
			//�ж��ܲ������� B
			A[y][x]='B';
		}else if(check(y, x, A, 'W')){
			// �ж��ܲ������� W
			A[y][x]='W';
		}
		dfs(y+(x+1)/m,(x+1)%m,A);
	}
	
	/**
	 * �ж��ܲ������� k
	 * @param y
	 * @param x
	 * @param A
	 * @param k
	 * @return
	 */
	static boolean check(int y,int x,char[][] A,char k) {
		if(A[y][x]=='-')return false;
		for (int i = 0; i < 4; i++) {
			int nextY=y+YX[i][0];
			int nextX=x+YX[i][1];
			if(nextY>=0 && nextX>=0 && nextY<n && nextX<m) {
				if(A[nextY][nextX]==k)return false;
			}
		}
		return true;
	}
	
	static void out(char[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				System.out.print(A[i][j]+"");
			}
			System.out.println();
		}
	}
}
