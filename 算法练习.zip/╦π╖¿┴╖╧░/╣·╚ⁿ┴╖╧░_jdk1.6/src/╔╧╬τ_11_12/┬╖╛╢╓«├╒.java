package ����_11_12;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ·��֮�� {
	static int n;
	static int[][] A;
	
	static int[] LEFT;
	static int[] TOP;
	
	static int[][] YX=new int[][] {
		{-1,0},		//top
		{1,0},		//down
		{0,-1},		//left
		{0,1}		//right
	};
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		A=new int[n][n];
		LEFT=new int[n];
		TOP=new int[n];
		for (int i = 0; i < n; i++) {
			TOP[i]=scanner.nextInt();
		}
		
		for (int i = 0; i < n; i++) {
			LEFT[i]=scanner.nextInt();
		}
		scanner.close();
		createCoordinate(A);
		dfs(0,0,LEFT,TOP,new ArrayList<Integer>());
	}
	
	/**
	 * 
	 * @param y	��ǰ��y����
	 * @param x	��ǰ��x����
	 * @param L	�������ļ�	--1
	 * @param T	���ϱ���ļ�	--1
	 * @param P	·��
	 */
	static void dfs(int y,int x,int[] L,int[] T,List<Integer> P) {
		if(y==n-1 && x==n-1) {
			P.add(A[y][x]);
			L[y]--;
			T[x]--;
			
			if(check(L, T)) {
				out(P);
				System.exit(0);
			}
			
			P.remove(P.size()-1);
			L[y]++;
			T[x]++;
			//out(P);
			return;
		}
		for (int i = 0; i < 4; i++) {
			int nextY=y+YX[i][0];
			int nextX=x+YX[i][1];
			if(nextX>=0 && nextY>=0 && nextX<n && nextY<n) {
				P.add(A[y][x]);
				L[y]--;
				T[x]--;
				dfs(nextY,nextX,L,T,P);
				P.remove(P.size()-1);
				L[y]++;
				T[x]++;
			}
		}
	}
	
	
	static boolean check(int[] L,int[] T) {
		for (int i = 0; i < n; i++) {
			if(L[i]!=0 || T[i]!=0)return false;
		}
		return true;
	}
	
	/**
	 * ��������ϵ
	 * @param A
	 */
	static void createCoordinate(int[][] A) {
		int cnt=0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				A[i][j]=cnt;
				cnt++;
			}
		}
	}
	
	static void out(int[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	static void out(List<Integer> A) {
		for (int i = 0; i < A.size(); i++) {
			System.out.print(A.get(i)+" ");
		}
		System.out.println();
	}
}
