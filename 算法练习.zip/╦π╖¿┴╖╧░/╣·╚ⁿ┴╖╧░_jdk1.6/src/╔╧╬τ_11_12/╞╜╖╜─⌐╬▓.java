package ����_11_12;

import java.util.HashSet;
import java.util.Set;

public class ƽ��ĩβ {
	static Set<String> set=new HashSet<String>();
	public static void main(String[] args) {
		for(int i=10; i<100000;i++) {
			if(check(i)) {
				//System.out.println(i);
				String s=i+"";
				set.add(s.substring(s.length()-2));
			}
		}
		System.out.println(set.size());
	}
	
	static boolean check(int n) {
		int k=(int)Math.sqrt(n);
		return k*k==n;
	}
}
