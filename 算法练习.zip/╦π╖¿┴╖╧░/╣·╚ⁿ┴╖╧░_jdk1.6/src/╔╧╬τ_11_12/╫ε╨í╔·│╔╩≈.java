package ����_11_12;

import java.util.Arrays;
import java.util.Scanner;

public class ��С������ {
	static int n,m;
	static int[][] data;
	static int[] Q;
	static int cnt=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		data=new int[n+1][n+1];
		Q=new int[n+1];
		
		Arrays.fill(Q, Integer.MAX_VALUE);
		for (int i = 1; i <= n; i++) {
			Arrays.fill(data[i], Integer.MAX_VALUE);
		}
		
		for (int i = 0; i < m; i++) {
			int y=scanner.nextInt();
			int x=scanner.nextInt();
			int value=scanner.nextInt();
			if(data[y][x]>value) {
				data[y][x]=data[x][y]=value;
			}
		}
		
		scanner.close();
		Q[0]=0;
		Q[1]=0;
		f(1);
	}
	
	static void f(int yx) {
		//System.out.println(Arrays.toString(Q));
		if(check()) {
			System.out.println(cnt);
			System.exit(0);
		}
		for (int i = 1; i <= n; i++) {
			if(yx!=i && Q[i]>data[yx][i]) {
				Q[i]=data[yx][i];
			}
		}
		int min=Integer.MAX_VALUE;
		int nextYX=-1;
		for (int i = 1; i <= n; i++) {
			if(min>Q[i] && Q[i]>0) {
				min=Q[i];
				nextYX=i;
			}
		}
		cnt+=min;	
		Q[nextYX]=0;
		f(nextYX);
	}
	
	
	static boolean check() {
		for (int i = 1; i <= n; i++) {
			if(Q[i]>0)return false;
		}
		return true;
	}

	static void out(int[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[i].length; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
}