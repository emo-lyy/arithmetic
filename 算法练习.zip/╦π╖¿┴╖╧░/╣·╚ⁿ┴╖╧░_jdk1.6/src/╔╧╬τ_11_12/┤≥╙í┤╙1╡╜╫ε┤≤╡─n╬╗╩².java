package ����_11_12;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ��ӡ��1������nλ�� {
	static List<String> S;
	public static void main(String[] args) {
		int n=3;
		int[] A=printNumbers(n);
		System.out.println(Arrays.toString(A));
	}
	
	public static int[] printNumbers(int n) {
		if(n<1)return new int[0];
		List<String> data=new ArrayList<String>();
		S=new ArrayList<String>();
		for (int i = 0; i < 10; i++) {
			data.add(i+"");
			S.add(i+"");
		}
		List<String> res=bfs(data,n-1);
		
		int[] p=new int[res.size()-1];
		for (int i = 0; i < p.length; i++) {
			p[i]=Integer.valueOf(res.get(i+1));
		}
		return p;
    }
	
	
	static List<String> bfs(List<String> data,int n) {
		if(n==0) {
			return data;
		}
		List<String> box=new ArrayList<String>();
		for (String s : data) {
			for (int i = 0; i < S.size(); i++) {
				box.add(s+S.get(i));
			}
		}
		return bfs(box,n-1);
	} 	
		
}
