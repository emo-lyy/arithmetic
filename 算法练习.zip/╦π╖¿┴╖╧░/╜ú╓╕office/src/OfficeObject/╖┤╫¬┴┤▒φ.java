package OfficeObject;

import java.util.ArrayList;
import java.util.List;

public class ��ת���� {
	 public static List reverseList(List head) {
		List res=new ArrayList<>();
		for (int i = head.size()-1; i >= 0; i--) {
			res.add(head.get(i));
		}
		return res;
	}
}
