package ����;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class �����������еĹ鲢 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] N=new int[n];
		for(int i=0;i<n;i++)N[i]=scanner.nextInt();
		int m=scanner.nextInt();
		int[] M=new int[m];
		for(int i=0;i<m;i++)M[i]=scanner.nextInt();
		scanner.close();
		f(N,M);
	}
	public static void f(int[] N,int[] M) {
		ArrayList<Integer> temp=new ArrayList<>();
		for(int i=0;i<N.length;i++)temp.add(N[i]);
		for(int i=0;i<M.length;i++)temp.add(M[i]);
		Collections.sort(temp);
		for (Integer i : temp) {
			System.out.println(i);
		}
	}
}
