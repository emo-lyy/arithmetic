package ����;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class �������� {
	private static double k=3.0/7.0;
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		double[] data=new double[n];
		for(int i=0;i<n;i++)data[i]=scanner.nextDouble();
		scanner.close();
		for (double d : data) {
			f(d);
		}
	}
	
	public static void f(double n) {
		ArrayList<Score> temp1=new ArrayList<>();
		double begin=3;
		if(n>50)begin=n-30;
		for(double i=(int)begin+1;i<=n;i++) {
			Score temp=null;
			for(double j=1;j<i;j++) {
				Score s=new Score(j,i);
				//System.out.println(s.getConsult());
				if(s.getConsult()<k)temp=s;
				else break;
			}
			temp1.add(temp);
		}
		Map<Double,Score> map=new HashMap<>();
		ArrayList<Double> temp2=new ArrayList<>();
		for (Score s : temp1) {
			temp2.add(s.getConsult());
			map.put(s.getConsult(), s);
		}
		Collections.sort(temp2);
		Score s=map.get(temp2.get(temp2.size()-1));
		System.out.println((int)s.getZi()+" "+(int)s.getMu());
	}
	
		
	
	private static class Score{
		private double zi;
		private double mu;
		private double consult;
		public double getZi() {
			return zi;
		}
		public double getMu() {
			return mu;
		}
		public double getConsult() {
			return consult;
		}
		public Score(double zi, double mu) {
			super();
			this.zi = zi;
			this.mu = mu;
			this.consult = zi/mu;
		}
	}
}
