package ����;

import java.math.BigInteger;
import java.util.Scanner;

public class ��С������LCM {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String a=scanner.next();
		String b=scanner.next();
		scanner.close();
		BigInteger A=new BigInteger(a);
		BigInteger B=new BigInteger(b);
		//System.out.println(A.compareTo(B));
		if(A.compareTo(B)==-1) {
			BigInteger temp=A;
			A=B;
			B=temp;
		}
		BigInteger box=A.multiply(B);
		BigInteger res=gcd(A,B);
		System.out.println(box.divide(res));
	}
	
	public static BigInteger gcd(BigInteger A,BigInteger B) {
		if(B==BigInteger.ZERO)return A;
		return gcd(B,A.mod(B));
	}
	
}
