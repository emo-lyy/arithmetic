package com.area.calculateLayer;

public class CalculateSquare {
	public CalculateSquare(double a) {
		double s=a*a;
		System.out.println("���Ϊ:"+s);
		System.out.println("----------------------"+"\n");
	}
}
