package com.area.calculateLayer;

public class CalculateTriangle {
	public CalculateTriangle(double d,double h) {
		double s=d*h/2;
		System.out.println("���Ϊ:"+s);
		System.out.println("----------------------"+"\n");
	}
}
