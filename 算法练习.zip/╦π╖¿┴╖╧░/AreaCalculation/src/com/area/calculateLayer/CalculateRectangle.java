package com.area.calculateLayer;

public class CalculateRectangle {
	public CalculateRectangle(double a,double b) {
		double s=a*b;
		System.out.println("���Ϊ:"+s);
		
	}
}
