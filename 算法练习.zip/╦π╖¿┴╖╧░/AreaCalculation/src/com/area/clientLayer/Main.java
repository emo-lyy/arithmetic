package com.area.clientLayer;

import com.area.JudgmentLayer.If;

public class Main {
	public static void main(String[] args) {
		User user=new User();
		while(true) {		
			String If=user.openScanner();
			//System.out.println("----------------------");
			//�������ж�ѡ�����ʲôͼ��
			new If(If);
		}
	}
}
