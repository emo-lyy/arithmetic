package com.area.clientLayer;

import java.util.Scanner;

import com.area.JudgmentLayer.IfInput;
import com.area.staticResource.GeometricType;
import com.area.staticResource.OptionNumber;

//�������û���
public class User {
    static String[] typeData= GeometricType.typeData;
	static String[]  optionNumberEnglish=OptionNumber.optionNumberEnglish;
	static IfInput ifInput=new IfInput();
	
	public static String  openScanner() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("��������Ҫ����ļ���ͼ��:");
		System.out.println();
		//����������
		for(int i=0;i<typeData.length;i++) {
			System.out.print(optionNumberEnglish[i]+"."+typeData[i]+"  ");
		}
		
		System.out.println();
		String ret =ifInput.IfScanner(scanner.next());
		return ret;
	}	

	public static void closeScanner(Scanner scanner) {
		scanner.close();
	}
}
