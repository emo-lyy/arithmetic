package com.area.JudgmentLayer;

import com.area.staticResource.GeometricType;
import com.area.staticResource.OptionNumber;

//�������жϲ�
public class If {
	public If(String optionNumberEnglish) {
		String[] optionNumber=OptionNumber.optionNumberEnglish;
		String[] typeData= {GeometricType.square,GeometricType.rectangle,GeometricType.triangle};
		
		int index=0;
		for (int i = 0; i < optionNumber.length; i++) {
			if(optionNumberEnglish.equals(optionNumber[i])) {
				index=i;
			}
		}
		String If=typeData[index];
		try {
			new IfCalculate(If);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("�������!");
			System.out.println("----------------------"+"\n");
		}
	}
}
