package com.area.JudgmentLayer;

import java.util.Scanner;

import com.area.calculateLayer.CalculateRectangle;
import com.area.calculateLayer.CalculateSquare;
import com.area.calculateLayer.CalculateTriangle;
import com.area.staticResource.GeometricType;

public class IfCalculate {
	Scanner scanner=new Scanner(System.in);
	public IfCalculate(String str)throws Exception{
		
		if(str==GeometricType.square) {
			System.out.println("�����������εı߳�:");
			System.out.print("a=");
			double a=scanner.nextDouble();
			new CalculateSquare(a);
		}
		if(str==GeometricType.rectangle) {
			System.out.println("��������ε������߳� a��b:");
			System.out.print("a=");
			double a=scanner.nextDouble();
			System.out.print("b=");
			double b=scanner.nextDouble();
			new CalculateRectangle(a,b);
		}
		if(str==GeometricType.triangle) {
			System.out.println("�����������εĵ׺͸� d��h:");
			System.out.print("d=");
			double d=scanner.nextDouble();
			System.out.print("h=");
			double h=scanner.nextDouble();
			new CalculateTriangle(d,h);
		}
	}
}
