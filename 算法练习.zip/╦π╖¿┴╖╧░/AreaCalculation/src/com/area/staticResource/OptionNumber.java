package com.area.staticResource;

public class OptionNumber {
	public final static String[] optionNumberEnglish= {"a","b","c"};
}
