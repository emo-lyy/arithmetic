package ������;

import java.util.Scanner;

/**
 *��������
4 5
1 1 0 0 0
1 1 0 0 0
0 0 1 0 0
0 0 0 1 1

3



4 5
1 1 1 1 0
1 1 0 1 0
1 1 0 0 0
0 0 0 0 0

1

 * @author ��ħ
 *
 */
public class �������� {
	static int n,m;
	static char[][] A;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new char[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				A[i][j]=scanner.next().charAt(0);
			}
		}
		scanner.close();
		int res=f(A);
		System.out.println(res);
	}
	static int f(char[][] A) {
		int count=0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(A[i][j]=='1') {
					count++;			//�൱��ÿ����ڶ���һ������
					dfs(i,j,A);
				} 
			}
		}
		return count;
	}
	static void dfs(int y,int x,char[][] A) {
		//left
		if(x-1>=0 && A[y][x-1]=='1') {
			A[y][x-1]='0';
			dfs(y,x-1,A);
		}
		//right
		if(x+1<m && A[y][x+1]=='1') {
			A[y][x+1]='0';
			dfs(y,x+1,A);
		}
		//top
		if(y-1>=0 && A[y-1][x]=='1') {
			A[y-1][x]='0';
			dfs(y-1,x,A);
		}
		//down
		if(y+1<n && A[y+1][x]=='1') {
			A[y+1][x]='0';
			dfs(y+1,x,A);
		}
	}
	
	static void out(char[][] A) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
		}
	}
}
