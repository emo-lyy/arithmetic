package ������;

import java.util.ArrayList;
import java.util.List;

public class �������� {
	final static String[] A="A,2,3,4,5,6,7,8,9,10,J,Q,K".split(",");
	static int count=0;
	public static void main(String[] args) {
		dfs(0,new ArrayList<String>());
		System.out.println(count);
	}
	
	static void dfs(int n,List<String> data) {
		if(data.size()==13) {
			System.out.println(data);
			count++;
			return;
		}
		if(n>=A.length || data.size()>13)return;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < i; j++) {
				data.add(A[n]);
			}
			dfs(n+1,data);
			//����
			for (int j = 0; j < i; j++) {
				data.remove(data.size()-1);
			}
		}
	}
}
