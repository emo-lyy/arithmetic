package ������;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ��ԭIP��ַ {
	static String s;
	static int len;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		s=scanner.next();
		len=s.length();
		scanner.close();
		dfs(0,new ArrayList<String>());
	}
	
	static void dfs(int index,List<String> data) {
		if(data.size()>4 || index>len)return;
		if(data.size()==4 && index==len) {
			System.out.println(data);
			return;
		}
		for (int i = index; i < index+3 && i<len; i++) {
			String temp=s.substring(index,i+1);
			if((temp.length()>1 && temp.charAt(0)=='0') || Integer.valueOf(temp)>255) {
				return;
			}else {
				data.add(temp);
				dfs(i+1,data);
				data.remove(data.size()-1);		//����
			}
		}
	}
}
