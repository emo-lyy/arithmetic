package 测试五;

import java.util.Scanner;

/**
 * 题目
 * 	7-9 旅游规划（25 分）

有了一张自驾旅游路线图，你会知道城市间的高速公路长度、以及该公路要收取的过路费。现在需要你写一个程序，帮助前来咨询的游客找一条出发地和目的地之间的最短路径。如果有若干条路径都是最短的，那么需要输出最便宜的一条路径。

输入格式:
输入说明：输入数据的第1行给出4个正整数N、M、S、D，其中N（2≤N≤500）是城市的个数，顺便假设城市的编号为0~(N−1)；M是高速公路的条数；S是出发地的城市编号；D是目的地的城市编号。随后的M行中，每行给出一条高速公路的信息，分别是：城市1、城市2、高速公路长度、收费额，中间用空格分开，数字均为整数且不超过500。输入保证解的存在。

输出格式:
在一行里输出路径的长度和收费总额，数字间以空格分隔，输出结尾不能有多余空格。

输入样例:
4 5 0 3
0 1 1 20
1 3 2 30
0 3 4 10
0 2 2 20
2 3 1 20
输出样例:
3 40
 * @author 恶魔
 *
 */
public class 旅游规划 {
	static int n,m,s,d;			//	城市的个数、	M是高速公路的条数、S是出发地的城市编号、D是目的地的城市编号
	static int[] N,M,S,D;
	static int MINLEN=0;		//最短长度
	static int MINMONEY=0;		//最少的钱
	static boolean check=true;		//判断是不是第一次找到路径
	public static void main(String[] args) {
		initData();
		dfs(s,d,0,0);
		System.out.println(MINLEN+" "+MINMONEY);
	}
	
	/**
	 * 
	 * @param a	出发地
	 * @param b	目的地
	 * @param len	路径
	 * @param money	钱
	 */
	static void dfs(int a,int b,int len,int money) {
		if(a==b) {
			//从a地到达b地
			if(check) {
				MINLEN=len;
				MINMONEY=money;
				check=false;
			}else {
				if(MINLEN>len) {
					MINLEN=len;
					MINMONEY=money;
				}else if(MINLEN==len) {
					if(MINMONEY>money) {
						MINLEN=len;
						MINMONEY=money;
					}
				}
			}
			return;
		}
		for (int i = 0; i < m; i++) {
			if(N[i]==a) {
				dfs(M[i],b,len+S[i],money+D[i]);
			}
		}
	}
	
	/**
	 * 初始化数据
	 */
	static void initData() {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		s=scanner.nextInt();		//出发地
		d=scanner.nextInt();		//目的地
		N=new int[m];
		M=new int[m];
		S=new int[m];
		D=new int[m];
		for (int i = 0; i < m; i++) {
			N[i]=scanner.nextInt();
			M[i]=scanner.nextInt();
			S[i]=scanner.nextInt();
			D[i]=scanner.nextInt();		
		}
		scanner.close();
	}
}
