package ������;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class �绰�������ĸ��� {
	static Map<String, String> map;
	public static void main(String[] args) {
		initData();
		System.out.println(f("234"));
	}
	static List<String> f(String s){
		String[] S=s.split("");
		List<String> data=dfs(S[0]);
		for (int i = 1; i < S.length; i++) {
			List<String> box1=new ArrayList<>(data);		//����һ��data
			List<String> box2=dfs(S[i]);
			data.clear();  	//���¹���data
			for (int a = 0; a < box1.size(); a++) {
				for (int b = 0; b < box2.size(); b++) {
					data.add(box1.get(a)+box2.get(b));
				}
			}
		}
		return data;
	}
	static List<String> dfs(String index){
		List<String> data=new ArrayList<>();
		for (int i = 0; i < map.get(index).length(); i++) {
			data.add(map.get(index).charAt(i)+"");
		}
		return data;
	}
	
    public static List<String> letterCombinations(String digits) {
        
        List<String> list = new ArrayList<String>();
        if(digits.length() == 0)
            return list;
        HashMap<Integer, String> map = new HashMap<Integer, String>();
        map.put(2, "abc");
        map.put(3, "def");
        map.put(4, "ghi");
        map.put(5, "jkl");
        map.put(6, "mno");
        map.put(7, "pqrs");
        map.put(8, "tuv");
        map.put(9, "wxyz");
        for(int i = 0; i < map.get(digits.charAt(0) - 48).length(); i++){
            list.add(map.get(digits.charAt(0) - 48).substring(i,i+1));
        }
        for(int i = 1; i < digits.length(); i++){
            String str = map.get(digits.charAt(i) - 48);
            int len = list.size();
            for(int k = 0; k < len; k++){
                String s = list.get(0);
                list.remove(0);
                for(int m = 0; m < str.length(); m++){
                    list.add(s + str.substring(m,m+1));
                }
            }
        }
        return list;
    }
	
	static void initData() {
		map=new HashMap<String, String>();
        map.put("2", "abc");
        map.put("3", "def");
        map.put("4", "ghi");
        map.put("5", "jkl");
        map.put("6", "mno");
        map.put("7", "pqrs");
        map.put("8", "tuv");
        map.put("9", "wxyz");
	}
}
