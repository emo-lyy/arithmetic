package ������;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ����֮�� {
	static int n;
	static int[] nums;
	static int target;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		nums=new int[n];
		for (int i = 0; i < n; i++) {
			nums[i]=scanner.nextInt();
		}
		target=scanner.nextInt();
		scanner.close();
		dfs(0,new ArrayList<Integer>(),0);
	}
	
	static void dfs(int index,List<Integer> box,int sum) {
		if(box.size()==4 && sum==target) {
			System.out.println(box);
			return;
		}
		if(index>=n)return;
		dfs(index+1,box,sum);		//������
		
		box.add(nums[index]);			//����
		dfs(index+1,box,sum+nums[index]);
		box.remove(box.size()-1);
		sum-=nums[index];
	}
}
