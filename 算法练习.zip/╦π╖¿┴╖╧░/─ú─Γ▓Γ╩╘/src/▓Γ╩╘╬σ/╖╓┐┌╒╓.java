package ������;

import java.util.ArrayList;
import java.util.List;

public class �ֿ��� {
	public static final long data[]={
			9090400L,
			8499400L,
			5926800L,
			8547000L,
			4958200L,
			4422600L,
			5751200L,
			4175600L,
			6309600L,
			5865200L,
			6604400L,
			4635000L,
			10663400L,
			8087200L,
			4554000L};
	static long min=0L;
	static List<Long> box1,box2;
	static boolean check=true;		//�ж��Ƿ��ǵ�һ�ν���
	public static void main(String[] args) {
		dfs(0,new ArrayList<Long>(),new ArrayList<>());
		System.out.println();
		System.out.println("-----------------------------------------------------");
		System.out.println("------------------------------------------------------");
		System.out.println(min);
		System.out.println(box1);
		System.out.println(box2);
	}
	
	/**
	 * ����˼·�����Ǹ�AҽԺ�����Ǹ�BҽԺ
	 * @param index		��ǰ����
	 * @param A			AҽԺ
	 * @param B			BҽԺ
	 */
	static void dfs(int index,List<Long> A,List<Long> B) {
		if(index==data.length) {
			System.out.println(A);
			System.out.println(B);
			System.out.println("--------------------------------------------------------------------------------");
			if(check) {
				min=Math.abs(sum(A)-sum(B));
				box1=new ArrayList<>(A);
				box2=new ArrayList<>(B);
				check = false;
			}else {
				long k=Math.abs(sum(A)-sum(B));
				if(k<min) {
					min=k;
					box1=new ArrayList<>(A);
					box2=new ArrayList<>(B);
				}
			}
			return;
		}
		A.add(data[index]);
		dfs(index+1,A,B);		//��AҽԺ
		A.remove(A.size()-1);		//����
		
		B.add(data[index]);
		dfs(index+1,A,B);
		B.remove(B.size()-1);		//����
	}
	
	static long sum(List<Long> data) {
		long sum=0L;
		for (Long l : data) {
			sum+=l;
		}
		return sum;
	}
	
}
