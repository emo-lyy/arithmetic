package ������;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * ���԰���		(���ϲ����ظ�)   [2 3 3]  [3 2 3] [3 3 2]  ����ͬʱ����
4
2 3 6 7
7

3
2 3 5
8
 * @author ��ħ
 *
 */
public class ����ܺ� {
	static int n;		//����ĳ���
	static int[] candidates;
	static int target;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		candidates=new int[n];
		for (int i = 0; i < n; i++) {
			candidates[i]=scanner.nextInt();
		}
		target=scanner.nextInt();
		scanner.close();
		dfs(target,new ArrayList<Integer>());
	}
	
	static void dfs(int target,List<Integer> A) {
		if(target<0)return;
		if(target==0) {
			System.out.println(A);
			return;
		}
		for(int i=0;i<n;i++) {
			if(A.size()==0 || candidates[i]>=A.get(A.size()-1)) {
				A.add(candidates[i]);
				dfs(target-candidates[i],A);
				A.remove(A.size()-1);		//����	
			}
			
		}
	}
}
