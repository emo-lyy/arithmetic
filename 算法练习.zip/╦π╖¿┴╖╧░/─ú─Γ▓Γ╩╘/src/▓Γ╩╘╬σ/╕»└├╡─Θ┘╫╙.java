package ������;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ���õ����� {
	static int n,m;
	static int[][] A;
	static int minTime;
	static boolean check=true;
	static boolean end=true;			//�Ƿ������ֹѭ������û����һ����
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		A=new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				A[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		f(A);
	}
	
	static void f(int[][] A) {
		List<Tool> list=new ArrayList<���õ�����.Tool>();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if(A[i][j]==2) {
					Tool tool=new Tool(i, j);
					list.add(tool);
				}	
			}
		}
		dfs(list,0,A);
		if(check) {
			System.out.println(-1);
		}else {
			System.out.println(minTime);
		}
	}
	
	static void dfs(List<Tool> list,int k,int[][] A) {
		if(check(A)) {	
			check=false;
			minTime=k;
			return;
		}
		end=true;	
		List<Tool> box=new ArrayList<>(list);
		for(Tool tool : list) {
			//����ˮ���ĵ�ַ
			int y=tool.y;
			int x=tool.x;
			//top
			if(y-1>=0 && A[y-1][x]==1) {
				A[y-1][x]=2;		//�õı仵
				box.add(new Tool(y-1, x)); 		//���뻵�˵ļ���
				end=false;
			}
			//down
			if(y+1<n && A[y+1][x]==1) {
				A[y+1][x]=2;
				box.add(new Tool(y+1, x));
				end=false;
			}
			//left
			if(x-1>=0 && A[y][x-1]==1) {
				A[y][x-1]=2;
				box.add(new Tool(y, x-1));
				end=false;
			}
			//right
			if(x+1<m && A[y][x+1]==1) {
				A[y][x+1]=2;
				box.add(new Tool(y, x+1));
				end=false;
			}
		}
		//���沽�趼û��ִ��
		if(end) {
			check=false;
			minTime=-1;
			return;
		}
		dfs(box,k+1,A);
	}
	
	/**
	 * �ж��Ƿ�ȫ������
	 * @param A
	 * @return
	 */
	static boolean check(int[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[0].length; j++) {
				if(A[i][j]==1)return false;
			}
		}
		return true;
	}
	private static class Tool{
		private int y,x;

		public Tool(int y, int x) {
			super();
			this.y = y;
			this.x = x;
		} 
		
	}
}
