package ������;

import java.util.Calendar;

public class ���� {
	static int day=1;
	public static void main(String[] args) {
		Calendar calendar=Calendar.getInstance();
		for (int i = 2000; i < 2020; i++) {
			for (int j = 1; j < 13; j++) {
				calendar.set(i, j,0);
				day+=calendar.get(Calendar.DAY_OF_MONTH);
			}
		}
		
		for (int i = 1; i < 10; i++) {
			calendar.set(2020, i,0);
			day+=calendar.get(Calendar.DAY_OF_MONTH);
		}
		System.out.println(day);
	}
}
