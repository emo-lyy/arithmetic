package ������;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ��� {
	static int n,m;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		m=scanner.nextInt();
		scanner.close();
		dfs(m,new ArrayList<Integer>());
	}
	
	static void dfs(int m,List<Integer> A) {
		if(m==0) {
			System.out.println(A);
			return;
		}
		for (int i = 1; i <= n; i++) {
			if(A.size()==0 || i>A.get(A.size()-1)) {
				A.add(i);
				dfs(m-1,A);
				A.remove(A.size()-1);
			}
		}
	}
}
