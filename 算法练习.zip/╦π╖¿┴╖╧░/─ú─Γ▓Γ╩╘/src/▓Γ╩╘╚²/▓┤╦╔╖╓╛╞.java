package ������;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * ��������
12 8 5
12 0 0
6
 * @author ��ħ
 *
 */
public class ���ɷ־� {
	static int v1,v2,v3;		//��������
	static int l1,l2,l3;			//ÿ�������ĳ�ʼֵ
	static int k;				//�ﵽ��״̬
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		v1=scanner.nextInt();
		v2=scanner.nextInt();
		v3=scanner.nextInt();
		l1=scanner.nextInt();
		l2=scanner.nextInt();
		l3=scanner.nextInt();
		k=scanner.nextInt();
		scanner.close();
		
		ArrayList<XYZ> list=new ArrayList<>();
		XYZ xyz=new XYZ();
		xyz.x=l1;
		xyz.y=l2;
		xyz.z=l3;
		
		if(l1>0) {
			dfs(l1-1,l2+1,l3,list,"atob");
			dfs(l1-1,l2,l3+1,list,"atoc");
		}
		if(l2>0) {
			dfs(l1+1,l2-1,l3,list,"atob");
			dfs(l1,l2-1,l3+1,list,"atoc");
		}
		if(l3>0) {
			dfs(l1+1,l2,l3-1,list,"atob");
			dfs(l1,l2+1,l3-1,list,"atoc");
		}
		System.out.println("������");
	}
	
	static void dfs(int a,int b,int c,ArrayList<XYZ> list,String p) {
		if(a<0 || b<0 || c<0)return;
		if(a>v1 || b>v2 || c>v3)return;
		

		XYZ xyz=new XYZ();
		xyz.x=a;
		xyz.y=b;
		xyz.z=c;
		list.add(xyz);
		
		
		if(a==k || b==k || c==k) {
			out(list);
			System.out.println();
			System.exit(0);
		}
		
		if(!p.equals("atob")) {
			dfs(a+1,b-1,c,list,"btoa");
		}
		if(!p.equals("atoc")) {
			dfs(a+1,b,c-1,list,"ctoa");
		}
		if(!p.equals("btoa")) {
			dfs(a-1,b+1,c,list,"atob");
		}
		if(!p.equals("btoc")) {
			dfs(a,b+1,c-1,list,"ctob");
		}
		if(!p.equals("ctoa")) {
			dfs(a-1,b,c+1,list,"atoc");
		}
		if(!p.equals("ctob")) {
			dfs(a,b-1,c+1,list,"btoc");
		}
	}
	
	static void out(ArrayList<XYZ> list) {
		for (XYZ xyz : list) {
			System.out.println(xyz.x+" "+xyz.y+" "+xyz.z);
		}
	}
	
	private static class XYZ{
		private int x,y,z;
	}
}
