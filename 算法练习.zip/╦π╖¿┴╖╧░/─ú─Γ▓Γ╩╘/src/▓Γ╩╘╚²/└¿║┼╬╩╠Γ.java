package ������;

import java.util.Stack;

public class �������� {
	public static boolean isGoodBracket(String s)
	{
		Stack<Character> a = new Stack<Character>();			//ջ
		
		for(int i=0; i<s.length(); i++)
		{
			char c = s.charAt(i);
			if(c=='(') a.push(')');								//����ջ��
			if(c=='[') a.push(']');								//����ջ
			if(c=='{') a.push('}');
			
			if(c==')' || c==']' || c=='}')
			{
				if(a.size()==0) return false;    // ���
				if(a.pop() != c) return false;					//�Ƴ�ջ
			}
		}
		
		if(a.size()!=0) return false;  // ���
		
		return true;
	}
	
	public static void main(String[] args)
	{
		System.out.println( isGoodBracket("...(..[.)..].{.(..).}..."));
		System.out.println( isGoodBracket("...(..[...].(.).){.(..).}..."));
		System.out.println( isGoodBracket(".....[...].(.).){.(..).}..."));
		System.out.println( isGoodBracket("...(..[...].(.).){.(..)...."));
	}
}
