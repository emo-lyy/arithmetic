package ������;

public class ������ {
	static int N=0;
	public static void main(String[] args) {
		int[][] x =new int[][] {
				{1,0,0,0,0,0},
				{0,0,1,0,1,0},
				{0,0,1,1,0,1},
				{0,1,0,0,1,0},
				{0,0,0,1,0,0},
				{1,0,1,0,0,1}
			};

			f(x, 0, 0);
			
			System.out.printf("%d\n", N);
	}

	static void f(int x[][], int r, int c)
	{
		if(r==6)
		{
			if(CheckStoneNum(x))
			{
				N++;
				show(x);
			}
			return;
		}
	
		if(x[r][c]==1)  // �Ѿ�����������  // ���
		{
			GoNext(x,r,c);
			return;
		}
		
		int rr = GetRowStoneNum(x,r);
		int cc = GetColStoneNum(x,c);
	
		if(cc>=3)  // ��������
			GoNext(x,r,c);  
		else if(rr>=3)  // ��������
			f(x, r+1, 0);   
		else
		{
			x[r][c] = 1;
			GoNext(x,r,c);
			x[r][c] = 0;
			
			if(!(3-rr >= 6-c || 3-cc >= 6-r))  // ���л�������ȱ�ӣ��򱾸��ܿ��ţ�
				GoNext(x,r,c);  
		}
	}
	
	static void GoNext(int x[][],  int r,  int c)
	{
		if(c<6)
			f(x,r+(c+1)/6,(c+1)%6);// ���
		else
			f(x, r+1, 0);        	//�������
	}
	

//	static void f(int x[][], int r, int c);
	

	static boolean CheckStoneNum(int x[][])
	{
		for(int k=0; k<6; k++)
		{
			int NumRow = 0;
			int NumCol = 0;
			for(int i=0; i<6; i++)
			{
				if(x[k][i]==1) NumRow++;
				if(x[i][k]==1) NumCol++;
			}
			if(NumRow!=3 || NumCol!=3 ) return false;  // ���
		}
		return true;
	}
	
	static int GetRowStoneNum(int x[][], int r)
	{
		int sum = 0;
		for(int i=0; i<6; i++) 	if(x[r][i]==1) sum++;
		return sum;
	}
	
	static int GetColStoneNum(int x[][], int c)
	{
		int sum = 0;
		for(int i=0; i<6; i++) 	if(x[i][c]==1) sum++;
		return sum;
	}
	
	static void show(int x[][])
	{
		for(int i=0; i<6; i++)
		{
			for(int j=0; j<6; j++) System.out.printf("%2d", x[i][j]);
			System.out.println();
		}
		System.out.println();
	}
	
}
