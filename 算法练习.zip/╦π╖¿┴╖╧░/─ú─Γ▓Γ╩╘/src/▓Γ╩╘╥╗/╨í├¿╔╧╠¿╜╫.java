package ����һ;

import java.util.Scanner;

/**
 * ����
 * 	f(n)=2^n-1
 * @author ��ħ
 *
 */
public class Сè��̨�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		long res=f(scanner.nextInt());
		scanner.close();
		System.out.println(res);
	}
	
	static long f(int n) {
		long res=1l;
		for(int i=1;i<n;i++) {
			res*=2;
		}
		return res;
	}
}
