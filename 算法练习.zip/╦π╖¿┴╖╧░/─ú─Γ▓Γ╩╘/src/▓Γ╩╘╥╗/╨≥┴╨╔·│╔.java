package ����һ;

import java.util.Scanner;

public class �������� {
	static int n;
	static int[] begin,end;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		n=scanner.nextInt();
		begin=new int[n];
		end=new int[n];
		for(int i=0;i<n;i++) {
			begin[i]=scanner.nextInt();
			end[i]=scanner.nextInt();
		}
		scanner.close();
		for(int k=0;k<n;k++) {
			int b=begin[k];
			int e=end[k];
			int max=0;
			for(int i=b;i<=e;i++) {
				int res=dfs(i,1);
				max=max>res?max:res;
			}
			System.out.println(b+" "+e+" "+max);
		}
	}
	
	static int dfs(int n,int count) {
		if(n==1) {
			return count;
		}
		if(n%2==0) {
			return dfs(n/2,count+1);
		}else {
			return dfs(n*3+1,count+1);
		}
	}
}
