package ����һ;

import java.util.Scanner;

public class ȡ���� {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n =scanner.nextInt();
		int[] A=new int[n];
		for(int i=0;i<n;i++) {
			A[i]=scanner.nextInt();
		}
		scanner.close();
		for(int i=0;i<n;i++) {
			if(getBoll(A[i])){
				System.out.println(1);
			}else {
				System.out.println(0);
			}
		}
	}

	private static boolean getBoll(int n) { //ÿ�ε����Լ�ȡ��
		if (n==1)   return  false;
		if (n==2)	return  true;
		if (n==3)  	return  false;
		if (n>8)  	return  !getBoll(n-1)||!getBoll(n-3)||!getBoll(n-7)||!getBoll(n-8);
		if (n>7) 	return  !getBoll(n-1)||!getBoll(n-3)||!getBoll(n-7);
		if (n>=4)	return  !getBoll(n-1)||!getBoll(n-3);
		return false;
	}
}
