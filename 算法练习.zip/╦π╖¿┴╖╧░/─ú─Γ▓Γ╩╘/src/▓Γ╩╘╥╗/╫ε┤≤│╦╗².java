package ����һ;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * ˼·��
 * 	��ȫ���У��ڷָ�ڼ���
 * @author ��ħ
 *
 */
public class ���˻� {
	static char[] A="123456789".toCharArray();
	static long max=0l;
	
	public static void main(String[] args) {
		long beginTime=System.currentTimeMillis();
		f(A);
		System.out.println(max);
		long endTime=System.currentTimeMillis();
		System.out.println("�ܹ�����ʱ��:"+(endTime-beginTime)+"ms");
	}
	
	static void f(char[] A) {
		dfs(0,A);
	}
	
	static void dfs(int index,char[] A) {
		if(index==A.length) {
			//System.out.println(Arrays.toString(A));
			String temp=new String(A);
			for(int i=1;i<A.length;i++) {
				int a=Integer.valueOf(temp.substring(0,i));
				int b=Integer.valueOf(temp.substring(i,A.length));
				long k=Long.valueOf(a*b);
				if(check((k+"").toCharArray())) {
					max=max>k?max:k;
				}
			}
		}
		for(int i=index;i<A.length;i++) {
			swap(A,index,i);
			dfs(index+1,A);
			swap(A,index,i);
		}
	}
	
	static void swap(char[] A,int i,int j) {
		char temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
	
	static boolean check(char[] A) {
		Set<String> set=new HashSet<>();
		for(int i=0;i<A.length;i++) {
			if(set.contains(A[i]+"") || A[i]=='0') {
				return false;
			}else {
				set.add(A[i]+"");
			}
		}
		return true;
	}
}
