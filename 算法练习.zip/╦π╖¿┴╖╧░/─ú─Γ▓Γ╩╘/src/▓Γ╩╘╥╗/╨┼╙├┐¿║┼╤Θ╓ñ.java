package ����һ;

import java.util.Scanner;

public class ���ÿ�����֤ {
	static String id=null;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		id=scanner.next();
		scanner.close();
		if(check(id)) {
			System.out.println("�ɹ�");
		}else {
			System.out.println("ʧ��");
		}
	}
	
	
	static boolean check(String id) {
		int res=count(id);
		if(res%10==0) return true;
		else return false;
	}
	
	static int count(String id) {
		int ji=0;
		int ou=0;
		int index=1;
		for(int i=id.length()-1;i>=0;i--) {
			if(index%2==1) {
				//����λ
				ji+=id.charAt(i)-'0';
			}else {
				int temp=(id.charAt(i)-'0')*2;
				if(temp>=10) {
					temp-=9;
				}
				ou+=temp;
			}
			index++;
		}
		return ji+ou;
	}
}
