package ���Զ�;

public class �ƽ���� {
	static String k="0.618034";
	public static void main(String[] args) {
		for(int i=1;i<100;i++) {
			double h=Z(i)/M(i);
			String temp=String.format("%.6f", h);
			if(temp.equals(k)) {
				System.out.println(Z(i)+"/"+M(i));
				return;
			}
		}
	}
	
	static double Z(int n) {
		if(n==1) return 1.0;
		if(n==2) return 3.0;
		return Z(n-1)+Z(n-2);
	}
	
	static double M(int n) {
		if(n==1) return 3.0;
		if(n==2) return 4.0;
		return M(n-1)+M(n-2);
	}
}
