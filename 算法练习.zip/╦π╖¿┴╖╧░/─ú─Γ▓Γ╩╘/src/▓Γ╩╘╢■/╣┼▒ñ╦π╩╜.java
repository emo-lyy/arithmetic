package ���Զ�;

public class �ű���ʽ {
	public static void main(String[] args) {
		for (int a = 0; a < 10; a++) {
			for (int b = 0; b < 10; b++) {
				for (int c = 0; c < 10; c++) {
					for (int d = 0; d < 10; d++) {
						for (int e = 0; e < 10; e++) {
							for (int k = 0; k < 10; k++) {
								if(a!=b && a!=c && a!=d && a!=e && a!=k
									   && b!=c && b!=d && b!=e && b!=k
								                && c!=d && c!=e && c!=k
								                && d!=e && d!=k
								                && e!=k) {
									int ABCDE=Integer.valueOf(a+""+b+""+c+""+d+""+e);
									int EDCBA=Integer.valueOf(e+""+d+""+c+""+b+""+a);
									if(ABCDE * k ==EDCBA) {
										System.out.println(ABCDE+" * "+k+" = "+EDCBA);
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
