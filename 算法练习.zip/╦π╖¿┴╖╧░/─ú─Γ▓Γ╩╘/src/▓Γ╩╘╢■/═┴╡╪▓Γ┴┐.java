package ���Զ�;

public class ���ز��� {
	public static void main(String[] args) {
		double s1=new Double(f(52.1,33.4,68.2));
		double s2=new Double(f(68.2,57.2,71.9));
		double s3=new Double(f(51.9,71.9,43.5));
		System.out.printf("%.2f",(s1+s2+s3));
	}
	static String f(double a,double b,double c) {
		double s=(a+b+c)/2.0;
		double A=Math.sqrt(s*(s-a)*(s-b)*(s-c));
		return String.format("%.2f", A);
	}
}
