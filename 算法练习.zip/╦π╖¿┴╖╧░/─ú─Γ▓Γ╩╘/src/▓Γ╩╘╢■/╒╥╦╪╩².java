package ���Զ�;

public class ������ {
	public static void main(String[] args) {
		int count=0;
		for (int i = 2; true; i++) {
			if(check(i)) {
				count++;
				if(count==100002) {
					System.out.println(i);
					return;
				}
			}
		}
	}
	
	static boolean check(int n) {
		for(int i=2;i<n;i++) {
			if(n%i==0)return false;
		}
		return true;
	}
}
