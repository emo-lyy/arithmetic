package ���Զ�;

public class �����ɺ� {
	public static void main(String[] args) {
		for(int i=2000;i<2014;i++) {
			int k=2014-i;		//����
			String s=i+"";
			int sum=0;
			for(int j=0;j<s.length();j++) {
				sum+=s.charAt(j)-'0';
			}
			if(sum==k) {
				System.out.println(i);
			}
		}
	}
}
