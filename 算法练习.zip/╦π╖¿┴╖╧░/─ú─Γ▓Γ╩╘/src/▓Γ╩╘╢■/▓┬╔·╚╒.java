package ���Զ�;

public class ������ {
	public static void main(String[] args) {
		for(int y=1000;y<2012;y++) {
			for(int d=1;d<31;d++) {
				String k=y+"06";
			
				//6��30��
				if((d+"").length()==2) {
					k+=d+"";
				}else {
					k+="0"+d;
				}
				int q=Integer.valueOf(k);
				if(check(q)) {
					System.out.println(q);
				}
			}
		}
	}
	
	static boolean check(int n) {
		if(n%2012==0 && n%3==0 && n%12==0) {
			return true;
		}else {
			return false;
		}
	}
}
