package ���Զ�;

public class �������� {
	public static void main(String[] args) {
		double k=2.0/45.0;
		int count=0;
		for (double i = 2.0; i < 10000; i++) {
			for (double j = 2.0; j < 10000; j++) {
				if(i<j) {
					double a=1.0/i;
					double b=1.0/j;
					if(a+b==k) {
						System.out.println("1/"+i+" + "+"1/"+j);
						count++;
					}
				}
			}
		}
		System.out.println(count);
	}
}
