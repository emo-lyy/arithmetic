package ���Զ�;

public class �Ⱦ��� {
	public static void main(String[] args) {
		for(int i=20;i>=4;i--) {
			for(int j=19;j>=3;j--) {
				for(int x=18;x>=2;x--) {
					for(int y=17;y>=1;y--) {
						if(i>j && j>x && x>y) {
							double k=(1.0/i)+(1.0/j)+(1.0/x)+(1.0/y);
							if(k==1) {
								System.out.println(i+","+j+","+x+","+y+","+0);
							}
						}
					}
				}
			}
		}
	}
}
