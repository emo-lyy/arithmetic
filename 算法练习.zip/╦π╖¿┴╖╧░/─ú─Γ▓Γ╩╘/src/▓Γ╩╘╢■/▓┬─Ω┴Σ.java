package ���Զ�;

public class ������ {
	public static void main(String[] args) {
		for (int i = 1; i < 100; i++) {
			for (int j = 1; j < 100; j++) {
				if(i<j && j-i<=8) {
					if((i*j)==(i+j)*6) {
						System.out.println(i+" "+j);
					}
				}
			}
		}
	}
}
