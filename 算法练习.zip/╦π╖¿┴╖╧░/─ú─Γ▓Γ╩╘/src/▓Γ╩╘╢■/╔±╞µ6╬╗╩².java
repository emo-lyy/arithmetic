package ���Զ�;

import java.util.HashSet;
import java.util.Set;

public class ����6λ�� {
	public static void main(String[] args) {
		for(int i=100000;i<1000000;i++) {
			if(checkLen(i*2) && checkLen(i*3) && checkLen(i*4) && checkLen(i*5) && checkLen(i*6)) {
				//System.out.println(i);
				if(checkNum(i, i*2)) {
					if(checkNum(i, i*3)) {
						if(checkNum(i, i*4)) {
							if(checkNum(i, i*5)) {
								if(checkNum(i, i*6)) {
									System.out.println(i);
								}
							}
						}
					}
				}
			}
		}
	}
	
	static boolean checkLen(int n) {
		if((n+"").length()!=6) {
			return false;
		}else {
			return true;
		}
	}
	
	static boolean checkNum(int a,int b) {
		Set<String> set=new HashSet<>();
		String[] A=(a+"").split("");
		for(int i=0;i<A.length;i++) {
			set.add(A[i]);
		}
		String[] B=(b+"").split("");
		for (String s : A) {
			int countA=0;
			int countB=0;
			for (int i = 0; i < A.length; i++) {
				if(A[i].equals(s)) {
					countA++;
				}
			}
			for (int i = 0; i < B.length; i++) {
				if(B[i].equals(s)) {
					countB++;
				} 
			}
			if(countA!=countB)return false;
		}
		return true;
	}
}
