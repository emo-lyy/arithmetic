package ���Զ�;

public class �ú�ѧϰ {
	static char[] A="�ú�ѧϰ".toCharArray();
	static int count=0;
	static int sum=0;
	public static void main(String[] args) {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				for (int x = 0; x < 4; x++) {
					for (int k = 0; k < 4; k++) {
						if(i!=j && i!=x && i!=k
							  && j!=x && j!=k
							  		  && x!=k) {
							sum++;
							String temp=A[i]+""+A[j]+""+A[x]+""+A[k];
							System.out.println(temp);
							if(temp.equals("�ú�ѧϰ")) {
								count++;
							}
						}
					}
				}
			}
		}
		System.out.println("�ܹ���:"+count+"/"+sum);
	}
}
