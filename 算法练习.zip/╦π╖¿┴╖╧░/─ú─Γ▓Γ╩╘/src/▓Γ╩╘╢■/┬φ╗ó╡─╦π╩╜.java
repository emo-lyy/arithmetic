package ���Զ�;

public class ��������ʽ {
	public static void main(String[] args) {
		int count=0;
		for (int a = 1; a < 10; a++) {
			for (int b = 1; b < 10; b++) {
				for (int c = 1; c < 10; c++) {
					for (int d = 1; d < 10; d++) {
						for (int e = 1; e < 10; e++) {
							if(a!=b && a!=c && a!=d && a!=e
									&& b!=c && b!=d && b!=e 
										    && c!=d && c!=e
										    && d!=e) {
								int ab=Integer.valueOf(a+""+b);
								int cde=Integer.valueOf(c+""+d+""+e);
								int adb =Integer.valueOf(a+""+d+""+b);
								int ce =Integer.valueOf(c+""+e);
								if(ab*cde==adb*ce) {
									System.out.println(ab+" * "+cde+" = "+adb+" * "+ce);
									count++;
								}
							}
						}
					}
				}
			}
		}
		System.out.println(count);
	}
}
