package ���Զ�;

public class �˿����� {
	static char[] A="AA223344".toCharArray();
	public static void main(String[] args) {
		dfs(0,A);
	}
	
	static void dfs(int index,char[] A) {
		if(index==A.length) {
			String s=new String(A);
			if(check(s)) {
				System.out.println(s);
			}	
			return;
		}
		for(int i=index;i<A.length;i++) {
			swap(A,index,i);
			dfs(index+1,A);
			swap(A,index,i);
		}
	}
	
	static void swap(char[] A,int i,int j) {
		char temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
	
	static boolean check(String s) {
		int beginA=s.indexOf('A');
		int begin2=s.indexOf('2');
		int begin3=s.indexOf('3');
		int begin4=s.indexOf('4');
		int endA=beginA;
		int end2=begin2;
		int end3=begin3;
		int end4=begin4;
		
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='A') {
				endA=i;
			}
			if(s.charAt(i)=='2') {
				end2=i;
			}
			if(s.charAt(i)=='3') {
				end3=i;
			}
			if(s.charAt(i)=='4') {
				end4=i;
			}
		}
		if(endA-beginA!=2)return false;
		if(end2-begin2!=3)return false;
		if(end3-begin3!=4)return false;
		if(end4-begin4!=5)return false;
		return true;
	}
}
