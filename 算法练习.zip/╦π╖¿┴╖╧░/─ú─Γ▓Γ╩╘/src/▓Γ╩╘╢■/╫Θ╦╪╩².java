package ���Զ�;

public class ������ {
	static char[] A="1949".toCharArray();
	static int count=0;
	public static void main(String[] args) {
		dfs(0,A);
		System.out.println(count);
	}
	
	static void dfs(int index,char[] A) {
		if(index==A.length) {
			String s=new String(A);
			if(check(Integer.valueOf(s))) {
				System.out.println(s);
				count++;
			}
			return;
		}
		for (int i = index; i < A.length; i++) {
			swap(A,index,i);
			dfs(index+1,A);
			swap(A, index, i);
		}
	}
	
	static void swap(char[] A,int i,int j) {
		char temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
	
	static boolean check(int n) {
		for (int i = 2; i < n; i++) {
			if(n%i==0)return false;
		}
		return true;
	}
}
