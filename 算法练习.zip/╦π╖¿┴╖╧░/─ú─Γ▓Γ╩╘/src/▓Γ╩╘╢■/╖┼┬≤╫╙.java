package ���Զ�;

import java.math.BigInteger;

public class ������ {
	public static void main(String[] args) {
		BigInteger sum=BigInteger.ZERO;
		for(int i=0;i<64;i++) {
			BigInteger temp=BigInteger.ONE;
			for(int j=1;j<=i;j++) {
				temp=temp.multiply(new BigInteger("2"));
			}
			//System.out.println(temp);
			sum=sum.add(temp);
		}
		System.out.println(sum.toString());
	}
}
