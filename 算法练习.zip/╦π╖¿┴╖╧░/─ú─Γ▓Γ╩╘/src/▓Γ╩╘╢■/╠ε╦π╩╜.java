package ���Զ�;

public class ����ʽ {
	static char[] A="123456789".toCharArray();
	static int count=0;
	public static void main(String[] args) {
		dfs(0,A);
		System.out.println(count);
	}
	static void dfs(int index,char[] A) {
		if(index==A.length) {
			String s=new String(A);
			if(check(s)) {
				count++;
			}
			return;
		}
		for(int i=index;i<A.length;i++) {
			swap(A, index, i);
			dfs(index+1,A);
			swap(A, index, i);
		}
	}
	
	static void swap(char[] A,int i,int j) {
		char temp=A[i];
		A[i]=A[j];
		A[j]=temp;
	}
	
	static boolean check(String s) {
		int A=Integer.valueOf(s.substring(0,3));
		int B=Integer.valueOf(s.substring(3,6));
		int C=Integer.valueOf(s.substring(6,9));
		if(A+B==C) {
			return true;
		}else {
			return false;
		}
	}
}
