package ���Զ�;

import java.util.ArrayList;

public class ����ĸ {
	public static void main(String[] args) {
		ArrayList<String> A=new ArrayList<>();
		for(int j=0;j<106;j++) {
			for(int i=(int) 'a'; i<=(int)'s';i++) {
				String temp=(char)i+"";
				A.add(temp);
			}
		}
		System.out.println(A.size());
		dfs(A);
	}
	
	static void dfs(ArrayList<String> A) {
		if(A.size()==1) {
			System.out.println(A.get(0));
			return;
		}
		ArrayList<String> box=new ArrayList<>();
		for(int i=0;i<A.size();i++) {
			if(i%2==1) {
				box.add(A.get(i));
			}
		}
		dfs(box);
	}
}
