package ���Զ�;

import java.util.Scanner;

/**
 * ��������
16 ?  ?  13
?  ?  11 ?
9  ?  ?  ?
?  15 ?  1
 * 
 * @author ��ħ
 *
 */
public class �÷���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String[][] A=new String[4][4];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				A[i][j]=scanner.next();
			}
		}
		scanner.close();
		dfs(0,0,A);
	}
	
	static void dfs(int x,int y,String[][] A) {
		if(y==4) {
			if(checkS(A)) {
				out(A);
			}
			return;
		}
		if(A[y][x].equals("?")) {
			for(int i=1;i<=16;i++) {
				if(check(A, i+"")) {
					A[y][x]=i+"";
					dfs((x+1)%4,y+(x+1)/4,A);
					A[y][x]="?";
				}
			}
		}else {
			dfs((x+1)%4,y+(x+1)/4,A);
		}
	}
	
	static boolean check(String[][] A,String k) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[0].length; j++) {
				if(A[i][j].equals(k))return false;
			}
		}
		return true;
	}
	
	
	static boolean checkS(String[][] S) {
		int[][] A=new int[S.length][S[0].length];
		for(int i=0;i<A.length;i++) {
			for(int j=0;j<A[0].length;j++) {
				A[i][j]=Integer.valueOf(S[i][j]);
			}
		}
		int sumTemp=0;
		for(int i=0;i<A[0].length;i++) {
			sumTemp+=A[0][i];
		}
		int a=0;		//�Խ���
		int b=0;
		for(int i=0;i<4;i++) {
			int k=0;		//ƽ����
			int l=0;
			for(int j=0;j<4;j++) {
				if(i+j==3) {
					a+=A[i][j];
				}
				if(i==j) {
					b+=A[i][j];
				}
				k+=A[i][j];
				l+=A[j][i];
			}
			if(sumTemp!=k || sumTemp!=l)return false;
			
		}
		if(sumTemp!=a || sumTemp!=b)return false;
		return true;
	}
	
	static void out(String[][] A) {
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A[0].length; j++) {
				System.out.print(A[i][j]+" ");
			}
			System.out.println();
			
		}
	}
}
