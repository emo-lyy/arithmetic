package ������;

public class Test {
	public static void main(String[] args) {
		String s="ababa";
		int index=s.indexOf("aba");
		String k=s.substring(index+1,s.length());
		System.out.println(index);
		System.out.println(k.indexOf("aba"));
	}
}
