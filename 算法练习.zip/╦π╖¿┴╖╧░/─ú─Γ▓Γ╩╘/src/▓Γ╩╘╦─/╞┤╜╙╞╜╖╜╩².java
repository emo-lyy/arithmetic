package ������;

import java.util.Scanner;

public class ƴ��ƽ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		scanner.close();
	p:	for(int i=n;i<=m;i++) {
			if(check(i)) {		
				//�����Լ���ƽ����
				String s=i+"";
				if(s.length()==1)continue p;
				int a1,b1,a2,b2;
				a1=Integer.valueOf(s.substring(0,1));
				b1=Integer.valueOf(s.substring(1,s.length()));
				a2=Integer.valueOf(s.substring(0,s.length()-1));
				b2=Integer.valueOf(s.substring(s.length()-1,s.length()));
				if((check(a1)&&check(b1)) || (check(a2)&&check(b2))) {
					System.out.println(i);
					continue p;
				}
			}
		}
	}
	
	static boolean check(int n) {
		if(n==0)return false;
		int k=(int)Math.sqrt(n);
		if(k*k==n)return true;
		else return false;
	}
}
