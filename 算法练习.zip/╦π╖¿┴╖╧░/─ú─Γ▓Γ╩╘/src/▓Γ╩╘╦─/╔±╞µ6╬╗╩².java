package ������;

import java.util.HashSet;
import java.util.Set;

public class ����6λ�� {
	public static void main(String[] args) {
		for(int i=100000;i<1000000;i++) {
			for(int j=2;j<=6;j++) {
				if(!checkLen(i*j))return;		//������ͷ���
			}
			if(checkNumber(i, i*2) && checkNumber(i, i*3) && checkNumber(i, i*4) && checkNumber(i, i*5) && checkNumber(i, i*6)) {
				System.out.println(i);
			}
		}
	}
	
	static boolean checkLen(int n) {
		if((n+"").length()==6)return true;
		return false;
	}
	
	static boolean checkNumber(int n,int m) {
		String[] A=(n+"").split("");
		String[] B=(m+"").split("");
		Set<String> set=new HashSet<>();
		for(int i=0;i<A.length;i++) {
			set.add(A[i]);
		}
		for (String s : set) {
			int a=0;
			int b=0;
			for(int i=0;i<A.length;i++) {
				if(s.equals(A[i]))a++;
				if(s.equals(B[i]))b++;
			}
			if(a!=b)return false;
		}
		return true;
	}
}
