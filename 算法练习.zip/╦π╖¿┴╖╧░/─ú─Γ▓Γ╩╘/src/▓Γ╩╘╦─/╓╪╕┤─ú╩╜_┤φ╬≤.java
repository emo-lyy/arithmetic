package ������;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class �ظ�ģʽ_���� {
	static int max=0;		//��ַ�����
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String[] A=scanner.next().split("");
		scanner.close();
		f(A);
		System.out.println(max);
	}
	static void f(String[] A) {
		Map<String, Integer> map=new HashMap<String, Integer>();
		for (String s : A) {
			if(map.keySet().contains(s)) {
				int k=map.get(s);
				map.put(s, k+1);
			}else {
				map.put(s, 1);
			}
		}
		
		for (String s : map.keySet()) {
			int k=map.get(s);
			max=max>k?max:k;
		}
	}
}
