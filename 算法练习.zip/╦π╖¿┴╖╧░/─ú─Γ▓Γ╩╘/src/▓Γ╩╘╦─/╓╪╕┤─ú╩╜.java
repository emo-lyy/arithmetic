package ������;

import java.util.Scanner;

public class �ظ�ģʽ {
	static int max=1;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		f(s);
		System.out.println(max);
	}
	static void f(String s) {
		int len=s.length();		//�ַ��ĳ���
		for(int i=len;i>=1;i--) {
			for(int j=0;j+i<len;j++) {
				String k=s.substring(j,i+j);
				if(check(k, s)) {
					max=max>i?max:i;
				}
			}
		}
	}
	
	/**
	 * ����Ҫ��������
	 * @param k	Ҫƥ����ַ�
	 * @param s	���ַ�
	 * @return
	 */
	static boolean check(String k,String s) {
		int index=s.indexOf(k);
		String a="";
		if(index+1<s.length()) {
			a=s.substring(index+1,s.length());
		}	
		if(a.contains(k))return true;
		else return false;
	}
}
