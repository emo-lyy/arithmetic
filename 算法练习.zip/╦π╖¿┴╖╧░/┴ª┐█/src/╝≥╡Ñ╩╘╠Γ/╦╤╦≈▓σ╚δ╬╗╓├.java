package ������;

public class ��������λ�� {
	public static void main(String[] args) {
		int[] nums= {1,3,5,6};
		int n=0;
		int res=searchInsert(nums,n);
		System.out.println(res);
	}
	public static int searchInsert(int[] nums, int target) {
        int index=nums.length;
        for(int i=0;i<nums.length;i++){
           if(nums[i]>=target) {index=i;break;}
        }
        return index;
    }
}
