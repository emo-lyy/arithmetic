package ������;

import java.util.Scanner;

/**
 * ��������ʱ�䳬ʱ����
 * @author ��ħ
 *
 */
public class ǰ׺��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n+1];
		for(int i=1;i<=n;i++)data[i]=scanner.nextInt();
		int m=scanner.nextInt();
		int[] begin=new int[m];
		int[] end=new int[m];
		for(int i=0;i<m;i++) {
			begin[i]=scanner.nextInt();
			end[i]=scanner.nextInt();
		}
		scanner.close();
		int[] res=f(data,begin,end);
		for (int i : res) {
			System.out.println(i);
		}
	}
	
	public static int[] f(int[] data,int[] begin,int[] end) {
		int[] res=new int[begin.length];
		for(int i=0;i<begin.length;i++) {
			int l=begin[i];
			int r=end[i];
			int k=0;
			for(int j=l;j<=r;j++) {
				k^=data[j];
			}
			res[i]=k;
		}
		return res;
	}
}
