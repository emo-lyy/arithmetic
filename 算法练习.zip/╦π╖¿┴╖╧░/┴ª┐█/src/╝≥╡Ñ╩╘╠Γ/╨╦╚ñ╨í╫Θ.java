package ������;

import java.util.Scanner;

public class ��ȤС�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		int ab=scanner.nextInt();
		scanner.close();
		System.out.println(n-(a+b-ab));
	}
}
