package ������;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ���ϲ��� {
	public static ArrayList<Integer> list=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		//System.out.println(n);
		int[] p=new int[n];
		int[] k=new int[n];
		for(int i=0;i<n;i++) {
			p[i]=scanner.nextInt();
			k[i]=scanner.nextInt();
		}
		scanner.close();
		for(int i=0;i<n;i++) {
			f(p[i],k[i]);
		}
	}
	public static void f(int x,int n) {
		Collections.sort(list);
		if(x==1) {
			list.add(n);
			return;
		}
		
		else if(2==x) {
			for(int j=0;j<list.size();j++) {
				if(list.get(j)==n) {
					list.remove(j);
					System.out.println("delete");
					return;
				}
			}
			System.out.println("none");
		}
		
		else if(x==3) {
			if(list.size()==0) {
				System.out.println("empty");
				return;
			}
			for(Integer temp : list) {
				if(temp>=n) {
					System.out.println(temp);
					return;
				}
			}
			System.out.println("null");
			
		}
	}
}
