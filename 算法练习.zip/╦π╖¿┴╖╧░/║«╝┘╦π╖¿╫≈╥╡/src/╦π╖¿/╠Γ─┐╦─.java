package �㷨;

import java.util.Scanner;

public class ��Ŀ�� {
	public static void main(String[] args) {
		test();
	} 
	
	public static void test() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("�����������ֵ:");
		int number=scanner.nextInt();
		scanner.close();
		
		//������һ��ֵ  �� n==i ʱ
		System.out.print(number+"=");
		System.out.print(digui(number));
	}
	
	public static int digui(int n) {
		for(int i=2;i<n;i++) {
			if(n%i==0) {
				System.out.print(i+"*");
				return digui(n/i);
				
			}
		}
		return n;
	}
}
