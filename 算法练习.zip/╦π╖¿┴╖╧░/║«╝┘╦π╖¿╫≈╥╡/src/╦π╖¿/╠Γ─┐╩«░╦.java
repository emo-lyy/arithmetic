package �㷨;

public class ��Ŀʮ�� {
	public static void main(String[] args) {
		test();
	}
	
	/**
	   * �� i�� 0,1,2 �ֱ���� a,b,c
	   *�� j�� 0,1,2�ֱ���� x,y,z 
	 */
	public static void test() {
		String[] box_1= {"a","b","c"};
		String[] box_2= {"x","y","z"};
		
		for(int n=0;n<3;n++) {
			for(int m=0;m<3;m++) {
//				System.out.print(n+" "+m+"     ");
				if(n==0) {
					if(m!=0) {
						System.out.println(box_1[n]+"��ս"+box_2[m]);
					}
				}
				else {
					if(m==2) {
						if(m!=0&&m!=2) {
							System.out.println(box_1[n]+"��ս"+box_2[m]);
						}
					}
					else {
						System.out.println(box_1[n]+"��ս"+box_2[m]);
					}
				}
			}
//			System.out.println();
		}
	}
}
