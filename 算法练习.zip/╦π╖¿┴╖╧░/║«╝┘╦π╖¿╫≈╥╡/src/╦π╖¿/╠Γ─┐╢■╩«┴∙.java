package �㷨;

import java.util.Scanner;

public class ��Ŀ��ʮ�� {
	private final String Monday="Monday";
	private final String Tuesday="Tuesday";
	private final String Wednesday="Wednesday";
	private final String Thursday="Thursday";
	private final String Friday="Friday";
	private final String Saturday ="Saturday";
	private final String Sunday="Sunday";
	
	
	public static void main(String[] args) {
		test();
	}
	
	public static void test() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("��������Ҫ��ѯ���ڵ�����ĸ 1~2����ĸ:");
		char[] strChar=scanner.next().toCharArray();
		scanner.close();
		System.out.println("����ҵ���"+If(strChar));
		
	}
	
	public static String If(char[] week) {
		��Ŀ��ʮ�� t=new ��Ŀ��ʮ��();
		String box=null;
		if(week[0]=='M'||week[0]=='m') {
			box=t.Monday;					
		}
		else if(week[0]=='T'||week[0]=='t') {
		   try {
			   if(week[1]=='U'||week[1]=='u') {
					box=t.Tuesday;
				}
				else {
					box=t.Thursday;
				}
		} catch (Exception e) {
			box=t.Thursday+"  "+t.Tuesday;
		}
		   
		   
		}
		else if(week[0]=='W'||week[0]=='w') {
			box=t.Wednesday;
		}
		else if(week[0]=='F'||week[0]=='f') {
			box=t.Friday;
		}
		else if(week[0]=='S'||week[0]=='s') {
			try {
				if(week[1]=='A'||week[1]=='a') {
					box=t.Saturday;
				}
				else {
					box=t.Sunday;
				}
			} catch (Exception e) {
				box=t.Saturday+"  "+t.Sunday;
			}
		}
		else {
			box=null;
			System.out.println("��������");
		}
		return box;
	}
}
