package �㷨;

public class ��Ŀ��ʮ�� {
	public static void main(String[] args) {
		test();
	}
	
	public static void test() {
		for(int i=1;i<=5;i++) {
			System.out.println("��"+i+"λ������Ϊ:"+digui(i));
		}
	}
	
	public static int digui(int n) {
		if(n==1) {
			return 10;
		}
		else {
			return digui(n-1)+2;
		}
	}
	
}
