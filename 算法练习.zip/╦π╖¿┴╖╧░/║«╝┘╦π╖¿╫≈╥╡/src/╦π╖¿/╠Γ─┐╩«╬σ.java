package �㷨;

import java.util.Scanner;

public class ��Ŀʮ�� {
	public static void main(String[] args) {
		test();
	}
	
	public static void test() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("������ X,Y,Z ��ֵ  �Զ��ŷָ�:");
		String[]  numericalValue=scanner.next().split(",");
		int data[] =new int[numericalValue.length];
		scanner.close();
		for (int i = 0; i < data.length; i++) {
			data[i]=Integer.parseInt(numericalValue[i]);
		}
		sort(data);
		for (int i : data) {
			System.out.print(i+"  ");
		}
	}
	
	
	/**
	 * ð������
	 * @param data
	 * @return
	 */
	public static int[] sort(int[] data) {
		for (int i = 0; i < data.length-1; i++) {
			for (int j = 0; j < data.length-i-1; j++) {
				if(data[j]>data[j+1]) {
					int temp=data[j];
					data[j]=data[j+1];
					data[j+1]=temp;
				}
				
			}
			
		}
		return data;
	}
}
