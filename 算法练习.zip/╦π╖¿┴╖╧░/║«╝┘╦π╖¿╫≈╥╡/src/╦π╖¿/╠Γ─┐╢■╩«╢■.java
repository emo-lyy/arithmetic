package �㷨;

import java.util.Scanner;

public class ��Ŀ��ʮ�� {
	public static void main(String[] args) {
		test();
	}
	
	public static void test() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("��������Ҫʵ����λ���Ľ׳�:");
		int n=scanner.nextInt();
		scanner.close();
		System.out.print(n+"!=");
		int box=digui(n);
		System.out.print("="+box);
	}
	
	public static Integer digui(int n) {
		if(n==1) {
			System.out.print("1");
			return 1;
		}
		else {
			System.out.print(n+"*");
			return n*digui(n-1);
		}
	}
}
