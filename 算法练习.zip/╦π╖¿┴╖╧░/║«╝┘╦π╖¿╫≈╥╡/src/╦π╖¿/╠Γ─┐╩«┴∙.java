package �㷨;

public class ��Ŀʮ�� {
	public static void main(String[] args) {
		test();
	}
	
	public static void test() {
		for(int i=1;i<10;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(j+"*"+i+"="+i*j+"  ");
			}
			System.out.println();
		}
	}
}
