package �㷨;

import java.util.Scanner;

public class ��Ŀʮ�� {
	public static void main(String[] args) {
		test();
	}
	
	public static void test() {
		Scanner scanner=new Scanner(System.in);
		System.out.print("�����뵱������:");
		int profit=scanner.nextInt();
		scanner.close();
		System.out.println("�����뷢����Ϊ:"+bonus(profit)+"��Ԫ");
	}
	
	public static double bonus(int profit) {
		if(0<=profit&&profit<=10) {
			return profit*0.1;
		}
		else if(10<profit&&profit<20) {
			return 10*0.1+(profit-10)*0.075;
		}
		else if(20<=profit&&profit<40) {
			return (profit-20)*0.05+10*0.1+10*0.075;
		}
		else if(40<=profit&&profit<60) {
			return (profit-40)*0.03+10*0.1+10*0.075+20*0.05;
		}
		else if(60<=profit&&profit<100) {
			return (profit-60)*0.015+10*0.1+10*0.075+20*0.05+20*0.03;
		}
		else {
			return (profit-100)*0.01+10*0.1+10*0.075+20*0.05+20*0.03+40*0.015;
		}
	}
}
