package �㷨;

import java.util.Scanner;

public class ��Ŀʮ�� {
	public static void main(String[] args) {
		test();
	}
	
	/**
	 * ��.���͡�|������ת���ַ�������ü�"\\"
	 */
	public static void test() {
		//�·�
		int month=0;
		Scanner scanner=new Scanner(System.in);
		System.out.print("���� '2019.07.09 ' �����ĸ�ʽ��������:");
		String data=scanner.next();
		scanner.close();
		String[] data_box=data.split("\\.");
		month=Integer.parseInt(data_box[1]);
		System.out.println("����"+data_box[0]+"��,�ĵ�"+days(month,Integer.parseInt(data_box[2]))+"��");
	}
	
	public static int days(int month,int data) {
		 int days=0;
		 switch(month) {
		 	case 01:
	 			days=data;
	 			break;
		 	case 02:
	 			days=31+data;
	 			break;
		 	case 03:
	 			days=31+28+data;
	 			break;
		 	case 04:
	 			days=31*2+28+data;
	 			break;
		 	case 05:
	 			days=31*2+28+30+data;
	 			break;
		 	case 06:
	 			days=31*3+28+30+data;
	 			break;
		 	case 07:
	 			days=31*3+28+30*2+data;
	 			break;
		 	case 8:
		 		days=31*4+28+30*2+data;
		 		break;
		 	case 9:
		 		days=31*5+28+30*2+data;
		 		break;
		 	case 10:
		 		days=31*5+28+30*3+data;
		 		break;
		 	case 11:
		 		days=31*6+28+30*3+data;
		 		break;
		 	case 12:
		 		days=31*6+28+30*4+data;
		 		break;
		 }
		return days;
		
	}
}
