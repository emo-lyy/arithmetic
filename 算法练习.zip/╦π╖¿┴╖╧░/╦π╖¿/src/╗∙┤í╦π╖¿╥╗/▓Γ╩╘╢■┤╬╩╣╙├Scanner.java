package �����㷨һ;

import java.util.Scanner;

public class ���Զ���ʹ��Scanner {
	public static void main(String[] args) {
		int a=a();
		int b=b();
		System.out.println(a+"  "+b);
	}
	
	public static int a() {
		int a=0;
		@SuppressWarnings("resource")  //���ƾ���
		Scanner scanner=new Scanner(System.in);
		a=scanner.nextInt();
		return a;
	}
	
	public static int b() {
		int b=0;
		Scanner scanner=new Scanner(System.in);
		b=scanner.nextInt();
		scanner.close();
		return b;
	}
}
