package ƽʱ��ҵ�㷨;

import java.math.BigInteger;


public class ������ {
	public static void main(String[] args) {
		Rati sum=new Rati(0);
		for(int i=1;i<=100;i++) {
			sum=sum.add(new Rati(1,i));
		}
		System.out.println(sum);
	}
	
	public static class Rati{
		private BigInteger zi=BigInteger.ZERO;
		private BigInteger mu=BigInteger.ONE;
		
		static BigInteger gcd(BigInteger a,BigInteger b) {
			if(b.equals(BigInteger.ZERO)) return a;
			return gcd(b,a.mod(b));
		}
		
		public Rati add(Rati it) {
			return new Rati(zi.multiply(it.mu).add(mu.multiply(it.zi)),mu.multiply(it.mu));
		}
		public Rati mul(Rati it) {
			return new Rati(zi.multiply(it.zi),mu.multiply(it.mu));
		}
		
		public Rati(long x) {
			this(BigInteger.valueOf(x),BigInteger.ONE);
		}
		public Rati(long x,long y) {
			this(BigInteger.valueOf(x),BigInteger.valueOf(y));
		}
		public Rati(BigInteger x,BigInteger y) {
			zi=x;
			mu=y;
			BigInteger g=gcd(zi,mu);
			zi=zi.divide(g);
			mu=mu.divide(g);
		}
		
		public String toString() {
			String s=zi.toString();
			if(mu.equals(BigInteger.ONE)==false)s+="/"+mu;
			return s;
		}
	}
}
