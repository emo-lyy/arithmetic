package ƽʱ��ҵ�㷨;

public class ��ķ�� {
	public static void main(String[] args) {
		int[] data= {3,4,5};
		boolean res=check(data);
		System.out.println(res);
	}
	public static boolean check(int[] data) {
		int n=0;
		for (int i : data) {
			n^=i;
		}
		return n!=0;
	}
}
