package ƽʱ��ҵ�㷨;

import java.math.BigInteger;
import java.util.Scanner;

public class ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		long begin=System.currentTimeMillis();
		f(n);
		long end1=System.currentTimeMillis();
		System.out.println("--------------");
		long begin2=System.currentTimeMillis();
		f2(n);
		long end2=System.currentTimeMillis();
		System.out.println("--------------");
		System.out.println(end1-begin);
		System.out.println(end2-begin2);
	}
	
	public static void f(int n) {
		int count=0;
		int k=2;
		while(count<n) {
			if(check(k)) {
				count++;
			}
			k++;
		}
		System.out.println(k-1);
	}
	
	public static boolean check(int n) {
		for(int i=2;i<=Math.sqrt(n);i++) {
			if(n%i==0)return false;
		}
		return true;
	}
	
	public static void f2(int n) {
		BigInteger b=new BigInteger("2");
		for(int i=2;i<=n;i++) {
			b=b.nextProbablePrime();
		}
		System.out.println(b);
	}
}
