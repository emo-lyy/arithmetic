package ƽʱ��ҵ�㷨;

import java.math.BigInteger;

public class �������� {
	public static void main(String[] args) {
		BigInteger mu=BigInteger.ONE;
		for(int i=2;i<=100;i++) {
			mu=mu.multiply(BigInteger.valueOf(i));
		}
		//System.out.println(mu);
		BigInteger zi=BigInteger.ZERO;
		for(int i=1;i<=100;i++) {
			zi=zi.add(mu.divide(BigInteger.valueOf(i)));
		}
		//System.out.println(zi);
		BigInteger k=gcd(mu,zi);
		System.out.println(zi.divide(k)+"/"+mu.divide(k));
	}
	public static BigInteger gcd(BigInteger a,BigInteger b) {
		if(b.equals(BigInteger.ZERO))return a;
		return gcd(b,a.mod(b));
	}
}
