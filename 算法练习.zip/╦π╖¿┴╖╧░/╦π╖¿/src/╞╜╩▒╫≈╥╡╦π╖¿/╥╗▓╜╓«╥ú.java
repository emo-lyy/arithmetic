package ƽʱ��ҵ�㷨;

public class һ��֮ң {
	private static int count=0; 
	public static void main(String[] args) {
		f1();
		f2(-1);
	}
	
	public static void f1() {
		for(int i=1;i<10000;i++) {
			for(int j=1;j<10000;j++) {
				if(i*97-j*127==1) {
					System.out.println(i+j);
					return;
				}
			}
		}
	}
	
	public static void f2(long n) {
		if(n==0) {
			System.out.println(count);
			return;
		}
		count++;
		if(n>0) {
			f2(n-127);
		}
		if(n<0) {
			f2(n+97);
		}
	}
}
