package ƽʱ��ҵ�㷨;

public class ��ֵľ��� {
	public static void main(String[] args) {
		  String str = Integer.toString(1000000, 7);
		//  System.out.println(str);
	        int sum = 0;
	        for(int i = 0; i < str.length(); i ++) {
	            sum += (str.charAt(i) - '0');
	        }
	        System.out.println(sum);
	}
}
