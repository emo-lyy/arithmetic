package ��ϰһ;

import java.util.ArrayList;
import java.util.Scanner;

public class ���г�ͣ�� {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int m = in.nextInt();
		for(int i=0;i<n-1;i++){
			int x = in.nextInt();
			int y = in.nextInt();
			int z = in.nextInt();
			int i1 = list.indexOf(y);
			if(i==0) {
				list.add(y);		//����λ�ĵ�һλ���ֲ����ȥ
			}
			if(z==0){
				if(i1==-1){
					//�����ڸ�ֵ
					list.add(x);
				} else {
					list.add(i1,x);
				}
			} else {
				if(i1==-1){
					list.add(x);
				} else {
					list.add(i1+1,x);
				}
			}
		}
		in.close();
		for(int i=0;i<list.size();i++){
			System.out.print(list.get(i)+" ");
		}
	}
	
	
	
	/**
	 * ��������
	 *  public static class TreeNode{
        int left;
        int right;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        TreeNode [] node = new TreeNode[100000+2];
        int k = sc.nextInt();
        for (int i = 0; i <= 100001; i++) {
            node[i]=new TreeNode();
            node[i].left = -1;
            node[i].right = -1;
        }
        node[k].left = 0;
        node[k].right = 100001;
        node[0].right = k;
        node[n + 1].left = k;
        for (int i = 0; i <n-1; i++) {
            int x=sc.nextInt();
            int y = sc.nextInt();
            int z = sc.nextInt();

            if (z == 0) {
                node[x].left = node[y].left;
                node[x].right = y;
                node[node[y].left].right = x;
                node[y].left = x;
            } else {

                node[x].right = node[y].right;
                node[x].left = y;
                node[node[y].right].left = x;
                node[y].right = x;
            }
        }
        int index=0;
        for (;;) {
            if(node[index].right==100001) break;
            System.out.print (node[index].right+" ");
            index=node[index].right;
        }
    }
	 */
}
