package ��ϰһ;

import java.util.Scanner;

public class ���� {
	static int k,n;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		k=scanner.nextInt();
		n=scanner.nextInt();
		scanner.close();
		String s=Integer.toString(n, 2);
		int res=0;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='1') {
				res+=Math.pow(k, s.length()-1-i);
			}
		}
		System.out.println(res);
	}
}
