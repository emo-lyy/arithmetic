package �������Զ�;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ��ѡ���� {
	public static ArrayList<ArrayList<Integer>> box=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int sum=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		dfs(data,sum,0,new ArrayList<Integer>());
		ArrayList<Integer> temp=box.get(box.size()-1);
		Collections.sort(temp);;
		for(int i=0;i<temp.size();i++) {
			if(i!=temp.size()-1) {
				System.out.print(temp.get(i)+" ");
			}
			else {
				System.out.print(temp.get(i));
			}
		}
	}
	
	public static void dfs(int[] data,int k,int cur,ArrayList<Integer> ints) {
		//����
		if(k==0) {
			//���ﲻ����д ���ܸ�ֵ
			ArrayList<Integer> temp=new ArrayList<>();
			for(Integer i : ints) {
				temp.add(i);
			}
			box.add(temp);
			//System.out.println(ints);
			//System.exit(0);
		}
		if(k<0 || cur==data.length) {
			return;
		}
		
		//��һ��״̬����Ҫ data[cur]��
		dfs(data,k,cur+1,ints);
		
		//�ڶ���ת̬,��Ҫ data[cur]��
		ints.add(data[cur]);
		int index=ints.size()-1;
		dfs(data,k-data[cur],cur+1,ints);
		ints.remove(index);  //�����·���У��򷵻���һ��
		
	}
}
