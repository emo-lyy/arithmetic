package �������Զ�;

import java.util.Scanner;

public class K�ַ���A����B {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int k=scanner.nextInt();
		scanner.close();
		String data="A";
		int count=1;
		while(count<n) {
			String[] temp=data.split("");
			StringBuffer sb=new StringBuffer();
			for(int i=0;i<temp.length;i++) {
				if(temp[i].equals("A")) {
					temp[i]="AB";
				}
				else {
					temp[i]="BA";
				}
				//System.out.print(temp[i]);
				sb.append(temp[i]);
			}
			data=sb.toString();
			//System.out.println(data);
			count++;
		}
		System.out.println(data.charAt(k-1));
	}
}	
