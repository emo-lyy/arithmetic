package �������Զ�;

import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		int count=0;
		for(int a=0;a<n;a++) {
			for(int b=a+1;b<n;b++) {
				for(int c=b+1;c<n;c++) {
					int A=data[a];
					int B=data[b];
					int C=data[c];
					if(A+B>C && B+C>A && A+C>B) {
						count++;
					}
				}
			}
		}
		System.out.println(count);
	}
}
