package �������Զ�;

import java.util.Scanner;

public class ���һ��ȴ� {
	public static void main(String[] args) {
		/*String test="abcde";
		System.out.println(test.substring(1, 1+2));*/
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		int max=0;
		int len=str.length();
		for(int i=0;i<len;i++) {
			if(i<=len-2) {
				int temp1=i;	//���浱ǰ�״����������ڼ������ĳ���
				int temp2=i;
				String box1=str.substring(i, i+2);
				//System.out.println(box1);
				if(box1.equals("01")) {
					temp2+=2;
					while(temp2<len-2) {
						String box2=str.substring(temp2,temp2+2);
						if(!box2.equals("01")) {
							break;
						}
						else {
							temp2+=2;
						}
					}
				}
				int len2=temp2-temp1;
				max=(max>len2)?max:len2;
			}	
		}
		System.out.println(max);
	}
}
