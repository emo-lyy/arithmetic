package �������Զ�;

import java.util.ArrayList;
import java.util.Scanner;

public class ���������� {
	public static void main(String[] args) {
		//check("10");
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		System.out.println(f2(n));
		System.out.println("---------------------");
		IfN(n);
	}
	//�ݹ鷽��
	public static long f1(int n) {
		if(n==1) return 2;
		if(n==2) return 4;
		return (f1(n-1)+f1(n-2))%100000007;
	}
	
	//��������
	public static long f2(int n) {
		int count=0;
		if(n==1) count=2;
		else if(n==2) count=4;
		else {
			int index=3;
			int a=2;
			int b=4;
			while(index<=n) {
				count=(a+b)%1000000007;
				int temp=b;
				b=count;
				a=temp;
				index++;
			}
		}
		return count;
	}
	
	
	public static void IfN(int n) {
		if(n==1) {
			System.out.println(2);
		}
		
		else if(n==2) {
			System.out.println(4);
		}
		else {
			ArrayList<String> box=new ArrayList<>();
			box.add("11");
			box.add("00");
			box.add("10");
			box.add("01");
			f3(n,3,box);
		}
	}
	//���ɷ�
	public static void f3(int n,int count,ArrayList<String> box) {
		if(count>n) {
			System.out.println(box.size());
			return;
		}
		ArrayList<String> temp=new ArrayList<>();
		for(String s : box) {
			String temp1=s+"0";
			String temp2=s+"1";
			if(check(temp1)) {
				temp.add(temp1);
			}
			if(check(temp2)) {
				temp.add(temp2);
			}
		}
		f3(n,count+1,temp);
	} 
	
	
	public static boolean check(String str) {
		String temp=str.substring(str.length()-3, str.length());
		//System.out.println(temp);
		if(temp.equals("000") || temp.equals("111")) {
			return false;
		}
		return true;
	}
	
}
