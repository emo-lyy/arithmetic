package �������Զ�;

import java.util.Scanner;

public class ��ǰ�������кܶ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		char[][] data=new char[n][m];
		for(int i=0;i<n;i++) {
			data[i]=scanner.next().toCharArray();
		}
		scanner.close();
		
		int count=0;
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				//System.out.print(data[i][j]);
				if(data[i][j]=='W') {
					dfs(data,i,j,n,m);
					count++;
				}
			}
			//System.out.println();
		}
		System.out.println(count);
	}
	
	//���Ĵ���
	public static void dfs(char[][] data,int i,int j,int n,int m) {
		data[i][j]='.';
		for(int k=-1;k<2;k++) {
			for(int l=-1;l<2;l++) {
				if(k==0&&l==0)continue;
				if(i+k>=0 && j+l>=0 && i+k<=n-1 && j+l<=m-1) {
					if(data[i+k][j+l]=='W') {
						dfs(data,i+k,j+l,n,m);
					}
				}
			}
		}
	}
}
