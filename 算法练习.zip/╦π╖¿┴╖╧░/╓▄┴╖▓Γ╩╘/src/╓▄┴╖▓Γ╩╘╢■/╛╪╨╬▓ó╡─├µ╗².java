package �������Զ�;

import java.util.Scanner;

public class ���β������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int[] X=new int[4];
		int[] Y=new int[4];
		for(int i=0;i<4;i++) {
			X[i]=scanner.nextInt();
			Y[i]=scanner.nextInt();
		}
		scanner.close();
		int count=0;
		
		//��ȡ�����x����
		int minX=0;
		int maxX=0;
		for(int a=X[0];a<=X[1];a++) {
			for(int b=X[2];b<=X[3];b++) {
				if(a==b) {
					if(count==0) {
						minX=a;
						count++;
					}
					else {
						maxX=a;
					}
				}
			}			
		}
		//System.out.println(minX+" "+maxX);
		
		//��ȡ�����y����
		count=0;
		int minY=0;
		int maxY=0;
		for(int a=Y[0];a<=Y[1];a++) {
			for(int b=Y[2];b<=Y[3];b++) {
				if(a==b) {
					if(count==0) {
						minY=a;
						count++;
					}
					else {
						maxY=a;
					}
				}
			}			
		}
		//System.out.println(minY+" "+maxY);
		
		//��������
		int w1=f(maxX-minX);
		int h1=f(maxY-minY);
		int s1=w1*h1;
		
		//ԭ�ȵ����֮��
		int w2=f(X[1]-X[0]);
		int h2=f(Y[1]-Y[0]);
		int s2=w2*h2;
		
		int w3=f(X[3]-X[2]);
		int h3=f(Y[3]-Y[2]);
		int s3=w3*h3;
		
		int s=s2+s3-s1;
		System.out.println(s);
	}
	
	public static int f(int n) {
		if(n<0) {
			return -n;
		}
		else {
			return n;
		}
	}
}
