package �������Զ�;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * ��Ҫ�Ż�
 * @author ��ħ
 *
 */
public class ����֮�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		int index=0;
		int count=0;
		while(index<str.length()){
			if(str.charAt(index)=='(') {count++;}
			index++;
		}
		/*for(int i=1;i<=50;i++) {
			Map<String,Integer> temp=dfs(i);
			Set<String> S=temp.keySet();
			for (String s : S) {
				if(s.equals(str)) {
					System.out.println(temp.get(s));
					return;
				}
			}
		}*/
		
		Map<String,Integer> temp=dfs(count);
		Set<String> S=temp.keySet();
		for (String s : S) {
			if(s.equals(str)) {
				System.out.println(temp.get(s));
				return;
			}
		}
		
	}
	
	public static Map<String, Integer> dfs(int n){
		Map<String,Integer> res=new HashMap<String, Integer>();
		res.put("()", 1);
		if(n==1) {return res;}
		for(int i=2;i<=n;i++) {
			Map<String, Integer> temp=new HashMap<>();
			Set<String> S=res.keySet();
			for (String s : S) {
				int box=res.get(s);
				temp.put("("+s+")", box*2);
				temp.put("()"+s, box+1);
				temp.put(s+"()", box+1);
			}
			res=temp;
		}
		return res;
	}
}
