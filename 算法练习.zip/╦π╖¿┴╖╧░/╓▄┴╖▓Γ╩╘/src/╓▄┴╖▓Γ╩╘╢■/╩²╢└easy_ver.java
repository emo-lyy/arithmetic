package �������Զ�;

import java.util.Scanner;

public class ����easy_ver {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[][] data=new char[9][9];
		for(int i=0;i<9;i++) {
			for(int j=0;j<9;j++) {
				data[i][j]=scanner.next().charAt(0);
			}
		}
		scanner.close();
		dfs(data,0,0);
		//System.out.println(data[8][8]);   //���������Ƿ񱣴�ɹ�
	}
	
	public static void dfs(char[][] arr,int x,int y) {
		if(x==9) {
			outArr(arr);
			System.exit(0);
		}
		if(arr[x][y]=='0') {
			for(int i=1;i<10;i++) {
				if(check(arr,x,y,i)) {
					arr[x][y]=(char)(i+'0');
					dfs(arr,x+(y+1)/9,(y+1)%9);
				}
			}
			
			arr[x][y]='0';  //����
		}
		else {
			dfs(arr,x+(y+1)/9,(y+1)%9);
		}
	}
	
	public static boolean check(char[][] arr,int x,int y,int k) {
		boolean res=true;
		
		//���ͬ��ͬ��
		for(int i=0;i<9;i++) {
			if(arr[x][i]==(char)('0'+k)) {
				return false;
			}
			if(arr[i][y]==(char)('0'+k)) {
				return false;
			}
		}
		
		//���С�Ź���
		for(int l=(x/3)*3;l<(x/3+1)*3;l++) {
			for(int m=(y/3)*3;m<(y/3+1)*3;m++) {
				if(arr[l][m]==(char)('0'+k)) {
					res=false;
					break;
				}
			}
		}
		
		return res;
	}
	
	public static void outArr(char[][] data) {
		for(int i=0;i<9;i++) {
			for(int j=0;j<9;j++) {
				System.out.print(data[i][j]+" ");
			}
			System.out.println();
		}
	}
}
