package �������Զ�;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class ��Ϊk�ı��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		int k=scanner.nextInt();
		scanner.close();
		Set<Set<Integer>> temp=getSubsets3(data,n);
		int count=0;
		for (Set<Integer> set : temp) {
			//System.out.println(set);
			int sum=0;
			for (Integer i : set) {
				sum+=i;
			}
			if(sum%k==0 && sum>=k) {
				System.out.println(set);
				count++;
			}
		}
		System.out.println(count);
	}
	
	public static Set<Set<Integer>> getSubsets3(int[] A,int n){
		return getSubsets3Core(A,n,n-1);
	}
	
	public static Set<Set<Integer>> getSubsets3Core(int[] A,int n,int cur){
		Set<Set<Integer>> newSet=new HashSet<>();
		if(cur==0) {
			Set<Integer> nil=new HashSet<>();
			Set<Integer> first=new HashSet<>();
			first.add(A[0]);
			newSet.add(nil);
			newSet.add(first);
			return newSet;
		}
		Set<Set<Integer>> oldSet=getSubsets3Core(A,n,cur-1);
		for (Set<Integer> set : oldSet) {
			newSet.add(set);
			@SuppressWarnings("unchecked")
			Set<Integer> clone=(Set<Integer>)((HashSet<Integer>)set).clone();
			clone.add(A[cur]);
			newSet.add(clone);
		}
		return newSet;
	}
}
