package �������Զ�;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * ����ʱ�����
 * @author ��ħ
 *
 */
public class ƴ����С���� {
	private static ArrayList<String> list=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String[] data=new String[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.next();
		}
		scanner.close();
		
		dfs(data,0);
		
		//int sum=0;
		long min=Long.valueOf(list.get(0));
		for (String s : list) {
			long temp=Long.valueOf(s);
			min=(min<temp)?min:temp;
			//System.out.println(s);
			//sum++;
		}
		System.out.println(min);
		//System.out.println("�ܹ���:"+sum);
	}
	
	
	//���Ĵ���
	public static void dfs(String[] data,int k) {
		if(k==data.length) {
			StringBuffer res=new StringBuffer();;
			for (String s : data) {
				res.append(s);
			}
			list.add(res.toString());
		}
		
		
		for(int i=k;i<data.length;i++) {
			swap(data,k,i);
			dfs(data,k+1);
			swap(data,k,i);
		}
	}
	
	public static void swap(String[] data,int i,int j) {
		String temp=data[i];
		data[i]=data[j];
		data[j]=temp;
	}
}
