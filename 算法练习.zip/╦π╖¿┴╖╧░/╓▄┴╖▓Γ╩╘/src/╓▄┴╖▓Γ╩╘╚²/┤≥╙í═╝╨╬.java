package ����������;

import java.util.ArrayList;
import java.util.Scanner;

public class ��ӡͼ�� {
	private static ArrayList<String> character=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		for(int i=(int)('A'); i<=(int)('Z');i++ ) {
			char temp=(char)i;
			character.add(String.valueOf(temp));
		}
		
		//System.out.println(character);
		
		int l=0;
		for(int i=0;i<character.size();i++) {
			if(s.equals(character.get(i))) {
				l=i;
				break;
			}
		}
		//System.out.println(l);
		
		int len=l*2+1;
		int index=l;
		int temp=index;
		
		while(len!=-1) {
			StringBuffer sb=new StringBuffer();
			for(int i=0;i<len;i++) {
				if(index<0) {
					for(int j=0;j<temp;j++) {
						index+=1;
						sb.append(character.get(index));
						i++;
					}
					temp--;
				}
				else {
					sb.append(character.get(index));
					index--;
				}
			}
			System.out.println(sb.toString());
			len=len-2;
		}
	}
}
