package ����������;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * ��������
 * @author ��ħ
 *
 */
public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.nextLine();
		String s=scanner.nextLine();
		scanner.close();
		//System.out.println(s);
		String[] temp=s.split("\\s+");
		Map<Integer, String> map=new HashMap<Integer, String>();
		ArrayList<Integer> box=new ArrayList<>();
		for(String S : temp) {
			map.put((int)S.charAt(0), S);
			box.add((int)S.charAt(0));
		}
		Collections.sort(box);
		for (Integer i : box) {
			System.out.print(map.get(i)+" ");
		}
	}
	
	/**
	 * ����ڶ����ַ����ֵ���ȵڶ����ֵ���� ����false
	 * @param str1  ��һ���ַ�
	 * @param str2 �ڶ����ַ�
	 * @return
	 */
	public static boolean check(String str1,String str2) {
		int len1=str1.length();
		int len2=str2.length();
		int len=(len1>len2)?len1:len2;
		char[] box1=new char[len];
		char[] box2=new char[len];
		for(int i=0;i<len1;i++) {
			box1[i]=str1.charAt(i);
		}
		for(int i=0;i<len2;i++) {
			box2[i]=str2.charAt(i);
		}
		
		for(int i=0;i<len;i++) {
			int a=(int)box1[i];
			int b=(int)box2[i];
			if(a>b)return false;
			if(a<b)return true;
		}
		
		
		return true;
	}
}
