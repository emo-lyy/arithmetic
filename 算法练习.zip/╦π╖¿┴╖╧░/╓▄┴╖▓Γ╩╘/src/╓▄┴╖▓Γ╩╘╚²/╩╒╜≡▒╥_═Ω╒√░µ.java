package ����������;

import java.util.Scanner;

public class �ս��_������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
			//System.out.print(data[i]);
		}
		scanner.close();
		f(data);
	}
	
	public static void f(int[] data) {
		int begin=0;
		int end=data.length-1;
		long beginSum=0;
		long endSum=0;
		int len=data.length;
		if(len%2==0) {
			while(end>=begin) {
				//System.out.println(begin+" "+end);
				if(beginSum>endSum) {
					endSum+=data[end];
					end--;
					//System.out.println(beginSum+" "+endSum+" "+1);
				}
				else if(beginSum<endSum) {
					//System.out.println("----------");
					beginSum+=data[begin];
					begin++;
					//System.out.println(beginSum+" "+endSum+" "+2);
				}
				else {
					endSum+=data[end];
					end--;
					beginSum+=data[begin];
					begin++;
					//System.out.println(beginSum+" "+endSum+" "+3);
				}
			}
		}
		else {
			while(end!=begin) {
				if(beginSum>endSum) {
					endSum+=data[end];
					end--;
					//System.out.println(beginSum+" "+endSum+" "+1);
				}
				else if(beginSum<endSum) {
					//System.out.println("----------");
					beginSum+=data[begin];
					begin++;
					//System.out.println(beginSum+" "+endSum+" "+2);
				}
				else {
					endSum+=data[end];
					end--;
					beginSum+=data[begin];
					begin++;
					//System.out.println(beginSum+" "+endSum+" "+3);
				}
				if(beginSum>endSum) {
					endSum+=data[(len-1)/2];
				}
				else {
					beginSum+=data[(len-1)/2];;
				}
			}
		}
		if(beginSum==endSum) {
			System.out.println("Yes");
		}
		else {
			//System.out.println(beginSum+" "+endSum);
			System.out.println("No");
		}
	}
}
