package ����������;

import java.util.Scanner;

public class ��ά����ת�� {
	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		int[][] data=new int[n][m];
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				data[i][j]=scanner.nextInt();
			}
		}
		scanner.close();
		
		System.out.println(m+" "+n);
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				System.out.print(data[j][i]+" ");
			}
			System.out.println();
		}
	}
}
