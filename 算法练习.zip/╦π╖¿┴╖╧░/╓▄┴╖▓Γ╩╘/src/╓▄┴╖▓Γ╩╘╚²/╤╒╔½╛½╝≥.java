package ����������;

import java.util.ArrayList;
import java.util.Scanner;

public class ��ɫ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		Color[] data=new Color[n];
		for(int i=0;i<n;i++) {
			data[i]=new Color(scanner.nextInt(),scanner.nextInt(),scanner.nextInt());
		}
		ArrayList<Color> temp=new ArrayList<>();
		while(true) {
			int r=scanner.nextInt();
			int g=scanner.nextInt();
			int b=scanner.nextInt();
			if(r==-1) break;
			else temp.add(new Color(r,g,b));
		}
		scanner.close();
		
		for(int i=0;i<temp.size();i++) {
			Color c1=data[0];
			Color c2=temp.get(i);
			//System.out.println("("+c2.getR()+","+c2.getG()+","+c2.getB()+")");
			int minLen=(c1.getR()-c2.getR())*(c1.getR()-c2.getR())+(c1.getG()-c2.getG())*(c1.getG()-c2.getG())+(c1.getB()-c2.getB())*(c1.getB()-c2.getB());
			for(int j=1;j<data.length;j++) {
				Color c3=data[j];
				int len=(c3.getR()-c2.getR())*(c3.getR()-c2.getR())+(c3.getG()-c2.getG())*(c3.getG()-c2.getG())+(c3.getB()-c2.getB())*(c3.getB()-c2.getB());
				if(len<minLen) {
					minLen=len;
					c1=c3;
				}
			}
			System.out.println("("+c1.getR()+","+c1.getG()+","+c1.getB()+")");
		}
	}
	
	
	//��ɫ������
	public static class Color{
		private int R;
		private int G;
		private int B;
		
		public Color() {}

		/**
		 * @return the r
		 */
		public int getR() {
			return R;
		}

		/**
		 * @param r the r to set
		 */
		public void setR(int r) {
			R = r;
		}

		/**
		 * @return the g
		 */
		public int getG() {
			return G;
		}

		/**
		 * @param g the g to set
		 */
		public void setG(int g) {
			G = g;
		}

		/**
		 * @return the b
		 */
		public int getB() {
			return B;
		}

		/**
		 * @param b the b to set
		 */
		public void setB(int b) {
			B = b;
		}

		public Color(int r, int g, int b) {
			super();
			R = r;
			G = g;
			B = b;
		};
		
	}
}
