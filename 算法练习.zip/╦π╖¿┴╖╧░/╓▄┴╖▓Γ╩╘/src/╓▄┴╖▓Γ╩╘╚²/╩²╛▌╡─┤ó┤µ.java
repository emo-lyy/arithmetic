package ����������;

import java.util.Scanner;

public class ���ݵĴ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String[] data=scanner.nextLine().split("");
		scanner.close();
		int count=0;
		for(int i=0;i<data.length;i++) {
			String temp=data[i];
			if(temp.equals("\"")) {
				if(count%2==0) {
					data[i]="``";
				}
				else {
					data[i]="''";
				}
				count++;
			}
		}
		for (String s : data) {
			System.out.print(s);
		}
	}
}
