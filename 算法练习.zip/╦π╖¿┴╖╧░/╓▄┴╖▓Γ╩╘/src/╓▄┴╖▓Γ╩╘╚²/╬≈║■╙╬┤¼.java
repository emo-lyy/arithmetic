package ����������;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class �����δ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		int w=scanner.nextInt();
		Map<Integer, Integer> map=new HashMap<Integer, Integer>();
		for(int i=1;i<=n;i++) {
			map.put(i, scanner.nextInt());
		}
		int[] index=new int[m];
		for(int i=0;i<m;i++) {
			index[i]=scanner.nextInt();
		}
		scanner.close();
		
		int maxG=0;
		int temp=0;
		ArrayList<Integer> box=new ArrayList<>();
		for(int i=0;i<m;i++) {
			int item=index[i];
			int g=map.get(item);
			if(box.contains(item)) {
				temp-=g;
				for(int j=-0;j<box.size();j++) {
					if(box.get(j)==item) {
						box.remove(j);
					}
				}
			}
			else {
				temp+=g;
				maxG=(maxG>temp)?maxG:temp;
				box.add(item);
			}
		}
		//System.out.println(maxG);
		if(maxG>w) {
			System.out.println("Oh, My God!");
		}
		else {
			System.out.println(maxG);
		}
	}
}
