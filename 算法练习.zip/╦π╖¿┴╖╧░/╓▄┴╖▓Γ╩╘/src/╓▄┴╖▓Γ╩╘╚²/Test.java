package ����������;

import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		for (int i = 0; i <n; i++) {
			long arr=sc.nextLong();
			long max=0;
			for (int j = 2; j <=Math.sqrt(arr); j++) {
				while (arr%j==0) {
					arr/=j;
					max=j;
				}
			}
			if (arr>max) {
			max=arr;	
			}
			System.out.println(max);
		}
	     
	   }
	}
