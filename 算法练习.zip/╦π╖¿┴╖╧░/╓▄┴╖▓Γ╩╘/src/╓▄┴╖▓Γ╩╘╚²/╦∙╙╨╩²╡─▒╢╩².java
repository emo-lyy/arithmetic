package ����������;

import java.util.Scanner;

/**
 * δд��
 * @author ��ħ
 *
 */
public class �������ı��� {
	public static void main(String[] args) {
		//System.out.println(T(22,12));
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		for (int i : data) {
			f(i);
		}
	}
	
	public static void f(int n) {
		if(n==1) {System.out.println(1);return;}
		if(n==2) {System.out.println(2);return;}
		if(n==3) {System.out.println(6);return;}
		long temp=2*3/T(3,2);
		for(int i=4;i<=n;i++) {
			long box=temp;
			temp=box*i/T(temp,i);
		}
		System.out.println(temp);
	}
	
	public static long T(long temp,long m) {
		if(m==0) return temp;
		return T(m,temp%m);
	}
	
}
