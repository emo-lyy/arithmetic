package ����������;

import java.util.Scanner;

public class ISBN�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		scanner.close();
		f(s);
	}
	
	public static void f(String s) {
		String[] temp=s.split("-");
		String[] box1=temp[0].split("");
		String[] box2=temp[1].split("");
		String[] box3=temp[2].split("");
		String[] box4=temp[3].split("");
		long sum=0;
		int count=1;
		for (String str : box1) {
			sum+=count*Integer.valueOf(str);
			count++;
		}
		for (String str : box2) {
			sum+=count*Integer.valueOf(str);
			count++;
		}
		for (String str : box3) {
			sum+=count*Integer.valueOf(str);
			count++;
		}
		for(int i=0;i<box4.length-1;i++) {
			String str=box4[i];
			sum+=count*Integer.valueOf(str);
			count++;
		}
		if(box4[box4.length-1].equals("X")) {
			box4[box4.length-1]="10";
		}
		sum=sum%11;
		if(sum==Integer.valueOf(box4[box4.length-1])) {
			System.out.println("Right");
		}
		else {
			String tempS=String.valueOf(sum);
			if(sum==10) {
				tempS="X";
			}
			String S=s.substring(0, s.length()-1);
			System.out.println(S+tempS);
		}
	}
	
}
