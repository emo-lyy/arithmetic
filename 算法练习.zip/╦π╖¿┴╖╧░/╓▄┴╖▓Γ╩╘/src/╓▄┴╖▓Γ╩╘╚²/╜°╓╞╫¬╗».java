package ����������;

import java.util.Scanner;

public class ����ת�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String n=scanner.next();
		int b=scanner.nextInt();
		scanner.close();
		String temp=Integer.toString(Integer.valueOf(n), b);
		System.out.println(temp);
	}
}
