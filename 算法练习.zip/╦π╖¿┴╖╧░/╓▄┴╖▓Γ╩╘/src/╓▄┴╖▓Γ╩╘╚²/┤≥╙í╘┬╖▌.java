package ����������;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

public class ��ӡ�·� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int year=scanner.nextInt();
		int month=scanner.nextInt();
		int day=scanner.nextInt();
		scanner.close();
		Calendar c=Calendar.getInstance();
		c.set(year, month,0);
		int a=c.get(Calendar.DAY_OF_MONTH);
		c.set(year, month-1, 1);
		int b=c.get(Calendar.DAY_OF_WEEK)-1;  //��ȡ���µĵ�һ�������ڼ�
		//System.out.println(a+" "+b);
		ArrayList<Integer> box=new ArrayList<>();
		for(int i=0;i<b;i++) {
			box.add(-1);
		}
		
		for(int i=1;i<=a;i++) {
			box.add(i);
		}
		
		System.out.println("S   M   T   W   T   F   S");
		//System.out.println(box);
		int index=0;
		while(index<42) {
			for(int i=index;i<index+7;i++) {
				if(i<box.size()) {
					int temp=box.get(i);
					if(temp==-1) {
						System.out.print("    ");
					}
					else {
						String s=temp+"";
						String out=(s.length()==1)?"   ":"  ";
						System.out.print(temp+out);
					}
				}
				else {
					break;
				}
			}
			index+=7;
			System.out.println();	
		}
	}
}
