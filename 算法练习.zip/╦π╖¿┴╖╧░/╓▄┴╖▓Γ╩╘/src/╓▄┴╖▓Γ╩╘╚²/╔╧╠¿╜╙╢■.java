package ����������;

import java.util.Scanner;

public class ��̨�Ӷ� {
	private static int mod=100003;
	private static int[] data=new int[100000+1];
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		data[1]=1;
		data[2]=1;
		data[3]=2;
		data[4]=3;
		data[5]=5;
		for(int i=6;i<=n;i++) {
			data[i]=(data[i-1]+data[i-3]+data[i-5])%mod;
		}
		System.out.println(data[n]);
	}
}
