package ����������;

import java.util.Scanner;

public class �˷� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String[] a=scanner.next().split("");
		String[] b=scanner.next().split("");
		String[] c=scanner.next().split("");
		scanner.close();
		int max=0;
		for (String s : a) {
			int temp=Integer.valueOf(s);
			max=(max>temp)?max:temp;
		}
		
		for (String s : b) {
			int temp=Integer.valueOf(s);
			max=(max>temp)?max:temp;
		}
		
		for (String s : c) {
			int temp=Integer.valueOf(s);
			max=(max>temp)?max:temp;
		}
		f(a,b,c,max+1);
	}
	
	public static void f(String[] a,String[] b,String[] c,int l) {
		for(int k=l;k<=16;k++) {
			int tempA=0;
			int tempB=0;
			int tempC=0;
			//k=13;
			for(int i=0;i<a.length;i++) {
				int temp=Integer.valueOf(a[i]);
				int sum=(int) Math.pow(k,a.length-1-i)*temp;
				tempA+=sum;
			}
			
			for(int i=0;i<b.length;i++) {
				int temp=Integer.valueOf(b[i]);
				int sum=(int) Math.pow(k,b.length-1-i)*temp;
				tempB+=sum;
			}
			
			for(int i=0;i<c.length;i++) {
				int temp=Integer.valueOf(c[i]);
				int sum=(int) Math.pow(k,c.length-1-i)*temp;
				tempC+=sum;
			}
			
			//System.out.println(tempA+"*"+tempB+"="+tempC);
			if(tempA*tempB==tempC) {
				System.out.println(k);
				return;
			}
		}
		System.out.println(0);
	}
}
