package ����������;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ���и�ԭ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();   //��δ�������ֵ����鳤��
		int m=scanner.nextInt(); 	//Ҫ�������ֵ����鳤��
		int[] box1=new int[n];
		ArrayList<Integer> interpositionKey=new ArrayList<Integer>();
		ArrayList<Integer> interpositionValue=new ArrayList<Integer>();
		Map<Integer, Integer> map=new HashMap<Integer, Integer>();
		for(int i=0;i<n;i++) {
			int value=scanner.nextInt();
			int key=scanner.nextInt();
			map.put(key, value);
		}
		for(int i=0;i<m;i++) {
			interpositionKey.add(scanner.nextInt());
			interpositionValue.add(scanner.nextInt());
		}
		scanner.close();
		
		/**
		 * �Ȱ�δ����ǰ�����鸴ԭ
		 */
		int index=n-1;
		int temp=0;
		while(index>=0) {
			box1[index]=map.get(temp);
			temp=map.get(temp);
			index--;
		}
		
		/*for (int i : box1) {
			System.out.print(i+" ");
		}*/
		
		
		ArrayList<Integer> box=new ArrayList<>();    //���ڱ���������������
		int count=1;
		while(count<=n+m) {
			for (int i : box1) {
				if(interpositionKey.contains(i)) {
					box.add(i);
					count+=1;
					for(int j=interpositionKey.size()-1;j>=0;j--) {
						if(interpositionKey.get(j)==i) {
							box.add(interpositionValue.get(j));
							count++;
						}
					}
				}
				else {
					box.add(i);
					count++;
				}
			}
		}
		//System.out.println(box);
		for (Integer i : box) {
			System.out.println(i);
		}
	}
}
