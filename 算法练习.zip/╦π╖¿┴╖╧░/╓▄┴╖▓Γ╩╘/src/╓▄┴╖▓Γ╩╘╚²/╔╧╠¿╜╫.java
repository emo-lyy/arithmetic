package ����������;

import java.util.Scanner;

public class ��̨�� {
	private static int mod=100003;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		System.out.println(f(n));
	}
	public static int f(int n) {
		if(n==1)return 1;
		if(n==2)return 1;
		if(n==3)return 2;
		if(n==4)return 3;
		if(n==5)return 5;
		return f(n-1)%mod+f(n-3)%mod+f(n-5)%mod;
	}
	
}
