package ����������;

import java.util.ArrayList;
import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] key=new int[n];
		int[] value=new int[n];
		for(int i=0;i<n;i++) {
			int temp=scanner.nextInt();
			if(temp==1) {
				value[i]=scanner.nextInt();
			}
			key[i]=temp;
		}
		scanner.close();
		
		ArrayList<Integer> box=new ArrayList<>();
		for(int i=0;i<n;i++) {
			int temp=key[i];
			if(temp==1) {
				box.add(value[i]);
			}
			else {
				if(box.size()==0) {
					System.out.println("empty");
				}
				else {
					System.out.println(box.get(0));
					box.remove(0);
				}
			}
		}
	}
}
