package ����������;

import java.util.Scanner;

public class ����Ը��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		long[] data=new long[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextLong();
		}
		scanner.close();
		f(data);
	}
	
	public static void f(long[] data) {
		Long count=(long)0;
		for(int i=0;i<data.length;i++) {
			for(int j=i;j<data.length;j++) {
				if(data[i]>data[j]) {
					count++;
				}
			}
		}
		System.out.println(count);
	}
}
