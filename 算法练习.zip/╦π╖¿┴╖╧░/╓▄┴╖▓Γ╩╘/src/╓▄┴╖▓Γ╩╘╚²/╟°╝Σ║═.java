package ����������;

import java.util.Scanner;

public class ����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		int[] data=new int[n];
		int[] begin=new int[m];
		int[] end=new int[m];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		for(int i=0;i<m;i++) {
			begin[i]=scanner.nextInt()-1;
			end[i]=scanner.nextInt()-1;
		}
		scanner.close();
		for(int i=0;i<m;i++) {
			int sum=0;
			for(int j=begin[i] ; j<=end[i] ; j++) {
				sum+=data[j];
			}
			System.out.println(sum);
		}
	}
}
