package ����������;

import java.util.Scanner;

public class ���м��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		System.out.println((int)molecule(n)+"/"+(int)denominator(n));
		double sum=0;
		for(int i=1;i<=n;i++) {
			double temp=molecule(i)/denominator(i);
			sum+=temp;
		}
		System.out.printf("%.2f",sum);
	}
	
	public static double molecule(int n) {
		if(n==1) return 4.0;
		if(n==2) return 7.0;
		return molecule(n-1)+molecule(n-2);
	}
	
	public static double denominator(int n) {
		if(n==1) return 7.0;
		if(n==2) return 11.0;
		return denominator(n-1)+denominator(n-2);
	}
}
