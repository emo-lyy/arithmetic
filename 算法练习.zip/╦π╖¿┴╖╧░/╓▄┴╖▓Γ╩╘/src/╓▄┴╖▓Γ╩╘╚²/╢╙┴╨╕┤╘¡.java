package ����������;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ���и�ԭ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		Map<Integer, Integer> map=new HashMap<Integer, Integer>();
		for(int i=0;i<n;i++) {
			int value=scanner.nextInt();
			int key=scanner.nextInt();
			map.put(key, value);
		}
		scanner.close();
		int index=n-1;
		int temp=0;
		while(index>=0) {
			data[index]=map.get(temp);
			temp=map.get(temp);
			index--;
		}
		
		for (int i : data) {
			System.out.println(i);
		}
	}
}
