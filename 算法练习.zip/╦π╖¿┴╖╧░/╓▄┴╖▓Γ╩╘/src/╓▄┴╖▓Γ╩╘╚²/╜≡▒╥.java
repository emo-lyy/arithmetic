package ����������;

import java.util.Scanner;

public class ��� {
	public static void main(String[] args) {
		int sum=0;
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int count=1;
		int index=1;
		while(index<=n) {
			for(int i=1;i<=count;i++) {
				sum+=count;
				//System.out.println(index+" "+sum);
				index++;
				if(index==n+1) {
					System.out.println(sum);
					System.exit(0);
				}
			}
			count++;
		}
		//System.out.println(sum);
	}
}
