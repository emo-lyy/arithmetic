package ����������;

import java.util.Scanner;

public class �ұ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String S=scanner.next();
		scanner.close();
		String temp=S.substring(0, S.length()-1);
		//System.out.println(temp);
		String[] data=temp.split(",");
		//System.out.println(data[1]);
		int sumN=0;	//��
		int sumE=0;	//��
		int sumS=0;	//��
		int sumW=0;	//��
		
		for (String s : data) {
			char a=s.charAt(s.length()-1);
			String b=s.substring(0, s.length()-1);
			if(a=='N') {
				sumN+=Integer.valueOf(b);
			}
			else if(a=='E') {
				sumE+=Integer.valueOf(b);
			}
			else if(a=='S') {
				sumS+=Integer.valueOf(b);
			}
			else{
				sumW+=Integer.valueOf(b);
			}
		}
		
		int sum=0;
		if(sumN>sumS) {
			int box=sumN;
			sumN=sumS;
			sumS=box;
		}
		if(sumE>sumW) {
			int box=sumE;
			sumE=sumW;
			sumW=box;
		}
		sum+=sumN-sumS;
		sum+=sumE-sumW;
		
		if(sum<0) {
			sum=-sum;
		}
		System.out.println(sum);
	}
}
