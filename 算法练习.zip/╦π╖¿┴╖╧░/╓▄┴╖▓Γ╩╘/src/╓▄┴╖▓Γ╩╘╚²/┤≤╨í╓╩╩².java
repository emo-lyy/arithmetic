package ����������;

import java.util.Scanner;

public class ��С���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=n+1;true;i++) {
			if(check(i)) {
				System.out.print(i+" ");
				break;
			}
		}
		for(int i=n-1;i>1;i--) {
			if(check(i)) {
				System.out.println(i);
				break;
			}
		}
	}
	
	public static boolean check(int n) {
		for(int i=2;i<n;i++) {
			if(n%i==0)return false;
		}
		return true;
	}
}
