package ����������;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class �ֽ������� {
	private static ArrayList<Integer> temp=new ArrayList<>();
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		f(n);
		Collections.sort(temp);
		for (Integer i : temp) {
			System.out.println(i);
		}
	}
	
	public static void f(int n) {
		if(n==1) {
			return;
		}
		int k=1;
		for(int i=2;i<=n;i++) {
			if(n%i==0) {
				k=i;
				break;
			}
		}
		if(check(k)) {
			temp.add(k);
		}
		f(n/k);
	}
	
	public static boolean check(int n) {
		for(int i=2;i<n;i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}
}
