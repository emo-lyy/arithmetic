package ����������;

import java.util.ArrayList;
import java.util.Scanner;

public class ��ά����ת�ö� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		ArrayList<ArrayList<Integer>> temp=new ArrayList<>();
		for(int i=0;i<n;i++) {
			ArrayList<Integer> box=new ArrayList<>();
			for(int j=0;j<m;j++) {
				box.add(scanner.nextInt());
			}
			temp.add(box);
		}
		scanner.close();
		System.out.println(m+" "+n);
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				System.out.print(temp.get(j).get(i)+" ");
			}
			System.out.println();
		}
	}
}
