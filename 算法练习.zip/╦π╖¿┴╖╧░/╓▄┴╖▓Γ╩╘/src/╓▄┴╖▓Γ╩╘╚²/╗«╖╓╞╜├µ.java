package ����������;

import java.util.Scanner;

public class ����ƽ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		long n=scanner.nextLong();
		scanner.close();
		System.out.println(f(n));
	}
	
	public static Long f(long n) {
		Long temp=(1+n*(1+n)/2)%1000000007;
		return temp;
	}
}
