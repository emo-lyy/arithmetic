package ����������;

import java.util.Scanner;

public class �Ϸ��������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		int a=0;
		for(int i=0;i<str.length();i++) {
			char temp=str.charAt(i);
			if(temp=='(') {
				a++;
			}
			else {
				a--;
			}
			if(a<0) {
				System.out.println(0);
				return;
			}
		}
		if(a==0) {
			System.out.println("1");
		}
		else {
			System.out.println("0");
		}
	}
}
