package ����������;

import java.util.Scanner;

public class ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		f(data);
	}
	
	public static void f(int[] data) {
		for(int i=0;i<data.length;i++) {
			int max=0;
			if(data[i]==3) {max=2;}
			//System.out.println(1.0/temp);
			for(int j=2;j<=Math.sqrt(data[i]);j++) {
				double temp=data[i];
				int count=j;
				while(count>0) {
					//System.out.println(count);
					temp-=(temp-1)/j+1;
					//System.out.println(temp);
					if(temp<=0)break;
					count--;
				}
				if(temp%j==0 && temp>=0) {
					max=j;
				}
			}
			if(max!=0) {
				System.out.println(max);
			}
			else {
				System.out.println("No Solution");
			}
		}
	}
}
