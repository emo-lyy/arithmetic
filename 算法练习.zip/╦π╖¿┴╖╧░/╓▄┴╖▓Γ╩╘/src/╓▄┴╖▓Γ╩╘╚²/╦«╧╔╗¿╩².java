package ����������;

import java.util.Scanner;

public class ˮ�ɻ��� {
	public static void main(String[] args) {
		//System.out.println(check(123));
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=n;true;i++) {
			if(check(i)) {
				System.out.println(i);
				break;
			}
		}
	}
	
	public static boolean check(int n) {
		/*System.out.println(n/100);
		System.out.println(n%100/10);
		System.out.println(n%10);*/
		if(n>=100 && n<1000) {
			//System.out.println(000);
			int a=n/100;
			int b=n%100/10;
			int c=n%10;
			if(a*a*a+b*b*b+c*c*c==n) {
				return true;
			}
		}
		else if(n>=1000 && n<10000) {
			//System.out.println(111);
			int a=n/1000;
			int b=n%1000/100;
			int c=n%100/10;
			int d=n%10;
			if((a*a*a*a)+(b*b*b*b)+(c*c*c*c)+(d*d*d*d)==n) {
				return true;
			}
		}
		else if(n>=10000 && n<100000) {
			//System.out.println(222);
			int a=n/10000;
			int b=n%10000/1000;
			int c=n%1000/100;
			int d=n%100/10;
			int e=n%10;
			if(a*a*a*a*a+b*b*b*b*b+c*c*c*c*c+d*d*d*d*d+e*e*e*e*e==n) {
				return true;
			}
		}
		return false;
	}
}
