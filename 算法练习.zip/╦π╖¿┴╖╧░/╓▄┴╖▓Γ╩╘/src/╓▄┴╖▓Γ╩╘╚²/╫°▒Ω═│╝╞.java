package ����������;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class ����ͳ�� {
	public static void main(String[] args) {
		Map<Location,Integer> map=new HashMap<>();
		ArrayList<Location> temp=new ArrayList<>();
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		for(int i=1;i<=n;i++) {
			Location l=new Location(scanner.nextInt(),scanner.nextInt());
			map.put( l, i);
			temp.add(l);
		}
		scanner.close();
		
		
		
		int max=0;
		Location box=new Location();
		for(int i=0;i<temp.size();i++) {
			int sum=0;
			for(int j=0;j<temp.size();j++) {
				if(i!=j) {
					Location a=temp.get(i);
					Location b=temp.get(j);
					if(a.getX()>b.getX() && a.getY()>b.getY()) {
						sum++;
					}
				}
			}
			//System.out.println("--------------------");
			System.out.println(sum);
			if(max<=sum) {
				max=sum;
				box=temp.get(i);
			}
		}
		System.out.println(map.get(box));
	}
	
	
	
	public static class Location{
		private int x;
		private int y;
		public Location() {}
		/**
		 * @return the x
		 */
		public int getX() {
			return x;
		}
		/**
		 * @param x the x to set
		 */
		public void setX(int x) {
			this.x = x;
		}
		/**
		 * @return the y
		 */
		public int getY() {
			return y;
		}
		/**
		 * @param y the y to set
		 */
		public void setY(int y) {
			this.y = y;
		}
		public Location(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		};
		
	}
}
