package ����������;

import java.util.Scanner;

public class ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String[] data=new String[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.next();
		}
		scanner.close();
		for(int i=0;i<data.length;i++) {
			for(int j=i+1;j<data.length;j++) {
				String str1=data[i];
				String str2=data[j];
				if(str1.length()>str2.length()) {
					String temp=str1;
					str1=str2;
					str2=temp;
				}
				int len=str1.length();
				String s=str2.substring(0, len);
				if(str1.equals(s)) {
					System.out.println("No");
					return;
				}
			}
		}
		
		System.out.println("Yes");
	}
}
