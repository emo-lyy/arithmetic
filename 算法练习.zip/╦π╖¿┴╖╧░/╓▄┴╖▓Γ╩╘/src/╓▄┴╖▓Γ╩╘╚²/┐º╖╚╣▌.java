package ����������;

import java.util.ArrayList;
import java.util.Scanner;

public class ���ȹ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String[] data=scanner.next().split("");
		scanner.close();
		f(n,data);
	}
	
	public static void f(int n,String[] data) {
		ArrayList<String> box=new ArrayList<>();
		int count=0;
		for(int i=0;i<data.length;i++) {
			//System.out.println(box);
			String temp=data[i];
			if(box.size()<n) {
				if(box.contains(temp)) {
					//�����ǰ��˿�Ҫ�뿪�Ļ��Ͳ���
					int index=T(box,temp);
					box.remove(index);
					
					//System.out.println(111);
				}
				else {
					box.add(temp);
					
					//System.out.println(222);
				}
			}
			else if(box.size()==n) {
				if(box.contains(temp)) {
					//�����ǰ��˿�Ҫ�뿪�Ļ��Ͳ���
					int index=T(box,temp);
					box.remove(index);
					
					//System.out.println(333);
				}
				else {
					count++;
					box.add(temp);
					
					//System.out.println(444);
				}
			}
			else {
				if(box.contains(temp)) {
					int index=T(box,temp);
					box.remove(index);
					
				//	System.out.println(555);
				}
				else {
					count++;
					box.add(temp);
					
					//System.out.println(666);
				}
			}
		}
		System.out.println(count);
	}
	
	public static int T(ArrayList<String> data,String str) {
		int index=0;
		for(int i=0;i<data.size();i++) {
			if(str.equals(data.get(i))) {
				index=i;
				break;
			}
		}
		return index;
	}
}
