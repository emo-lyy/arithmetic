package ����������;

import java.util.Scanner;

public class �Ӿ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int m=scanner.nextInt();
		int n=scanner.nextInt();
		int[][] data=new int[m][n];
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				data[i][j]=scanner.nextInt();
				//System.out.println(data[i][j]);
			}
		}
		int k=scanner.nextInt();
		int[] beginL=new int[k];
		int[] endL=new int[k];
		int[] beginR=new int[k];
		int[] endR=new int[k];
		for(int i=0;i<k;i++) {
			beginL[i]=scanner.nextInt()-1;
			endL[i]=scanner.nextInt()-1;
			beginR[i]=scanner.nextInt()-1;
			endR[i]=scanner.nextInt()-1;
		}
		scanner.close();
		for(int i=0;i<k;i++) {
			int sum=0;
			for(int a=beginL[i] ; a<=endL[i] ; a++) {
				for(int b=beginR[i] ; b<=endR[i] ; b++) {
					sum+=data[a][b];
				}
			}
			System.out.println(sum);
		}
	}
}
