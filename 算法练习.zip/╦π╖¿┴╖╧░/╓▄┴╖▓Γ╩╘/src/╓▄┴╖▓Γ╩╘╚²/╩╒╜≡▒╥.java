package ����������;

import java.util.Scanner;

public class �ս�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt(); 
		}
		scanner.close();
		int box1=0;
		int box2=0;
		if(n%2==0) {
			for(int i=0;i<n/2;i++) {
				box1+=data[i];
				box2+=data[n-1-i];
			}
		}
		else {
			for(int i=0;i<n/2;i++) {
				box1+=data[i];
				box2+=data[n-1-i];
			}
			if(box1<box2) {
				box1+=data[n/2];
			}else {
				box2+=data[n/2];
			}
		}
		if(box1==box2) {
			System.out.println("Yes");
		}
		else {
			System.out.println("No");
		}
	}
}
