package ����������;

import java.util.Scanner;

public class �ַ��滻 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] data=scanner.next().toCharArray();
		scanner.close();
		for(int i=0;i<data.length;i++) {
			int temp=(int)data[i];
			if(temp>=(char)('0') && temp<=(char)('9')) {
				data[i]='*';
			}
		}
		System.out.println(new String(data));
	}
}
