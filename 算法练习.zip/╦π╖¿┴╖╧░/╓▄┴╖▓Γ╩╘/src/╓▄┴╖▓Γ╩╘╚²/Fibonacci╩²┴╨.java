package ����������;

import java.util.Scanner;

public class Fibonacci���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		for(int j=0;j<n;j++) {
			long sum=0;
			for(int i=1;true;i++) {
				if(f(i)<=data[j]) {
					if(f(i)%2==0) {
						sum+=f(i);
					}
				}
				else {
					break;
				}
			}
			System.out.println(sum);
		}
	}
	
	public static long f(int n) {
		if(n==1) return 1;
		if(n==2) return 2;
		return f(n-1)+f(n-2);
	}
}
