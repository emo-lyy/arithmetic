package ����������;

import java.util.Scanner;


/**
 * ������
 * @author ��ħ
 *
 */
public class ���ε����� {
	private static int mod=1000000007;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		scanner.close();
		System.out.println(f(n,m));
	}
	public static Long f(int n,int m) {
		if(n==m) return count(n)%mod;
		else {
			int box,l;
			if(n>m) {
				box=n;
				l=n-m;
			}
			else {
				box=m;
				l=m-n;
			}
			Long temp1=count(box);
			Long temp2=count(l);
			return (temp1-temp2)%mod;
		}
	}
	
	public static Long count(int n) {
		long count=0;
		for(int i=1;i<=n;i++) {
			count+=i;
		}
		return count;
	}
}