package ����������;

import java.util.Scanner;

public class ��η�֮�͵��ڱ��� {
	public static void main(String[] args) {
		//System.out.println(Math.pow(5, 2));
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		f(data);
	}
	
	public static void f(int[] data) {
		for (int i : data) {
			long sum=0;
			for(int k=10;k<=i;k++) {
				String s=k+"";
				int index=0;
				int temp=0;
				while(index<s.length()) {
					if(temp>k) {
						break;
					}
					temp+=Math.pow(Integer.valueOf(s.charAt(index)+""), 5);
					index++;
				}
				if(temp==k) {
					sum+=k;
				}
			}
			System.out.println(sum);
		}
	}
}
