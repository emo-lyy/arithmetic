package ����������;

import java.util.Scanner;

public class �����Ƽ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int res=binaryGap(n);
		System.out.println(res);
	}
	public static int binaryGap(int N) {
		String[] data=Integer.toString(N, 2).split("");
		int max=0;
		int begin=0;
		for(int i=0;i<data.length;i++) {
			if(data[i].equals("1")) {
				begin=i;
				break;
			}
		}
		int count=1;
		for(int i=begin+1;i<data.length;i++) {
			if(data[i].equals("1")) {
				int temp=i-begin;
				max=(max>temp)?max:temp;
				count++;
				begin=i;
			}
		}
		if(count==1) {
			return 0;
		}
		else {
			return max;
		}
		
    }
}
