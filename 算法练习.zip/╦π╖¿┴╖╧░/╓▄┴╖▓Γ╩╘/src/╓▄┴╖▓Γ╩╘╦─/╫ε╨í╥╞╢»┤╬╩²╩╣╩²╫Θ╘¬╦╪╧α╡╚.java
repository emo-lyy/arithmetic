package ����������;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.Scanner;

public class ��С�ƶ�����ʹ����Ԫ����� {
	public static int count=0;
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
			System.out.print(data[i]+" ");
		}
		System.out.println();
		scanner.close();
		int res=minMoves(data);
		System.out.println(res);
	}
	
	  public  static int minMoves(int[] nums) {
		 Set<Integer> set=new HashSet<>();
		 int maxIndex=0;
		 for(int i=0;i<nums.length;i++) {
			 maxIndex=(nums[maxIndex]>nums[i])?maxIndex:i;
			 set.add(nums[i]);
		 }
		 if(set.size()==1) {
			// count++;
			return count;
		 }
		for(int i=0;i<nums.length;i++) {
			if(i!=maxIndex) {
				nums[i]=nums[i]+1;
			}
		}
		count++;
		return minMoves(nums);
		
	 }
	  
	  public static int minMoves2(int[] nums) {
	        Arrays.sort(nums);
	        int sum = 0;
	        for (int i = nums.length - 1; i > 0; i--) {
	            sum += nums[i] - nums[0];
	        }
	        return sum;
	    }
}
