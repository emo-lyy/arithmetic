package ����������;

import java.util.Scanner;

public class ��Ч��ȫƽ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		boolean res=isPerfectSquare(n);
		System.out.println(res);
	}
	
	public static boolean isPerfectSquare(int num) {
		int l=(int)Math.sqrt(num);
		if(l*l==num) {
			return true;
		}
		return false;
	}
}
