package ����������;

import java.util.Scanner;

public class ��Χ��Ͷ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		
		int k=scanner.nextInt();
		int[][] operations=new int[k][2];
		for(int i=0;i<k;i++) {
			int x=scanner.nextInt();
			int y=scanner.nextInt();
			operations[i][0]=x;
			operations[i][1]=y;
		}
		scanner.close();
		int res=maxCount(n,m,operations);
		System.out.println(res);
	}
	
	public static int maxCount(int m, int n, int[][] ops) {
		if(ops.length==0) return m*n;
		else {
			int minX=ops[0][0];
			int minY=ops[0][1];
			for(int i=1;i<ops.length;i++) {
				int x=ops[i][0];
				int y=ops[i][1];
				minX=(minX<x)?minX:x;
				minY=(minY<y)?minY:y;
			}
			return minX*minY;
		}
    }
	
	
	
	
	public static int maxCount1(int m, int n, int[][] ops) {
		int[][] data=new int[n][m];
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				data[i][j]=0;
			}
		}
		
		for(int i=0;i<ops.length;i++) {
			int x=ops[i][0];
			int y=ops[i][1];
			f(x,y,data);
		}
		
		int max=data[0][0];
		int count=0;
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				if(data[i][j]==max) {
					count++;
				}
			}
		}
		return count;
    }
	
	public static void f(int x,int y,int[][] data) {
		for(int i=0;i<x;i++) {
			for(int j=0;j<y;j++) {
				data[i][j]+=1;
			}
		}
	}
	
}
