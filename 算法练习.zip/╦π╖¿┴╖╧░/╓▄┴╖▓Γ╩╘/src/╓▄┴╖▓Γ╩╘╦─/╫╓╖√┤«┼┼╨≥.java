package ����������;

import java.util.Scanner;

public class �ַ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int m=scanner.nextInt();
		String[] str=new String[m];
		for(int i=0;i<m;i++) {
			str[i]=scanner.next();
		}
		scanner.close();
		String[] s=new String[m];
		int[] data=new int[m];
		for(int i=0;i<m;i++) {
			char[] box=str[i].toCharArray();
			int count=0;
			for(int j=0;j<n;j++) {
				for(int k=j+1;k<n;k++) {
					char temp1=box[j];
					char temp2=box[k];
					//System.out.println(j+" "+k);
					//System.out.println(temp1+" "+temp2);
					if(temp1>temp2) {
						count++;
					}
				}
			}
			//System.out.println(count);
			s[i]=str[i];
			data[i]=count;
		}
		
		
		for(int i=0;i<data.length-1;i++) {
			for(int j=0;j<data.length-i-1;j++) {
				if(data[j]>data[j+1]) {
					swap1(data,j,j+1);
					swap2(s,j,j+1);
				}
			}
		}
		
		
		for (String S : s) {
			System.out.println(S);
		}
	}
	
	public static void swap1(int[] obj,int i,int j) {
		int temp=obj[i];
		obj[i]=obj[j];
		obj[j]=temp;
	}
	
	public static void swap2(String[] obj,int i,int j) {
		String temp=obj[i];
		obj[i]=obj[j];
		obj[j]=temp;
	}
}
