package ����������;

import java.util.Scanner;

public class ƽ����֮�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		boolean res=judgeSquareSum(n);
		System.out.println(res);
	}
	
	public static boolean judgeSquareSum(int c) {
		for(int i=0;i<=Math.sqrt(c);i++) {
			int temp=c-i*i;
			if(check(temp)) {
				return true;
			}
		}
		return false;
    }
	
	public static boolean check(int n) {
		int temp=(int)Math.sqrt(n);
		if(temp*temp==n)return true;
		else return false;
	}
}
