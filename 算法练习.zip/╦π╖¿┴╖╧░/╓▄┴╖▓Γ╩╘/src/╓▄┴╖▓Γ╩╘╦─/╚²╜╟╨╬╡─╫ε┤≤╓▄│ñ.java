package ����������;

import java.util.Arrays;
import java.util.Scanner;

public class �����ε�����ܳ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		int res=largestPerimeter(data);
		System.out.println(res);
	}
	
	public static int largestPerimeter(int[] A) {
		Arrays.sort(A);
		int len=A.length;
		int a=1;
		int b=2;
		int c=3;
		int max=0;
		while(len-c>=0) {
			int i=A[len-a];
			int j=A[len-b];
			int k=A[len-c];
			if(i+j>k && i+k>j && j+k>i) {
				max=i+j+k;
				break;
			}
			else {
				int temp=c;
				a=b;
				b=c;
				c=temp+1;
			}
		}
		return max;
    }
}
