package ����������;

import java.util.Arrays;
import java.util.Scanner;

public class ��С��ֵһ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		int k=scanner.nextInt();
		scanner.close();
		int res=smallestRangeI(data,k);
		System.out.println(res);
	}
	
	public static int smallestRangeI(int[] A, int K) {
		if(A.length==1 || A.length==0)return 0;
		Arrays.sort(A);
		int max=0;
		max=Math.abs(A[A.length-1]-A[0]);
		if(max>2*K) {
			max-=2*K;
		}
		else {
			max=0;
		}
		return max;
    }
}
