package ����������;

import java.util.Scanner;

public class ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		boolean res=isPowerOfThree(n);
		System.out.println(res);
	}
	
	public static boolean isPowerOfThree(int n) {
		 if(n<=0){
	    	 return false;
	     }
	     if(n==1){
	    	 return true;
	     }
	     if(n%3!=0){
	    	 return false;
	     }		 
		 return isPowerOfThree(n/3);
	}
}
