package ����������;

import java.util.Scanner;

public class һ�������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		f(data);
	}
	
	public static void f(int[] data) {
		int temp=0;
		for(int i=0;i<data.length;i++) {
			temp=temp^data[i];
		}
		System.out.println(temp);
	}
}
