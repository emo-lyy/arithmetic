package ����������;

import java.util.Scanner;

public class Ӳ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int res=arrangeCoins(n);
		System.out.println(res);
	}
	
	public static int arrangeCoins(int n) {
		int sum=1;
		int count=0;
		while(n>=1) {
			if(n>=sum) {
				count++;
			}
			n-=sum;
			sum++;
		}
		return count;
    }
}
