package ����������;

import java.util.Scanner;

public class ��С�ܳ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		long s=scanner.nextLong();
		scanner.close();
		int k=(int)Math.sqrt(s);
		for(int i=k;i<=s;i++) {
			if(s%i==0) {
				long j=s/i;
				System.out.println((i+j)*2);
				return;
			}
		}
	}
}
