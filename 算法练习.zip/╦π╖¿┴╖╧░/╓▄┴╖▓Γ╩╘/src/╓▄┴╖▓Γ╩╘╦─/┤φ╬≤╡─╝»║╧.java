package ����������;

import java.util.Scanner;

public class ����ļ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		findErrorNums(data);
	}
	
	public static int[] findErrorNums(int[] nums) {
		int[] res=new int[2];
		int len=nums.length;
		for(int i=1;i<=len ;i++) {
			int count=0;
			for (int l : nums) {
				if(i==l) {
					count++;
				}
			}
			if(count==2) {
				res[0]=i;
				//System.out.println(res[0]);
			}
			if(count==0) {
				res[1]=i;
				//System.out.println(res[1]);
			}
		}
		return res;
    }
}
