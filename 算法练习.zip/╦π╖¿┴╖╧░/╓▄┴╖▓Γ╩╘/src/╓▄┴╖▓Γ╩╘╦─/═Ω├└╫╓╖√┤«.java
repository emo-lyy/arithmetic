package ����������;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class �����ַ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		String[] data=str.toLowerCase().split("");
		//System.out.println(s);
		ArrayList<Integer> box=new ArrayList<>();
		Set<String> temp=new HashSet<>();
		for (String s : data) {
			temp.add(s);
		}
		//System.out.println(temp);
		for (String s1 : temp) {
			int count=0;
			for (String s2 : data) {
				if(s1.equals(s2)) {
					count++;
				}
			}
			box.add(count);
		}
		Collections.sort(box);
		//System.out.println(box);
		long sum=0;
		int k=26;
		for(int i=box.size()-1;i>=0;i--) {
			sum+=box.get(i)*k;
			k--;
		}
		System.out.println(sum);
	}
}
