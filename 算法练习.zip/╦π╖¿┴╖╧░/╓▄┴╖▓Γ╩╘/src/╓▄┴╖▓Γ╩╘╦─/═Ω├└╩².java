package ����������;

import java.util.ArrayList;
import java.util.Scanner;

public class ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		boolean res=checkPerfectNumber(n);
		System.out.println(res);
	}
	
	public static boolean checkPerfectNumber(int num) {
		int sum=1;
		for(int i=2;i<=(int)Math.sqrt(num);i++) {
			if(num%i==0) {
				sum+=i;
				sum+=num/i;
			}
		}
		if(sum==num && sum!=1)return true;
		else return false;
    }
}
