package ����������;

import java.util.Arrays;
import java.util.Scanner;

public class �����������˻� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		int res=maximumProduct(data);
		System.out.println(res);
	}
	
	public static int maximumProduct(int[] nums) {
		Arrays.sort(nums);
		int max=0;
		int a=nums[0]*nums[1]*nums[nums.length-1];
		int b=nums[nums.length-1]*nums[nums.length-2]*nums[nums.length-3];
		max=(a>b)?a:b;
		return max;
	 }
}
