package ����������;

import java.util.Scanner;

public class �͵�ƽ����ȥƽ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		f(data);
	}
	public static void f(int[] data) {
		for (int i : data) {
			long sum1=0;
			long sum2=0;
			for(int k=1;k<=i;k++) {
				sum1+=k;
				sum2+=k*k;
			}
			sum1*=sum1;
			System.out.println(sum1-sum2);
			
		}
	}
}
