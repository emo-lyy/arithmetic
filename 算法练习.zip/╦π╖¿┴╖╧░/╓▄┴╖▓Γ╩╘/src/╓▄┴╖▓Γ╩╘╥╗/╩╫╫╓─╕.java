package ��������һ;

import java.util.Scanner;

public class ����ĸ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String str=scanner.next();
		scanner.close();
		if(str.equals("a")) {
			System.out.println("apple");
		}
		else if(str.equals("b")) {
			System.out.println("banana");
		}
		else if(str.equals("c")) {
			System.out.println("cat");
		}
		else {
			System.out.println("no");
		}
	}
}
