package ��������һ;

import java.util.Scanner;

public class ����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		scanner.close();
		int temp=(a|b)-(a&b);
		System.out.println(temp);
	}
}
