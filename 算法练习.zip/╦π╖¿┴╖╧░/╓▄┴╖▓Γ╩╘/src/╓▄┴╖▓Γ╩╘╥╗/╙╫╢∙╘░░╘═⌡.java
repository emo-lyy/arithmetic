package ��������һ;

import java.util.Scanner;


public class �׶�԰���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.nextLine();
		int min=0;
		int max=0;
		String minName="";
		String maxName="";
		String str1=scanner.nextLine();
		String[] box1=str1.split("\\s+");
		int v=1;
		for(int i=0;i<3;i++) {
			v*=Integer.valueOf(box1[i]);
		}
		min=v;
		max=v;
		minName=box1[3];
		maxName=box1[3];
		
		
		for(int i=1;i<n;i++) {
			String str2=scanner.nextLine();
			String[] box2=str2.split("\\s+");
			int v1=1;
			for(int j=0;j<3;j++) {
				v1*=Integer.valueOf(box2[j]);
			}
			if(min>v1) {
				minName=box2[3];
				min=v1;
			}
			if(max<v1) {
				maxName=box2[3];
				max=v1;
			}
			
		}
		scanner.close();
		System.out.println(maxName+" "+minName);
	}
}
