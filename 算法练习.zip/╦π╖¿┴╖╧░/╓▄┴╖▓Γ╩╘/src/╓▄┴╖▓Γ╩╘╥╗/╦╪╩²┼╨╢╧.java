package ��������һ;

import java.util.Scanner;

public class �����ж� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=2;i<n;i++) {
			if(n%i==0) {
				System.out.println("No");
				return;
			}
		}
		System.out.println("Yes");
	}
}
