package ��������һ;

import java.util.Scanner;

public class ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int begin=scanner.nextInt();
		int end=scanner.nextInt();
		scanner.close();
		for(int i=end;i>=begin;i--) {
			System.out.println(i);
		}
	}
}
