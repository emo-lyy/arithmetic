package ��������һ;

import java.util.Scanner;

public class �ֵ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		char[] char1=scanner.next().toCharArray();
		char[] char2=scanner.next().toCharArray();
		scanner.close();
		int[] data1=new int[10000];
		//System.out.println(data1[0]);
		int[] data2=new int[10000];
		for(int i=0;i<char1.length;i++) {
			data1[i]=(int)char1[i];
		}
		for(int i=0;i<char2.length;i++) {
			data2[i]=(int)char2[i];
		}
		
		for(int i=0;i<10000;i++) {
			if(data1[i]<data2[i]) {
				System.out.println("yes");
				return;
			}
			if(data1[i]>data2[i]) {
				System.out.println("no");
				return;
			}
		}
	}
}
