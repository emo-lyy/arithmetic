package ��������һ;

import java.util.Scanner;

public class ��������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		int c=scanner.nextInt();
		int d=scanner.nextInt();
		scanner.close();
		if(a+b>10) {
			System.out.println(a*b);
		}
		else if (b+c>5) {
			System.out.println(c*d);
		}
		else if(d<10 || a*c>100) {
			System.out.println("Yes");
		}
		else {
			System.out.println("No");
		}
	}
}
