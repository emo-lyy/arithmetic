package ��������һ;

import java.util.Scanner;

public class �׳� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int temp=1;
		for(int i=1;i<=n;i++) {
			temp*=i;
		}
		System.out.println(temp);
	}
}
