package ��������һ;

import java.util.ArrayList;
import java.util.Scanner;

public class ���������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int begin=scanner.nextInt();
		int end=scanner.nextInt();
		scanner.close();
		
		ArrayList<Integer> box=new ArrayList<>();
		for(int i=begin;i<=end;i++) {
			String[] temp=(i+"").split("");
			boolean If=false;
			for (String s : temp) {
				if(s.equals("7")) {
					If=true;
				}
			}
			if(If) {
				box.add(i);
			}
		}
		if(box.size()==0) {
			System.out.println("None");
		}
		else {
			for (Integer i : box) {
				System.out.println(i);
			}
		}
	}
}
