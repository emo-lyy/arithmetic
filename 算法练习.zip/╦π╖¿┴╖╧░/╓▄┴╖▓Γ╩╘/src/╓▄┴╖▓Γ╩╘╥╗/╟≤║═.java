package ��������һ;

import java.util.Scanner;

public class ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int sum=scanner.nextInt()+scanner.nextInt();
		scanner.close();
		//System.out.println(sum);
		String[] data= {"one","two","three","four","five","six","seven","eight","nine","None"};
		switch (sum) {
		case 1:
			System.out.println(data[sum-1]);
			break;
		case 2:
			System.out.println(data[sum-1]);
			break;
		case 3:
			System.out.println(data[sum-1]);
			break;
		case 4:
			System.out.println(data[sum-1]);
			break;
		case 5:
			System.out.println(data[sum-1]);
			break;
		case 6:
			System.out.println(data[sum-1]);
			break;
		case 7:
			System.out.println(data[sum-1]);
			break;
		case 8:
			System.out.println(data[sum-1]);
			break;
		case 9:
			System.out.println(data[sum-1]);
			break;
		default:
			System.out.println(data[data.length-1]);
			break;
		}
	}
}
