package ��������һ;

import java.util.Scanner;

public class ���³�˫ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		//int n=scanner.nextInt();
		int[] data=new int[99];
		int index=0;
		while(index<=99) {
			int temp=scanner.nextInt();
			data[index]=temp;
			index++;
			if(temp==0) {
				break;
			}
		}
		
		int end=0;
		for (int i = 0; i < data.length; i++) {
			//System.out.println(data[i]);
			if(data[i]!=0) {
				end++;
			}
			else {
				break;
			}
		}
		
		scanner.close();
		int count=0;
		for(int i=0;i<=end;i++) {
			for(int j=i+1;j<end;j++) {
				int temp1=data[i];
				int temp2=data[j];
				if(temp1==2*temp2 || 2*temp1==temp2) {
					count++;
				}
			}
		}
		System.out.println(count);
	}
}
