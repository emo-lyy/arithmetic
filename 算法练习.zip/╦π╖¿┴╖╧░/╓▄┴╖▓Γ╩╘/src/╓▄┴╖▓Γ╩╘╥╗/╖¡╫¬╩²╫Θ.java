package ��������һ;

import java.util.Scanner;

public class ��ת���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		System.out.println(n);
		int index=n-1;
		while(index>=0) {
			System.out.println(data[index]);
			index--;
		}
	}
}
