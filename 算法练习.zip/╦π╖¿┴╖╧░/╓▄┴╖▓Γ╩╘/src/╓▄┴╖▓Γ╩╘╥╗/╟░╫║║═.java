package ��������һ;

import java.util.Scanner;

public class ǰ׺�� {
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		System.out.println(n);
		for(int i=0;i<n;i++) {
			int sum=0;
			for(int j=0;j<=i;j++) {
				sum+=data[j];
			}
			System.out.println(sum);
		}
	}
}
