package ��������һ;

import java.util.Scanner;

public class ����������չ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		boolean If=true;
		for(int a=2;a<=n;a++) {
			for(int b=2;b<=100;b++) {
				for(int c=2;c<=100;c++) {
					for(int d=2;d<=100;d++) {
						if(b<c && c<d) {
							int A=a*a*a;
							int B=b*b*b;
							int C=c*c*c;
							int D=d*d*d;
							if(A==B+C+D) {
								If=false;
								System.out.println("("+a+","+b+","+c+","+d+")");
							}
						}
					}
				}
			}
		}
		if(If) {
			System.out.println("OMG");
		}
	}
}
