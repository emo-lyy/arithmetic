package ��������һ;

import java.util.Scanner;

public class ���ַ�д {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String data=scanner.next();
		scanner.close();
		int index=data.length()-1;
		while(index>=0) {
			System.out.print(data.charAt(index));
			index--;
		}
	}
}
