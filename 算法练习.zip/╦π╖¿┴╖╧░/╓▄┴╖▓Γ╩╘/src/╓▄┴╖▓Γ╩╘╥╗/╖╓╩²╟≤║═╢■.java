package ��������һ;

import java.util.Scanner;

public class ������Ͷ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		double k=1.0;
		double sum=0;
		for(int i=1;i<=n;i++) {
			if(i%2==0) {
				sum+=0-(k/i);
			}
			else {
				sum+=k/i;
			}
		}
		System.out.println(sum);
	}
}
