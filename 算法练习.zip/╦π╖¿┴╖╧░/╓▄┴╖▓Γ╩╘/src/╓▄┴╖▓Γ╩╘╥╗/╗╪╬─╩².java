package ��������һ;

import java.util.Scanner;

public class ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String[] data=scanner.next().split("");
		scanner.close();
		int len=data.length;
		if(len%2==0) {
			int begin=0;
			int end=len-1;
			while(begin+1!=end) {
				if(!data[begin].equals(data[end])) {
					System.out.println("no");
					return;
				}
				begin++;
				end--;
			}
			System.out.println("yes");
		}
		else {
			int begin=0;
			int end=len-1;
			while(begin!=end) {
				if(!data[begin].equals(data[end])) {
					System.out.println("no");
					return;
				}
				begin++;
				end--;
			}
			System.out.println("yes");
		}
	}
}
