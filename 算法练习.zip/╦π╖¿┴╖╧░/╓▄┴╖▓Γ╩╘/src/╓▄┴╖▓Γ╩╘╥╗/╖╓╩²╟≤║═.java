package ��������һ;

import java.util.Scanner;

public class ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		double temp=1.0;
		double sum=0;
		for(int i=1;i<=n;i++) {
			sum+=(temp/i);
		}
		System.out.println(sum);
	}
}
