package ��������һ;

import java.util.Scanner;

public class ������ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int h=scanner.nextInt();
		scanner.close();
		String str="My height is ";
		System.out.println(str+h+"cm.");
	}
}
