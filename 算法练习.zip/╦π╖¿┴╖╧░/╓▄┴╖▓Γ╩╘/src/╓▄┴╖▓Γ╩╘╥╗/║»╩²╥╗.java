package ��������һ;

import java.util.Scanner;

public class ����һ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int x=scanner.nextInt();
		scanner.close();
		int res=f(x);
		System.out.println(res);
	}
	
	public static int f(int x) {
		return x*x+2*x+5;
	}
}
