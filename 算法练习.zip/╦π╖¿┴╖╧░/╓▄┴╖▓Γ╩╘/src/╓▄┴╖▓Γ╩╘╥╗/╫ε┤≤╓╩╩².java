package ��������һ;

import java.util.Scanner;

public class ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int res=0;
		for(int i=1;i<n;i++) {
			for(int j=2;j<=i;j++) {
				if(i==j) {
					res=i;
				}
				if(i%j==0) {
					break;
				}
			}
		}
		System.out.println(res);
	}
}
