package ��������һ;

import java.util.Scanner;

public class ���Ĵ������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int count=0;
		int k=2;
		while(true) {
			if(n%k!=0) {
				break;
			}
			else {
				k*=2;
				count++;
			}
		}
		System.out.println(count);
		
	}
}
