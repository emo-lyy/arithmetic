package ��������һ;

import java.util.Scanner;

public class ѭ����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=1;i<=n;i++) {
			System.out.println(i);
		}
	}
}
