package ��������һ;

import java.util.Scanner;

public class ��������һ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		int c=scanner.nextInt();
		scanner.close();
		int res=f(a,b,c);
		System.out.println(res);
	}
	
	public static int f(int a,int b,int c) {
		return a*(b+c-a);
	}
}
