package ��������һ;

import java.util.Scanner;

public class ��ȫƽ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=1;i<n/2;i++) {
			if(i*i==n) {
				System.out.println(i);
				return;
			}
		}
		System.out.println("No");
	}
}
