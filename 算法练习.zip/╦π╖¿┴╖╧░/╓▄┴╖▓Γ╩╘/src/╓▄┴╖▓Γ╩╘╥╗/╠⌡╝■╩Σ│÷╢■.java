package ��������һ;

import java.util.Scanner;

public class ��������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		scanner.close();
		int sum=a+b;
		if(0<=sum && sum<=3) {
			System.out.println("YES");
		}
		else if(sum>=4) {
			System.out.println("NO");
		}
		else if(sum<0) {
			System.out.println("negative");
		}
	}
}
