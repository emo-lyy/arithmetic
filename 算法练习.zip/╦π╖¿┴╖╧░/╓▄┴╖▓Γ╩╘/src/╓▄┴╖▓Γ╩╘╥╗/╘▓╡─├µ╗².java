package ��������һ;

import java.util.Scanner;

public class Բ����� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		double r=scanner.nextDouble();
		scanner.close();
		double s=f(r);
		System.out.println(s);
	}
	
	public static double f(double r) {
		double PI=3.14159;
		return r*r*PI;
	}
}
