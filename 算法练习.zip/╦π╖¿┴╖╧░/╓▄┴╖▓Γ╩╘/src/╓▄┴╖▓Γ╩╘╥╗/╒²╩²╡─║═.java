package ��������һ;

import java.util.Scanner;

public class �����ĺ� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		int sum=0;
		for (int i : data) {
			if(i>0) {
				sum+=i;
			}
		}
		System.out.println(sum);
	}
}
