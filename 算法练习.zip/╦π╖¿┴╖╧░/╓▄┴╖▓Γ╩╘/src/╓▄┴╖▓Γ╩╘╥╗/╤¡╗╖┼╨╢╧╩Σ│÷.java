package ��������һ;

import java.util.Scanner;

public class ѭ���ж���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int i=3;
		int k=1;
		while(true) {
			if(i*k<=n) {
				System.out.println(i*k);
			}else {break;}
			k++;
		}
	}
}
