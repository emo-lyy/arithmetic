package ��������һ;

import java.util.Scanner;

public class ����ֵ {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for(int i=0;i<n;i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		int min=data[0];
		int max=data[0];
		for(int i=1;i<n;i++) {
			min=(min<data[i])?min:data[i];
			max=(max>data[i])?max:data[i];
		}
		System.out.print(min+" "+max);
	}
}
