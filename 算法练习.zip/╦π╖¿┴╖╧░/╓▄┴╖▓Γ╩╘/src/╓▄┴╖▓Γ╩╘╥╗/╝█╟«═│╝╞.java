package ��������һ;

import java.util.Scanner;

public class ��Ǯͳ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		double a=scanner.nextDouble();
		double b=scanner.nextDouble();
		double c=scanner.nextDouble();
		double d=scanner.nextDouble();
		scanner.close();
		String sumA=String.format("%.1f", a*1.2);
		String sumB=String.format("%.1f", b*3.5);
		String sumC=String.format("%.1f", c*4.5);
		String sumD=String.format("%.1f", d*5);
		String sum=String.format("%.1f", a*1.2+b*3.5+c*4.5+d*5);
		
		System.out.println(sumA);
		System.out.println(sumB);
		System.out.println(sumC);
		System.out.println(sumD);
		System.out.println(sum);
	}
}
