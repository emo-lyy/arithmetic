package ��������һ;

import java.util.Scanner;

public class �������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		String[] temp=(n+"").split("");
		boolean If=false;
		for (String s : temp) {
			if(s.equals("7")) {
				If=true;
			}
		}
		if(If) {
			System.out.println("Yes");
		}
		else {
			System.out.println("No");
		}
	}
}
