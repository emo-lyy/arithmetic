package ��������һ;

import java.util.Scanner;

public class ���� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		
		for(int i=0;i<n;i++) {
			int[] data=new int[3];
			for(int j=0;j<3;j++) {
				data[j]=scanner.nextInt();
			}
			int x=data[0];
			int l=data[1];
			int z=data[2];
			double C=(x*3.14159)*(z/360.0)*2;
			double L=l*5;
			boolean If=L>C;
			if(If) {
				System.out.println("YES");
			}
			else {
				System.out.println("NO");
			}
			
		}
		
		scanner.close();
	}
}
