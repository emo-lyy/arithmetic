package ��������һ;

import java.util.Scanner;

public class �ŵĸ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		int count=0;
		for(int i=1;i<=n;i++) {
			String[] data=(i+"").split("");
			for (String s : data) {
				if(s.equals("9")) {
					count++;
				}
			}
		}
		System.out.println(count);
	}
}
