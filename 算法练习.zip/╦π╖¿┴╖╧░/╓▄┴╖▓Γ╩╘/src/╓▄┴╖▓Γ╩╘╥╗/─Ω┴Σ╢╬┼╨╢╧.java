package ��������һ;

import java.util.Scanner;

public class ������ж� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		if(0<=n && n<=3) {
			System.out.println("infant");
		}
		else if(4<=n && n<=12) {
			System.out.println("child");
		}
		else if(13<=n && n<=18) {
			System.out.println("youngster");
		}
		else if(19<=n && n<=25) {
			System.out.println("youth");
		}
	}
}
