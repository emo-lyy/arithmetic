package ��������һ;

import java.util.Scanner;

public class ��������� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		double k=1.0;
		double sum=0;
		for(int i=1;i<=n;i++) {
			int m=1;
			for(int j=1;j<=i;j++) {
				m*=j;
			}
			sum+=k/m;
		}
		System.out.println(sum);
	}
}
