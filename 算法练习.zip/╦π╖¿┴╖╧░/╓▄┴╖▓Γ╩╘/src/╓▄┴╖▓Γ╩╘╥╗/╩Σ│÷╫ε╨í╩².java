package ��������һ;

import java.util.Scanner;

public class �����С�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		int[] data=new int[n];
		for (int i = 0; i < data.length; i++) {
			data[i]=scanner.nextInt();
		}
		scanner.close();
		int min=data[0];
		for (int i = 1; i < data.length; i++) {
			min=(min<data[i])?min:data[i];
		}
		System.out.println(min);
	}
}
