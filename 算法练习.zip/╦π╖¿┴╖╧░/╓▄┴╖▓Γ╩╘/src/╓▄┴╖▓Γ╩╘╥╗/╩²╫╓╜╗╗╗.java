package ��������һ;

import java.util.Scanner;

public class ���ֽ��� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int a=scanner.nextInt();
		int b=scanner.nextInt();
		int c=scanner.nextInt();
		scanner.close();
		int temp=a;
		a=b;
		b=c;
		c=temp;
		System.out.println(a+" "+b+" "+c);
	}
}
