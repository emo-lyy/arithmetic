package ��������һ;

import java.util.Scanner;

public class �ַ����ֵ�λ�� {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String str=scanner.next();
		char c=scanner.next().charAt(0);
		scanner.close();
		System.out.println(str.indexOf(c));
	}
}
