package test;

public class Calculated {
	public static void main(String[] args)throws Exception {
		long n=0l;
		long time=System.currentTimeMillis();
		while ((System.currentTimeMillis()-time)<=1000) {
			n++;
		}
		System.out.println(n);
	}
}
