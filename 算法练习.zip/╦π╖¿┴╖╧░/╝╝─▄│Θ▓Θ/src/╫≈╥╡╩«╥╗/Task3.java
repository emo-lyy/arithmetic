package ��ҵʮһ;

public class Task3 {
	static void task3() {
		Shopping[] shoppings=new Shopping[3];
		shoppings[0]=new Shopping("��Ʒһ",1000,1);
		shoppings[1]=new Shopping("��Ʒ��",2000,1);
		shoppings[2]=new Shopping("��Ʒ��",3000,1);
		double sum=0.0;
		for (Shopping s : shoppings) {
			sum+=s.getPric();
		}
		double averagePric=sum/shoppings.length;
		System.out.println("��Ʒ����Ϊ:"+averagePric);
		System.out.println("��Ʒ�ܼ�Ϊ:"+sum);
	}
	public static void main(String[] args) {
		task3();
	}
}
