package ��ҵ��;

import java.util.Scanner;

public class Task1 {
	static void task1() {
		Scanner scanner=new Scanner(System.in);
		float unitPrice=scanner.nextFloat();		//����
		int number=scanner.nextInt();			//����
		scanner.close();
		if(number<0)System.out.println("��������");
		else if(0<=number && number<=10){
			float pric=(float) (unitPrice*number*9);
			System.out.println("�ܶ�Ϊ:"+pric);
		}
		else if(number>10 && number<=100) {
			float pric=(float) (unitPrice*number*0.85);
			System.out.println("�ܶ�Ϊ:"+pric);
		}
		else {
			float pric=(float) (unitPrice*number*0.8);
			System.out.println("�ܶ�Ϊ:"+pric);
		}
	}
	public static void main(String[] args) {
		task1();
	}
}
