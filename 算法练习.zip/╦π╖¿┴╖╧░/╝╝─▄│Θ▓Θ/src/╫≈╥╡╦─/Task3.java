package ��ҵ��;

import java.util.Scanner;

public class Task3 {
	static void task3() {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();	
		if(n<0) {
			System.out.println("input error");
			return; 	//��ʼ��ֵ����
		}
		for(int i=0;i<=n;i++) {
			for(int j=0;j<=n;j++) {
				if(i+j==n) {			//�жϵ�ʽ�Ƿ����
					System.out.println(i+"+"+j+"="+n);
				}
			}
		}
	}
	public static void main(String[] args) {
		task3();
	}
}
