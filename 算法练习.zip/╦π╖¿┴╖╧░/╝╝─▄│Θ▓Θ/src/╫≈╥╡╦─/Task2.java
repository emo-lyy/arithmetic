package ��ҵ��;

import java.util.Scanner;

public class Task2 {
	static void task2() {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		if(n<1000 || n>10000) {
			System.out.println("input error");
			return;
		}
		int a=n/1000;			//ǧλ�ϵ���ֵ
		int b=n%1000/100;		//��λ�ϵ���ֵ
		int c=n%100/10;			//ʮλ�ϵ���ֵ
		int d=n%10;				//��λ�ϵ���ֵ
		int sum=a+b+c+d;
		System.out.println((n+"").length());
		System.out.println(sum);
	}
	public static void main(String[] args) {
		task2();
	}
}
