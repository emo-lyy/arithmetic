package 作业六;

import java.util.Scanner;

public class Task1 {
    static void task1(){
    	Scanner scanner=new Scanner(System.in);
    	int n=scanner.nextInt();
    	scanner.close();
    	if(check3(n) && check5(n) && check7(n)) {
    		System.out.println("能同时被 3、5、7 整除");
    	}
    	else if(check3(n) && check5(n)) {
    		System.out.println("能同时被 3、5 整除");
    	}
    	else if(check3(n) && check7(n)) {
    		System.out.println("能同时被 3、7 整除");
    	}
    	else if(check5(n) && check7(n)) {
    		System.out.println("能同时被 5、7 整除");
    	}
    	else if(check(n)) {
    		System.out.println("只能被 3、5、7 中的一个整除");
    	}
    	else if(check3(n)==false && check5(n)==false && check7(n)==false) {
    		System.out.println("不能被 3、5、7 任一个整除");
    	}
    }
    //能被3整除
    static boolean check3(int n) {
    	return n%3==0;
    }
    //能被5整除
    static boolean check5(int n) {
    	return n%5==0;
    }
    //能被7整除
    static boolean check7(int n) {
    	return n%7==0;
    }
    
    //只能被一个整除
    static boolean check(int n) {
    	int count=0;
    	if(check3(n)) count++;
    	if(check5(n)) count++;
    	if(check7(n)) count++;
    	return count==1; 
    }
    
    public static void main(String[] args) {
		task1();
	}
}
