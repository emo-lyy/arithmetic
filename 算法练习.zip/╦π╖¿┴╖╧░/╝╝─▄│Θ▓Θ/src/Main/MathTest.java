package Main;

public class MathTest {
	public static void main(String[] args) {
		Shopping s=new Shopping();
		s.setName("��Ʒ��");
		s.setNumber(2);
		System.out.println(s.getNumber());
		
	}
	//���Ȳ� Math��ѧ����
	static boolean check(int n) {
		double k=Math.sqrt(n);		//��ƽ��
		int l=(int)k;
		if(l*l==n)return true;
		else return false;
	}
}
