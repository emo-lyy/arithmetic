package ��ҵ��;

import java.util.Scanner;

public class Task2 {
	static void task2() {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=0;i<n;i++) {				//��ӡ�߶�
			for(int j=0;j<n;j++) {
				System.out.print("*");		//��ӡ��*��
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		task2();
	}
}
