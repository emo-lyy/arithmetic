package ��ҵ��;

import java.util.Scanner;

public class Task3 {
	static void task3() {
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		scanner.close();
		for(int i=0;i<n;i++) {
			for(int j=1;j<=i*2+1;j++) {		//��ӡ�߶�
				System.out.print("*");		//��ӡ��*��
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		task3();
	}
}
