package ��ҵʮ��;

import java.util.Scanner;

public class Task3 {
	final static double PI=3.14;
	static void task3() {
		Scanner scanner=new Scanner(System.in);
		double h=scanner.nextDouble();			//Բ���ĸ߶�
		double r=scanner.nextDouble();				//Բ����Բ�İ뾶
		scanner.close();
		double V=getV(h,r);
		System.out.print("V=");
		System.out.format("%.2f", V).println();
	}
	static double getV(double h,double r) {
		return PI*r*r*h;
	}
	public static void main(String[] args) {
		task3();
	}
}
