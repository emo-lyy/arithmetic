package com.example.kugou.logic;

public interface SongListLogic {

    public String selectByName(String name);
}
