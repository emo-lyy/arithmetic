package com.example.kugou.logic;

import com.example.kugou.pojo.User;

public interface UserLogic {

    /**
     * 登录
     * @param user
     * @param password
     * @return
     */
    public String selectByUserName(String user,String password);


    /**
     * 添加用户
     * @param user
     * @return
     */
    public String insertUser(User user);


    /**
     * 更改用户密码
     * @param phone
     * @param userName
     * @param nextPassWord
     * @return
     */
    public String updatePassByName(String phone,String userName,String nextPassWord);
}
