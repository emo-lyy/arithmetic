package com.example.kugou.logic;

import com.example.kugou.mapper.UserMapper;
import com.example.kugou.pojo.Data;
import com.example.kugou.pojo.User;
import com.example.kugou.tool.MD5;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserLogicImpl implements UserLogic{
    @Autowired
    private UserMapper userMapper;

    private Gson json=new Gson();

    @Override
    public String selectByUserName(String username, String password) {
        try {
            User user= userMapper.select_by_user(username);
            if(user==null){
                return json.toJson(new Data(404,"查询成功","用户名不存在"));
            }else if(!MD5.equals(MD5.encryption(password),user.getPassWord())){
                return json.toJson(new Data(304,"查询成功","用户密码不正确"));
            } else{
                return json.toJson(new Data(200,"查询成功",user));
            }
        } catch (Exception e){
            e.printStackTrace();
            return json.toJson(new Data(500,"查询失败",null));
        }
    }


    @Override
    public String insertUser(User user) {
        try{
            userMapper.addUser(user);
            return json.toJson(new Data(200,"注册成功",user.getUserName()+"创建成功"));
        }catch (Exception e){
            e.printStackTrace();
            return json.toJson(new Data(500,"注册失败",null));
        }
    }

    @Override
    public String updatePassByName(String phone, String userName, String nextPassWord) {
        User user=userMapper.select_by_user(userName);
        if(user==null){
            return json.toJson(new Data(404,"更改失败","该用户不存在"));
        }else if(!user.getPhone().equals(phone)){
            return json.toJson(new Data(304,"更改失败","联系方式不匹配"));
        }else{
            userMapper.update_pwd_by_name(userName,MD5.encryption(nextPassWord));
            return json.toJson(new Data(200,"更改成功",userName+"密码更改成功"));
        }
    }
}
