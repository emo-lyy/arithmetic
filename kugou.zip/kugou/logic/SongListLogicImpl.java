package com.example.kugou.logic;

import com.example.kugou.mapper.MusicMapper;
import com.example.kugou.mapper.SongListMapper;
import com.example.kugou.pojo.Data;
import com.example.kugou.pojo.SongList;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SongListLogicImpl implements SongListLogic {
    @Autowired
    private SongListMapper songListMapper;

    @Autowired
    private MusicMapper musicMapper;

    private Gson json=new Gson();
    /**
     * 根据歌单名称查询歌单
     * @param name
     * @return
     */
    @Override
    public String selectByName(String name) {
        try{
            SongList list= songListMapper.select_by_name(name);
            list.setMusics(musicMapper.select_t_music_And_t_songList_by_songListName(name));
            return json.toJson(new Data(200,"查询成功",list));
        }catch (Exception e){
            return json.toJson(new Data(500,"查询失败",null));
        }

    }
}
