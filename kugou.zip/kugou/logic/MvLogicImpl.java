package com.example.kugou.logic;

import com.example.kugou.mapper.MvMapper;
import com.example.kugou.pojo.Data;
import com.example.kugou.pojo.Mv;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MvLogicImpl implements MvLogic{
    private Gson json=new Gson();

    @Autowired
    private MvMapper mvMapper;

    @Override
    public String select_by_mvName(String mvName) {
        try{
            Mv mv=mvMapper.selectByName('%'+mvName+'%');
            return json.toJson(new Data(200,"查询成功",mv));
        }catch (Exception e){
            e.printStackTrace();
            return json.toJson(new Data(500,"查询失败",null));
        }

    }
}
