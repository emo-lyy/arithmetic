package com.example.kugou.logic;

import com.example.kugou.mapper.MusicMapper;
import com.example.kugou.pojo.Data;
import com.example.kugou.pojo.Music;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MusicLogicImpl implements MusicLogic {
    @Autowired
    private MusicMapper musicMapper;

    private Gson json=new Gson();

    /**
     * 插入音乐信息
     * @param music
     */
    public String add_music(Music music){
        String res=null;
        try{
            musicMapper.addMusic(music);
            System.out.println("信息已成功插入数据库..........");
            res=json.toJson(new Data(200,"成功","插入成功"));
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("数据库插入失败...........");
            res=json.toJson(new Data(500,"失败","插入失败"));
        }
        return res;
    }

    /**
     * 根据歌曲类型迷糊查询对应的歌曲
     * @param musicType
     * @param page
     * @return
     */
    public String select_music_like_musicType(String musicType,int page){
        try {
            int beginIndex=(page-1)*8;
            int len=8;
            Map<String,Object> select=new HashMap<>();
            select.put("musicType","%"+musicType+"%");
            select.put("beginIndex",beginIndex);
            select.put("len",len);
            return json.toJson(new Data(200,"成功",musicMapper.selectMusicLikeMusicType(select)));
        }catch (Exception e) {
            e.printStackTrace();
            return json.toJson(new Data(500, "失败", "查询歌曲失败"));
        }
    }

    public String query_music(String queryData){
        try {
            return json.toJson(new Data(200,"成功",musicMapper.queryMusic("%"+queryData+"%")));
        }catch (Exception e){
            e.printStackTrace();
            return json.toJson(new Data(500, "失败", "查询歌曲失败"));
        }
    }


    /**
     * 电台
     * @param a
     * @param b
     * @return
     */
    @Override
    public String select_music_limit(int a, int b) {
        try {
            List<Music> data=musicMapper.select_limit(a, b);
            return json.toJson(new Data(200,"成功",data));
        }catch (Exception e){
            e.printStackTrace();
            return json.toJson(new Data(500,"失败","获取电台信息失败"));
        }
    }
}
