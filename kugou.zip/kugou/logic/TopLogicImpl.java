package com.example.kugou.logic;

import com.example.kugou.mapper.MusicMapper;
import com.example.kugou.mapper.TopMapper;
import com.example.kugou.pojo.Data;
import com.example.kugou.pojo.Top;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TopLogicImpl implements  TopLogic {
    private Gson json=new Gson();
    @Autowired
    private TopMapper topMapper;
    @Autowired
    private MusicMapper musicMapper;
    
    @Override
    public String selectByName(String identifier) {
        try {
            Top top = topMapper.select_by_name(identifier);
            top.setMusics(musicMapper.select_t_music_And_t_Top_by_musicId(top.getTop_id()));
            return json.toJson(new Data(200,"查询成功",top));
        }catch (Exception e){
            e.printStackTrace();
            return json.toJson(new Data(500,"查询失败",null));
        }
    }
}
