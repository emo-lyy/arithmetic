package com.example.kugou.logic;

public interface MvLogic {
    public String select_by_mvName(String mvName);
}
