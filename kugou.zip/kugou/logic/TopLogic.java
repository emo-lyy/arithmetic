package com.example.kugou.logic;

public interface TopLogic {
    public String selectByName(String topName);
}
