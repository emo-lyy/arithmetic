package com.example.kugou.logic;

import com.example.kugou.pojo.Music;

import java.util.List;

public interface MusicLogic {
    public String add_music(Music music);       //添加音乐信息
    public String select_music_like_musicType(String musicType,int page);      //根据歌曲类型查询对应的歌曲
    public String query_music(String queryData);            //查询歌曲
    public String select_music_limit(int a,int b);          //电台
}
