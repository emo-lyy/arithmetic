package com.example.kugou.interceptor;

import com.example.kugou.tool.RequestFormat;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//这是一个拦截器操作类
@Slf4j
public class MyInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //处理前
        log.debug("MyInterceptor: preHandle,处理前");
        RequestFormat.request_format(request,response);     //处理编码格式
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        //处理中
        log.debug("MyInterceptor: postHandle，处理中");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        //处理后
        log.debug("MyInterceptor: afterCompletion，处理后");
    }
}
