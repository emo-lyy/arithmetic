package com.example.kugou.pojo;

import lombok.Data;
import tk.mybatis.mapper.annotation.KeySql;

import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Table(name = "t_music")
public class Music {
    @KeySql(useGeneratedKeys = true)
    @Id
    private int music_id;

    private String musicName;
    private String singer;
    private String musicPath;
    private String musicAlbum;
    private String playNumber;
    private String time;
    private String musicType;
    private String annotation;

    public Music(){}
    public Music(int music_id,String musicName,String singer,String musicPath,String musicAlbum,String playNumber,String time,String musicType,String annotation){
        this.music_id=music_id;
        this.musicName=musicName;
        this.singer=singer;
        this.musicPath=musicPath;
        this.musicAlbum=musicAlbum;
        this.playNumber=playNumber;
        this.time=time;
        this.musicType=musicType;
        this.annotation=annotation;
    }
}
