package com.example.kugou.pojo;

import lombok.Data;
import tk.mybatis.mapper.annotation.KeySql;

import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Table(name = "t_mv")
public class Mv {
    @KeySql(useGeneratedKeys = true)
    @Id
    private int mv_id;
    private int singer_id;
    private String singer_name;
    private String mv_name;
    private String mv_path;
    private String mv_brief;
    private String mv_beizhu;

    public Mv(){}
    public Mv(int mv_id, int singer_id, String singer_name, String mv_name, String mv_path, String mv_brief, String mv_beizhu) {
        this.mv_id = mv_id;
        this.singer_id = singer_id;
        this.singer_name = singer_name;
        this.mv_name = mv_name;
        this.mv_path = mv_path;
        this.mv_brief = mv_brief;
        this.mv_beizhu = mv_beizhu;
    }
}
