package com.example.kugou.pojo;

import lombok.Data;
import tk.mybatis.mapper.annotation.KeySql;

import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Table(name = "t_user")
public class User {
    @KeySql(useGeneratedKeys = true)
    @Id
    private int user_id;

    @KeySql(useGeneratedKeys = true)
    @Id
    private String userName;

    private String passWord;

    private String nickName;

    private String phone;

    private int role;

    private String sex;

    private String likeMusicType;

    private String creationTime;

    private String annotation;
}
