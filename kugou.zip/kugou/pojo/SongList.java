package com.example.kugou.pojo;

import lombok.Data;
import tk.mybatis.mapper.annotation.KeySql;

import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 歌单表
 */
@Data
@Table(name = "t_songlist")
public class SongList {
    @KeySql(useGeneratedKeys = true)
    @Id
    private String songList_id;
    private String songList_name;
    private String songList_volume;
    private String songList_image;
    private String songList_person;
    private String songList_mood;
    private String songList_time;
    private String songList_brief;
    private Object musics;          //歌单歌曲集

    public SongList(){}

    public SongList(String songList_id, String songList_name, String songList_volume, String songList_image, String songList_person, String songList_mood, String songList_time, String songList_brief) {
        this.songList_id = songList_id;
        this.songList_name = songList_name;
        this.songList_volume = songList_volume;
        this.songList_image = songList_image;
        this.songList_person = songList_person;
        this.songList_mood = songList_mood;
        this.songList_time = songList_time;
        this.songList_brief = songList_brief;
    }
}
