package com.example.kugou.pojo;

import lombok.Data;

@Data
public class SaveMusic {
    private String music;       //歌名
    private String singer;      //歌手
    private String ulr;         //路径(网络请求路径)

}
