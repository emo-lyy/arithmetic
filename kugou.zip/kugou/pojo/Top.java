package com.example.kugou.pojo;

import lombok.Data;
import tk.mybatis.mapper.annotation.KeySql;

import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Table(name = "t_top")
public class Top {
    @KeySql(useGeneratedKeys = true)
    @Id
    private int top_id;
    private String top_identifier;
    private String top_name;
    private String top_updateTime;
    private String top_brief;
    private Object musics;

    public Top(){}

    public Top(int top_id, String top_name, String top_updateTime, String top_brief, Object musics) {
        this.top_id = top_id;
        this.top_name = top_name;
        this.top_updateTime = top_updateTime;
        this.top_brief = top_brief;
        this.musics = musics;
    }

    public Top(int top_id, String top_identifier, String top_name, String top_updateTime, String top_brief, Object musics) {
        this.top_id = top_id;
        this.top_identifier = top_identifier;
        this.top_name = top_name;
        this.top_updateTime = top_updateTime;
        this.top_brief = top_brief;
        this.musics = musics;
    }
}
