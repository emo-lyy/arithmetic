package com.example.kugou.controller;

import com.example.kugou.logic.TopLogicImpl;
import com.example.kugou.tool.RequestFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
public class TopService {
    @Autowired
    private TopLogicImpl topLogic;

    @RequestMapping("/top")
    public void getTop(HttpServletRequest request, HttpServletResponse response)throws Exception{
        RequestFormat.request_format(request,response);
        response.getWriter().write(topLogic.selectByName(request.getParameter("identifier")));
    }
}
