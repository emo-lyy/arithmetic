package com.example.kugou.controller;

import com.example.kugou.logic.MusicLogicImpl;
import com.example.kugou.pojo.Music;
import com.example.kugou.tool.EncapsulatedFile;
import com.example.kugou.tool.RequestFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
public class GetMusicUrl {
    @Autowired
    private MusicLogicImpl musicLogic;
    private final String httpUrl="/local/music/";

    @RequestMapping("/music_data")
    public void get_music_url(HttpServletRequest request, HttpServletResponse response){
        try{
            RequestFormat.request_format(request,response);         //处理编码格式问题
            String url=request.getParameter("url");              //歌曲网页地址

            String singer=checkFileName(request.getParameter("singer"));        //歌手
            String music_name=checkFileName(request.getParameter("musicName"));     //歌曲名

            String album=request.getParameter("album");                //专辑
            String time=request.getParameter("time");                  //歌曲时长

            EncapsulatedFile.saveFile(url,singer+" - "+music_name+".mp3");          //下载歌曲

            Music music=new Music();
            music.setMusic_id(0);
            music.setMusicName(music_name);
            music.setSinger(singer);
            music.setMusicPath(httpUrl+singer+" - "+music_name+".mp3");
            music.setTime(time);
            music.setMusicAlbum(album);
            music.setMusicType("华语");
            music.setPlayNumber(playNumber()+"");
            music.setAnnotation("");

            System.out.println("歌曲名称:"+music.getSinger()+"\t"+"歌手:"+music.getMusicName());



            musicLogic.add_music(music);
        }catch (Exception e){
            System.out.println("下载失败");
            e.printStackTrace();
        }

    }

    public String checkFileName(String fileName){
        String res="";
        for(int i=0;i<fileName.length();i++) {
            char temp = fileName.charAt(i);
            if (temp == '(' || temp == ')' || temp == 34 || temp == 39 || temp == 46 || temp==47 || temp==92 || temp=='[' || temp==']') {
                res += " ";
            } else {
                res += temp;
            }
        }
        return res;
    }

    //播放量(随机数)
    public int playNumber(){
        return (int)(Math.random()*10000-1+1);
    }
}

