package com.example.kugou.controller;

import com.example.kugou.logic.UserLogicImpl;
import com.example.kugou.pojo.User;
import com.example.kugou.tool.MD5;
import com.example.kugou.tool.RequestFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
public class UserService {
    @Autowired
    private UserLogicImpl userLogic;

    @RequestMapping("/login")
    public void login(HttpServletRequest request, HttpServletResponse response)throws Exception{
        RequestFormat.request_format(request,response);
        String user=request.getParameter("user");
        String password=request.getParameter("password");
        response.getWriter().write(userLogic.selectByUserName(user,password));
    }

    @RequestMapping("/register")
    public void register(HttpServletRequest request,HttpServletResponse response)throws Exception{
        RequestFormat.request_format(request,response);
        User user=new User();
        user.setUserName(request.getParameter("userName"));
        user.setPassWord(MD5.encryption(request.getParameter("passWord")));
        user.setNickName(request.getParameter("nickName"));
        user.setPhone(request.getParameter("phone"));
        user.setSex(request.getParameter("sex"));
        response.getWriter().write(userLogic.insertUser(user));
    }

    @RequestMapping("/updatePassword")
    public void updatePassword(HttpServletRequest request,HttpServletResponse response)throws Exception{
        RequestFormat.request_format(request,response);
        String phone=request.getParameter("phone");
        String userName=request.getParameter("userName");
        String nextPassword=request.getParameter("nextPassword");
        response.getWriter().write(userLogic.updatePassByName(phone,userName,nextPassword));
    }
}
