package com.example.kugou.controller;

import com.example.kugou.logic.MusicLogicImpl;
import com.example.kugou.tool.RequestFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@RestController
public class MusicService {
    @Autowired
    MusicLogicImpl musicLogic;


    /**
     * 根据歌曲类型查询对应的歌曲
     * @param request
     * @param response
     * @throws IOException
     */

    @RequestMapping("/music")
    public void getMusic(HttpServletRequest request, HttpServletResponse response) throws IOException {
        RequestFormat.request_format(request,response);
        String musicType=request.getParameter("musicType");
        int page=Integer.valueOf(request.getParameter("page"));
        System.out.println("musicTypr:"+musicType+" page"+page);
        response.getWriter().write(musicLogic.select_music_like_musicType(musicType,page));
    }

    /**
     * 查询歌曲
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/query")
    public void queryMusic(HttpServletRequest request,HttpServletResponse response)throws IOException{
        RequestFormat.request_format(request,response);
        String queryData=request.getParameter("queryData");     //要查询的数据
        response.getWriter().write(musicLogic.query_music(queryData));
    }


    /**
     * 获取热门歌单
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/hot")
    public void getHotMusic(HttpServletRequest request,HttpServletResponse response)throws IOException{
        RequestFormat.request_format(request,response);
        Map<String,int[]> map=new HashMap<>();
        map.put("KTV",new int[]{11,20});
        map.put("DJ",new int[]{21,30});
        map.put("HOT",new int[]{31,40});
        map.put("RED",new int[]{41,50});
        map.put("CLASSICS",new int[]{51,60});
        map.put("LOVE",new int[]{61,70});
        map.put("NEXT",new int[]{71,80});
        map.put("CARTOON",new int[]{81,90});
        map.put("LIGHT",new int[]{91,100});
        map.put("BECOME",new int[]{101,110});

        int[] A=map.get(request.getParameter("hotMusicName"));
        System.out.println(Arrays.toString(A));
        response.getWriter().write(musicLogic.select_music_limit(A[0],A[1]));
    }
}
