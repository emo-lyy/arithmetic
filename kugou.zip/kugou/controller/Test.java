package com.example.kugou.controller;

import com.example.kugou.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;

@RestController

//专用测试接口
public class Test {
    @Autowired
    DataSource dataSource;

    @Autowired
    UserMapper userMapper;


    @RequestMapping("/test")
    public void test() throws Exception {
        System.out.println("正在进入测试中..........");
        System.out.println(userMapper.select_all().get(0).getNickName());
    }
}
