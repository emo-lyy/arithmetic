package com.example.kugou.mapper;

import com.example.kugou.pojo.Top;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;

@Component
public interface TopMapper extends Mapper<Top> {

    /**
     * 根据topName 查询对应的信息
     * @param identifier
     * @return
     */
    public Top select_by_name(@Param("top_identifier") String identifier);
}
