package com.example.kugou.mapper;

import com.example.kugou.pojo.Mv;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;

@Component
public interface MvMapper extends Mapper<Mv> {
    public Mv selectByName(@Param("MvName") String MvName);      //根据Mv的名字查询mv   （模糊查询取第一个）
}
