package com.example.kugou.mapper;

import com.example.kugou.pojo.SongList;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;


@Component
public interface SongListMapper extends Mapper<SongList> {

    /**
     * 根据歌单名称查询歌单信息
     * @param songListName
     * @return
     */
    public SongList select_by_name(@Param("name") String songListName);
}
