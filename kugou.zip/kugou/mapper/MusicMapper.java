package com.example.kugou.mapper;


import com.example.kugou.pojo.Music;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;
import java.util.Map;

@Component
public interface MusicMapper extends Mapper<Music> {
    public void addMusic(Music music);
    public List<Music> selectMusicLikeMusicType(@Param("map") Map<String,Object> select);
    public List<Music> queryMusic(@Param("queryData") String queryData);

    /**
     * 跟歌单表连表查询
     * @param songListName
     * @return
     */
    public List<Music> select_t_music_And_t_songList_by_songListName(@Param("name") String songListName);


    /**
     * 与top表联查
     * @param topId
     * @return
     */
    public List<Music> select_t_music_And_t_Top_by_musicId(@Param("top_id") Integer topId);


    /**
     * 电台
     * @param a
     * @param b
     * @return
     */
    public List<Music> select_limit(@Param("a") Integer a,@Param("b") Integer b);
}
