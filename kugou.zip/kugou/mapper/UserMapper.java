package com.example.kugou.mapper;

import com.example.kugou.pojo.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import tk.mybatis.mapper.common.Mapper;

import java.util.ArrayList;

@Component
public interface UserMapper extends Mapper<User> {
    public void addUser(User user);         //添加用户

    public ArrayList<User> select_all();    //查询所有用户

    public User select_by_user(@Param("usernName") String user);        //根据用户名查询用户

    public void update_pwd_by_name(@Param("userName") String userName,@Param("passWord") String pwd);         //根据用户名修改用户密码
}
