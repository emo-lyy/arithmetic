package com.example.kugou.config;

//@Configuration
public class JdbcConfig {
  /*  @Bean
    @ConfigurationProperties(prefix = "jdbc")
    public DataSource dataSource(){
        return new DruidDataSource();
    }*/
}
