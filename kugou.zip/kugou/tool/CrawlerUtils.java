package com.example.kugou.tool;

import org.jsoup.Connection;
import org.jsoup.Jsoup;

public final class CrawlerUtils {
    private CrawlerUtils() {}

    /**
     * 获取connection
     *
     * @param url
     * @return
     */
    public static Connection getConnection(String url) {
        Connection connection = Jsoup.connect(url);
        // 3.伪造请求头
        connection.header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
        connection.header("Accept-Encoding", "gzip, deflate, br");
        connection.header("Accept-Language", "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2");
        connection.header("Cache-Control", "max-age=0");
        connection.header("Connection", "keep-alive");
        connection.header("Cookie", "_ga=GA1.2.2056949165.1580206631");
        connection.header("Host", "zhipeng0908.gitee.io");
        connection.header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0");
        connection.ignoreHttpErrors(true);
        return connection;
    }
}
