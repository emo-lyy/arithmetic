package com.example.kugou.tool;

import com.ndktools.javamd5.Mademd5;

public class MD5 {
    private static Mademd5 md5=new Mademd5();

    private static final String PWD="EMO";


    /**
     * 加密
     * @param cleartext 明文
     * @return  密文
     */
    public static String encryption(String cleartext){
        return md5.toMd5(cleartext+PWD);
    }


    /**
     * 判断俩断密文是否一致
     * @return
     */
    public static boolean equals(String s1,String s2){
        return s1.equals(s2);
    }
}
