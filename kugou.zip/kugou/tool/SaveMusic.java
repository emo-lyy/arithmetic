package com.example.kugou.tool;

import org.junit.Test;

import java.util.Scanner;

public class SaveMusic {
    @Test
    public void main1() throws Exception{

    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("地址:");
            String url = scanner.next();
            System.out.print("歌手:");
            String singer = scanner.next();
            System.out.print("歌名:");
            String musicName = scanner.next();
            EncapsulatedFile.saveFile("https:" + url, singer + " - " + musicName + ".mp3");
        }
    }
}
