package com.example.kugou.tool;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class File {
    //创建文件
    public static void createFile(StringBuffer sb) throws IOException {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        Date date=new Date();
        String path="F:\\桌面文件夹\\学习文件\\java_网络爬虫\\爬虫素材\\歌曲\\"+sdf.format(date)+".txt";
        System.out.println(path);
        java.io.File file=new java.io.File(path);
        if(!file.exists())
            file.createNewFile();
        FileOutputStream out=new FileOutputStream(file,true);
        out.write(sb.toString().getBytes("utf-8"));
        out.close();
    }
    //删除文件
    public static void deleteFile(String path){
        java.io.File dir=new java.io.File(path);
        if(dir.exists()){
            java.io.File[] tmp=dir.listFiles();
            for(int i=0;i<tmp.length;i++){
                if(tmp[i].isDirectory()){
                    deleteFile(path+"/"+tmp[i].getName());
                }
             else{
                    tmp[i].delete();
                }
            }
            dir.delete();
        }
    }
}
