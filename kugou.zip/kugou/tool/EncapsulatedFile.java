package com.example.kugou.tool;

import java.io.File;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class EncapsulatedFile {
    private static String savePath01="F:\\桌面文件夹\\学习文件\\java_网络爬虫\\爬虫素材\\歌曲\\歌曲详情";          //默认文件保存地址
    private static String savePath02="F:\\桌面文件夹\\学习文件\\酷狗音乐资源";
    private static String savePath03="D:\\IDEAIU-2019.3.3\\work\\kugou\\src\\main\\resources\\static\\music";
    /**
     *
     *
     * @param ulr       文件网络路径
     * @param fileName  文件名称
     * @throws MalformedURLException
     * @throws IOException
     */
    public static void saveFile(String ulr, String fileName){
        try {
            // 构造URL
            URL weburl = new URL(ulr);
            // 打开连接
            URLConnection con = weburl.openConnection();
            // 设置请求超时为5s
            con.setConnectTimeout(5 * 1000);
            // 输入流
            InputStream is = con.getInputStream();
            // 1K的数据缓冲
            byte[] bs = new byte[1024];
            // 读取到的数据长度
            int len;
            // 输出的文件流
            java.io.File sf = new File(savePath03);
            if (!sf.exists()) {
                sf.mkdirs();
                }
            OutputStream os = new FileOutputStream(sf.getPath() + "\\" +  fileName);
             // 开始读取
            while ((len = is.read(bs)) != -1) {
                os.write(bs, 0, len);
            }
            // 完毕，关闭所有链接
            os.close();
            is.close();
            System.out.println("从:"+ulr+"下载  "+fileName+" 完毕!");

            //下载详情
            StringBuffer sb=new StringBuffer();
            String[] data=fileName.split(" ");
            sb.append("歌手:" + data[0] + "    歌曲:" + data[2] + "\n");
            sb.append("歌曲地址:" + ulr + "\n");
            com.example.kugou.tool.File.createFile(sb);

        } catch (IOException e){
            e.printStackTrace();
            System.out.println(fileName+" 下载出错!");
        }
    }
}
