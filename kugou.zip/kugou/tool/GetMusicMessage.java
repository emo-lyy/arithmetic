package com.example.kugou.tool;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.logging.Level;

public class GetMusicMessage {
    private static String ulr="";
    public GetMusicMessage(){}
    public GetMusicMessage(String ulr){this.ulr=ulr;}
    public String getUlr() {
        return ulr;
    }
    public void setUlr(String ulr) {
        this.ulr = ulr;
    }
    /**
     * 获取爬虫信息、     */
    public void getMessage(String tp,String key) throws IOException {
        //1.获取connection
        Connection connection=CrawlerUtils.getConnection(ulr);
        //2.执行请求
        Document document = connection.method(Connection.Method.POST)
                .data("tp",tp)
                .data("key",key)
                .execute()
                .parse();
        Element bodyElement = document.body();
        Elements cardElements = bodyElement.select(".searchResult li");

        for (Element element : cardElements){
            Elements singerElements=element.select(".p2");
            Elements musicElements=element.select(".p3");
            String singer=singerElements.text();        //歌手名称
            String music=musicElements.text();          //歌曲名称
            if(!singer.equals("歌手名称")) {
                System.out.println("歌手:" + singer + "    歌曲:" + music);
                Elements musicHref = musicElements.select("a[href]");
                String path = ulr.split("com")[0] + "com" + musicHref.attr("href");      //歌曲详情页面
                System.out.println("歌曲详情页面:" + path);
                String musicUrl=getMusicUrl(path);          //根据歌曲详情页面获取歌曲地址
                System.out.println("歌曲地址:"+musicUrl);
                EncapsulatedFile.saveFile(musicUrl,singer+" - "+music+".mp3");
            }
        }
    }
    //根据歌曲详情页面获取对应的歌曲链接
    public String getMusicUrl(String url){
        final String prefix="http://ting6.yymp3.net:82/";
        final WebClient webClient = new WebClient(BrowserVersion.CHROME);//新建一个模拟谷歌Chrome浏览器的浏览器客户端对象

        //关闭日志
        webClient.getOptions().setThrowExceptionOnScriptError(false);
        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        java.util.logging.Logger.getLogger("com.gargoylesoftware").setLevel(Level.OFF);
        java.util.logging.Logger.getLogger("org.apache.http.client").setLevel(Level.OFF);

        webClient.getOptions().setThrowExceptionOnScriptError(false);//当JS执行出错的时候是否抛出异常, 这里选择不需要
        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);//当HTTP的状态非200时是否抛出异常, 这里选择不需要
        webClient.getOptions().setActiveXNative(false);
        webClient.getOptions().setCssEnabled(false);//是否启用CSS, 因为不需要展现页面, 所以不需要启用
        webClient.getOptions().setJavaScriptEnabled(true); //很重要，启用JS
        webClient.setAjaxController(new NicelyResynchronizingAjaxController());//很重要，设置支持AJAX

        HtmlPage page = null;
        try {
            page = webClient.getPage(url);      //尝试加载页面
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            webClient.close();
        }
        webClient.waitForBackgroundJavaScript(30000);//异步JS执行需要耗时,所以这里线程要阻塞30秒,等待异步JS执行结束
        String pageXml = page.asXml();//直接将加载完成的页面转换成xml格式的字符串
        Document document = Jsoup.parse(pageXml);//获取html文档
        String html=document.toString();        //整个网页
        int beginIndex=html.indexOf("$song_data[0]");
        int endIndex=html.indexOf("$song_data[1]");
        String A=html.substring(beginIndex,endIndex);
        String[] data=A.split("\\|");
        String musicUrl=prefix+data[4].substring(0,data[4].length()-3)+"mp3";
        return musicUrl;
    }
}
